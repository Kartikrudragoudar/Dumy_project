"""
Enterprise AI Observability Panel

Demo-friendly dashboard showing:
- Classification
- Priority
- Resolution
- LLM provider
- Token usage
- Cost
- Confidence
- Traceability
"""

from __future__ import annotations

import streamlit as st

from ui import state


def inject_debug_styles() -> None:
    st.markdown(
        """
        <style>

        .debug-header{
            padding:12px;
            border-radius:12px;
            background:linear-gradient(
                90deg,
                #1e40af,
                #2563eb
            );
            color:white;
            margin-bottom:16px;
        }

        .trace-box{
            background:#f8fafc;
            border:1px solid #e2e8f0;
            border-radius:12px;
            padding:12px;
            margin-top:10px;
            font-size:13px;
        }

        .health-good{
            color:#16a34a;
            font-weight:700;
        }

        .health-bad{
            color:#dc2626;
            font-weight:700;
        }

        .section-label{
            font-size:13px;
            font-weight:700;
            color:#475569;
            margin-top:12px;
            margin-bottom:8px;
        }

        </style>
        """,
        unsafe_allow_html=True,
    )


def render_debug_drawer(client) -> None:

    ss = st.session_state

    resp = ss.get(state.LAST_RESPONSE)

    if not resp:
        return

    inject_debug_styles()

    with st.expander(
        "🔍 AI Observability Dashboard",
        expanded=False,
    ):

        llm = resp.get("llm", {})
        usage = resp.get("usage", {})

        st.markdown(
            """
            <div class="debug-header">
                <h4 style="margin:0">
                    🤖 Telecom Support Copilot Analytics
                </h4>
                <div style="font-size:13px">
                    Response diagnostics, model statistics and classification insights
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # -------------------------
        # Incident Intelligence
        # -------------------------

        st.markdown("##### 🎯 Incident Intelligence")

        c1, c2, c3 = st.columns(3)

        c1.metric(
            "Category",
            resp.get("category") or "—",
        )

        c2.metric(
            "Priority",
            resp.get("priority") or "—",
        )

        c3.metric(
            "Resolution",
            resp.get("resolution") or "—",
        )

        st.divider()

        # -------------------------
        # LLM Diagnostics
        # -------------------------

        st.markdown("##### 🧠 Model Diagnostics")

        c4, c5, c6 = st.columns(3)

        c4.metric(
            "Provider",
            llm.get("provider", "—"),
        )

        c5.metric(
            "Model Alias",
            llm.get("alias", "—"),
        )

        latency = resp.get("latency_ms", 0)

        c6.metric(
            "Latency",
            f"{latency} ms",
        )

        degraded = llm.get("degraded", False)

        if degraded:
            st.error(
                "Fallback model was used due to provider degradation."
            )
        else:
            st.success(
                "Primary model operating normally."
            )

        st.divider()

        # -------------------------
        # Token Analytics
        # -------------------------

        st.markdown("##### 📊 Token Analytics")

        prompt_tokens = usage.get(
            "prompt_tokens",
            0,
        )

        completion_tokens = usage.get(
            "completion_tokens",
            0,
        )

        total_tokens = (
            prompt_tokens +
            completion_tokens
        )

        c7, c8, c9 = st.columns(3)

        c7.metric(
            "Prompt Tokens",
            prompt_tokens,
        )

        c8.metric(
            "Completion Tokens",
            completion_tokens,
        )

        c9.metric(
            "Total Tokens",
            total_tokens,
        )

        cost = usage.get(
            "est_cost_usd",
            0.0,
        )

        st.metric(
            "Estimated Cost (USD)",
            f"${cost:.5f}",
        )

        if total_tokens > 0:

            st.progress(
                min(total_tokens / 10000, 1.0)
            )

            st.caption(
                f"Context Usage: {total_tokens:,} tokens"
            )

        st.divider()

        # -------------------------
        # Traceability
        # -------------------------

        st.markdown(
            "##### 🔗 Traceability"
        )

        trace_id = resp.get(
            "trace_id",
            "N/A",
        )

        st.markdown(
            f"""
            <div class='trace-box'>
                <b>Trace ID</b><br>
                <code>{trace_id}</code>
                <br><br>

                <b>Session ID</b><br>
                <code>{ss.get(state.SESSION_ID,'N/A')}</code>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.divider()

        # -------------------------
        # Classification
        # -------------------------

        st.markdown(
            "##### 🏷 Classification Analysis"
        )

        if st.button(
            "Analyze Classification",
            key="debug_classification",
            use_container_width=True,
        ):

            with st.spinner(
                "Running classifier..."
            ):

                try:

                    cls = client.classify(
                        resp.get(
                            "_last_message",
                            "",
                        ),
                        ss.get(
                            state.SESSION_ID
                        ),
                    )

                    st.success(
                        "Classification completed"
                    )

                    confidence = cls.get(
                        "confidence",
                        0,
                    )

                    st.metric(
                        "Confidence Score",
                        f"{confidence:.1%}"
                        if confidence <= 1
                        else f"{confidence}%",
                    )

                    if confidence <= 1:
                        score = confidence
                    else:
                        score = confidence / 100

                    st.progress(score)

                    st.json(cls)

                except Exception as exc:

                    st.error(
                        f"Classification failed: {exc}"
                    )

        # -------------------------
        # Raw Response
        # -------------------------

        with st.expander(
            "📄 Raw Response Payload",
            expanded=False,
        ):
            st.json(resp)
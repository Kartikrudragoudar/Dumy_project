---
name: Obsidian Flux
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#b4c5ff'
  on-secondary: '#002a78'
  secondary-container: '#0053db'
  on-secondary-container: '#cdd7ff'
  tertiary: '#4ae176'
  on-tertiary: '#003915'
  tertiary-container: '#00a74b'
  on-tertiary-container: '#003111'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  data-tabular:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-margin: 24px
  gutter: 16px
  panel-padding: 16px
  data-gap: 8px
  compact-gap: 4px
---

## Brand & Style

The design system is engineered for mission-critical enterprise environments where high-speed data processing and situational awareness are paramount. The brand personality is authoritative, technical, and precise, designed to reduce cognitive load during high-stress network incidents.

The aesthetic follows a **Modern Corporate** approach with a heavy emphasis on **High-Density Utility**. It utilizes deep tonal layering to establish hierarchy without the need for aggressive shadows. The interface feels like a sophisticated instrument panel—compact, efficient, and devoid of unnecessary ornamentation. Every pixel is dedicated to information density and legibility.

## Colors

The color palette is optimized for dark-room monitoring environments to reduce eye strain over long shifts.

- **Base & Surface**: The background uses a deep Slate Gray to provide a neutral foundation. Panels and surfaces use a slightly lighter Navy to create distinct functional zones.
- **Accents**: Indigo is used for primary actions and focus states, while Cyber Blue is reserved for informational highlights and secondary interactive elements.
- **Feedback**: Operational status relies on a vibrant Success Green. Warning and Error states (implied) should follow standard semantic patterns (Amber/Red) but maintain high saturation to pop against the dark backdrop.
- **Borders**: Subtle Slate is used for all structural divisions to maintain a clean, grid-based appearance without high-contrast distractions.

## Typography

This design system utilizes **Inter** for all UI controls and headings to ensure maximum readability. For technical data, IP addresses, and logs, **JetBrains Mono** is introduced to provide the character distinction necessary for error-free monitoring.

- **Density**: Use `body-sm` for standard table rows and `label-sm` for metadata tags.
- **Hierarchy**: Headlines are kept compact. Avoid using font sizes larger than 30px to maximize the "above the fold" data visibility.
- **Tabular Data**: Always use the `data-tabular` role for numerical values in tables to ensure columns align perfectly.

## Layout & Spacing

The layout uses a **Fluid Grid** system that prioritizes a multi-pane dashboard approach. 

- **Grid**: 12-column layout with 16px gutters.
- **Density**: A 4px base unit allows for tight alignment of technical components. 
- **Adaptation**:
  - **Desktop**: Three-pane layout (Navigation / Main View / Inspector).
  - **Tablet**: Collapsible Sidebar, Main View and Inspector become stacked or tabbed.
  - **Mobile**: Single column focus, optimized for alert acknowledgement and basic status checks only.
- **Spacing Rhythm**: Use `compact-gap` for related technical inputs and `data-gap` for list items.

## Elevation & Depth

Depth is conveyed through **Tonal Layers** rather than shadows. In a NOC environment, shadows can muddy the interface and reduce the clarity of small text.

- **Level 0 (Base)**: `#0F172A` - The primary canvas.
- **Level 1 (Panels)**: `#1E293B` - Used for primary data cards and sidebars.
- **Level 2 (Modals/Popovers)**: `#334155` - Used for elevated elements that require focus.

Borders are the primary method of separation. Every panel must have a 1px solid border using the `Subtle Slate` token to maintain structure.

## Shapes

The design system uses a **Rounded** (8px-12px) language to soften the industrial nature of the data.

- **Standard Elements**: Buttons, Input fields, and Chips use a 8px radius (`rounded`).
- **Containers**: Large dashboard panels and cards use a 12px radius (`rounded-lg`) to create clear containment.
- **Status Indicators**: Status dots and "Pills" use the maximum radius for a full-circle effect, making them easily distinguishable from interactive buttons.

## Components

- **Buttons**: Primary buttons use a solid Indigo fill. Secondary buttons use a Subtle Slate outline with no fill. Size should be compact (32px height) for high-density views.
- **Input Fields**: Dark backgrounds (`#0F172A`) with a Subtle Slate border. On focus, the border transitions to Cyber Blue with a subtle 2px outer glow of the same color.
- **Data Tables**: Zero-border on the outer container; internal rows separated by 1px Subtle Slate lines. Hover states should use a subtle highlight (`#334155`).
- **Status Chips**: Small, high-contrast badges. Success Green background with black text for maximum visibility, or transparent with a 2px stroke for secondary status.
- **Charts & Sparklines**: Use Cyber Blue for primary data trends. Avoid fills under lines unless necessary for area comparison; keep lines at 2px thickness for clarity.
- **Terminal/Log Component**: A dedicated component using JetBrains Mono, `#000000` background, and a "Success Green" or "White" cursor, nested within a Level 1 panel.
﻿# Telecom Support Agent â€” Network Issue Triage & Escalation

An agentic support assistant for a telecom operator. It classifies an inbound customer
issue, retrieves grounded troubleshooting guidance from an approved knowledge base,
attempts resolution, and escalates unresolved or high-priority cases to the correct
support queue with a simulated ticket.

| | |
|---|---|
| **Primary LLM** | Azure AI Foundry (models inference endpoint) |
| **Backup LLM** | Groq (OpenAI-compatible API) |
| **Embeddings** | Azure AI Foundry (ingestion-time only) |
| **Vector store** | FAISS (local file) |
| **Framework** | LangGraph + FastAPI + Streamlit |
| **Data** | Synthetic only |

---

## Table of Contents

1. [Architecture](#1-architecture)
2. [Agent Workflow](#2-agent-workflow)
3. [Project Structure](#3-project-structure)
4. [Local Setup](#4-local-setup)
5. [API Endpoints](#5-api-endpoints)
6. [Environment Variables](#6-environment-variables)

---

## 1. Architecture

```mermaid
graph LR
    C["Customer"] -->|chat| UI["Streamlit UI"]
    UI -->|HTTPS| API["FastAPI"]
    API --> AG["Agent Orchestrator<br/>LangGraph"]
    AG --> LLM["LLM Router"]
    LLM -->|primary| AF["Azure AI Foundry"]
    LLM -->|failover| GQ["Groq"]
    AG --> VDB["FAISS + BM25"]
    AG --> TOOL["Tools: ticketing, kb_search"]
    TOOL --> DB[("SQLite")]
```

- **FastAPI** — HTTP boundary: validation, auth, rate limiting, orchestration entry
- **LangGraph Agent** — graph-based orchestration: classify, retrieve, draft, verify, escalate
- **LLM Router** — provider selection with circuit-breaker failover (Foundry → Groq)
- **FAISS + BM25** — hybrid retrieval over the synthetic knowledge base
- **Streamlit UI** — chat interface with citations, ticket panel, and feedback

---

## 2. Agent Workflow

```mermaid
stateDiagram-v2
    [*] --> load_session
    load_session --> classify
    classify --> clarify: confidence < 0.6
    clarify --> [*]
    classify --> escalate: priority == P1
    classify --> retrieve
    retrieve --> escalate: no chunk above score threshold
    retrieve --> draft_answer
    draft_answer --> verify
    verify --> respond: grounded and cited
    verify --> retrieve: retry, attempt < 2
    verify --> escalate: retry budget exhausted
    respond --> persist
    escalate --> create_ticket
    create_ticket --> persist
    persist --> [*]
```

| Node | Responsibility |
|---|---|
| `load_session` | Hydrate memory, pin LLM provider for the session |
| `classify` | Determine category, priority, confidence |
| `clarify` | Ask a follow-up when confidence is low |
| `retrieve` | Hybrid search (BM25 + FAISS), apply score threshold |
| `draft_answer` | Generate grounded answer citing chunk IDs |
| `verify` | Check every claim maps to a retrieved chunk |
| `respond` | Format reply with citations |
| `escalate` | Select queue, assemble handover summary |
| `persist` | Write turn, usage, citations, outcome to DB |

---

## 3. Project Structure

```text
├── main.py
├── pyproject.toml
├── requirements.txt
├── .env-example
│
├── src/telecom_agent/
│   ├── agent/              # LangGraph orchestration
│   │   ├── graph.py        # Graph definition and compilation
│   │   ├── state.py        # TriageState TypedDict
│   │   ├── edges.py        # Conditional edge functions
│   │   ├── nodes/          # One file per graph node
│   │   └── policies/       # Routing table, thresholds, budget
│   │
│   ├── api/                # FastAPI HTTP layer
│   │   ├── main.py         # App factory, lifespan, routers
│   │   ├── deps.py         # Dependency injection
│   │   ├── routers/        # chat, classify, tickets, feedback, health
│   │   ├── schemas/        # Pydantic request/response models
│   │   └── middleware/     # auth, logging, rate_limit, request_id
│   │
│   ├── llm/                # LLM provider abstraction
│   │   ├── router.py       # Provider selection + failover
│   │   ├── base.py         # ChatProvider protocol
│   │   ├── providers/      # azure_foundry.py, groq.py, fake.py
│   │   ├── aliases.py      # Model alias mapping
│   │   └── guards.py       # Circuit breaker, budget guard
│   │
│   ├── prompts/            # Versioned YAML prompt templates
│   ├── memory/             # Session store + window trimming
│   ├── store/              # SQLAlchemy models + repositories
│   ├── tools/              # Ticketing, kb_search, diagnostics
│   ├── observability/      # Logging, metrics, telemetry
│   ├── config/             # Pydantic Settings
│   └── core/               # Enums, errors, types, utils
│
├── docker/                 # Container build assets
│   ├── Dockerfile.api      # Multi-stage build for FastAPI service
│   ├── Dockerfile.ui       # Streamlit UI image
│   └── docker-compose.yml  # Local stack: api + ui
│
└── ui/                     # Streamlit frontend (separate deployable)
    ├── app.py
    ├── api_client.py
    ├── state.py
    └── components/         # chat_panel, citation_card, ticket_panel, etc.
```

---

## 4. Local Setup

```bash
# 1. Clone and install
git clone <repo-url> && cd telecom-support-agent
pip install -e ".[dev]"
# or
uv sync

# 2. Configure environment
cp .env-example .env
# Edit .env with your API keys (or use LLM_PROVIDER=fake for no credentials)

# 3. Run the application
# API server
uvicorn src.telecom_agent.api.main:app --reload --port 8000

# Streamlit UI (separate terminal)
streamlit run ui/app.py --server.port 8501

# Run with fake LLM (no credentials needed)
LLM_PROVIDER=fake uvicorn src.telecom_agent.api.main:app --reload --port 8000
```

---

## 5. API Endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/v1/chat` | Main triage workflow — returns answer + citations + resolution |
| `POST` | `/v1/classify` | Classification only |
| `POST` | `/v1/tickets` | Create a simulated ticket (idempotent) |
| `GET` | `/v1/tickets/{ticket_id}` | Ticket status |
| `GET` | `/v1/tickets` | List tickets (filter by queue, priority, status) |
| `POST` | `/v1/feedback` | Thumbs up/down + comment |
| `GET` | `/healthz` | Liveness probe |
| `GET` | `/readyz` | Readiness probe |

### Example response — `POST /v1/chat`

```json
{
  "trace_id": "01JBX...",
  "session_id": "sess_8f2a",
  "category": "DATA_SLOW",
  "priority": "P2",
  "resolution": "RESOLVED",
  "answer": "Three steps to restore data service ...",
  "citations": [
    { "doc_id": "KB-114", "title": "APN reset – Android", "section": "2.3", "score": 0.81 }
  ],
  "ticket": null,
  "llm": { "provider": "AZURE_FOUNDRY", "alias": "chat-main", "degraded": false },
  "usage": { "prompt_tokens": 2841, "completion_tokens": 402 },
  "latency_ms": 4180
}
```

---

## 6. Environment Variables

```bash
# ---------- app ----------
APP_ENV=local                    # local | dev | prod
API_KEY=dev-key-change-me        # inbound auth for /v1/* endpoints
LOG_LEVEL=INFO

# ---------- LLM routing ----------
LLM_PROVIDER=fake               # azure_foundry | groq | fake
LLM_FAILOVER_ENABLED=true
LLM_BREAKER_COOLDOWN_SECONDS=60
LLM_REQUEST_TIMEOUT_SECONDS=20
SESSION_TOKEN_BUDGET=12000

# ---------- Azure AI Foundry (primary) ----------
AZURE_AI_ENDPOINT=https://<resource>.services.ai.azure.com/models
AZURE_AI_API_KEY=
AZURE_AI_DEPLOYMENT_CHAT_MAIN=chat-main
AZURE_AI_DEPLOYMENT_CHAT_MINI=chat-mini
AZURE_AI_DEPLOYMENT_EMBED=embed

# ---------- Groq (backup) ----------
GROQ_BASE_URL=https://api.groq.com/openai/v1
GROQ_API_KEY=
GROQ_MODEL_CHAT_MAIN=openai/gpt-oss-120b
GROQ_MODEL_CHAT_MINI=llama-3.1-8b-instant

# ---------- data ----------
INDEX_DIR=./data/index
DATABASE_URL=sqlite:///./data/app.db
RETRIEVAL_TOP_K=8
RETRIEVAL_SCORE_FLOOR=0.35
```

Set `LLM_PROVIDER=fake` to run the full application without any LLM credentials.


﻿# Network Support Operations Center (NOC) - Multi-Agent Assistant

An enterprise-grade **Network Support Operations Center** platform built with a **LangGraph multi-agent architecture**. The system autonomously triages network incidents, runs specialized diagnostics, retrieves resolution steps from SOPs via RAG, creates tickets, and escalates unresolved cases to the appropriate team.

| | |
|---|---|
| **Primary LLM** | Azure AI Foundry (GPT-4.1) |
| **Backup LLM** | Groq (Llama 3.1 70B) |
| **Embeddings** | HuggingFace `BAAI/bge-small-en-v1.5` (local) |
| **Vector Store** | FAISS (IndexFlatIP, cosine similarity) |
| **Framework** | LangGraph + FastAPI + Streamlit |
| **Observability** | LangSmith Tracing |
| **Authentication** | JWT + bcrypt (role-based access) |
| **Database** | SQLite / PostgreSQL (SQLAlchemy ORM) |

---

## Table of Contents

1. [Architecture](#1-architecture)
2. [Multi-Agent Workflow](#2-multi-agent-workflow)
3. [Project Structure](#3-project-structure)
4. [Local Setup](#4-local-setup)
5. [API Endpoints](#5-api-endpoints)
6. [Environment Variables](#6-environment-variables)
7. [Authentication & Roles](#7-authentication--roles)
8. [Streamlit Pages](#8-streamlit-pages)

---

## 1. Architecture

```mermaid
graph LR
    C["User / NOC Engineer"] -->|chat| UI["Streamlit Multipage UI"]
    UI -->|HTTPS| API["FastAPI Backend"]
    API --> AUTH["Auth Module<br/>JWT + bcrypt"]
    API --> AG["Multi-Agent Orchestrator<br/>LangGraph"]
    AG --> LLM["LLM Router"]
    LLM -->|primary| AF["Azure AI Foundry"]
    LLM -->|failover| GQ["Groq"]
    AG --> VDB["FAISS + BM25"]
    AG --> TOOL["Tools: ticketing, diagnostics"]
    TOOL --> DB[("SQLite")]
    AG --> LS["LangSmith Tracing"]
```

- **FastAPI** - HTTP boundary: validation, JWT auth, rate limiting, orchestration entry
- **LangGraph Multi-Agent** - Supervisor orchestrates Intent, Diagnostic, RAG, Resolution, Ticket, and Escalation agents
- **LLM Router** - Provider selection with circuit-breaker failover (Azure -> Groq)
- **FAISS + BM25** - Hybrid retrieval over enterprise network SOPs and runbooks
- **Streamlit UI** - 8-page multipage platform with role-based navigation

---

## 2. Multi-Agent Workflow

```mermaid
stateDiagram-v2
    [*] --> load_session
    load_session --> intent_classification_agent
    intent_classification_agent --> diagnostic_router_agent
    diagnostic_router_agent --> specialized_diagnostic_agent
    specialized_diagnostic_agent --> rag_agent
    rag_agent --> resolution_agent
    resolution_agent --> supervisor_agent: Resolved
    resolution_agent --> ticket_agent: Unresolved
    ticket_agent --> escalation_agent
    escalation_agent --> supervisor_agent
    supervisor_agent --> persist
    persist --> [*]
```

| Agent | Responsibility |
|---|---|
| `Supervisor Agent` | Orchestrates workflow, aggregates outputs, formats final response |
| `Intent Classification Agent` | Classifies intent (VPN, WiFi, DNS, Router, Connectivity) with confidence score |
| `Diagnostic Router Agent` | Routes to the correct specialized diagnostic agent |
| `Specialized Diagnostic Agent` | VPN / WiFi / DNS / Router / Connectivity domain-specific diagnostics |
| `RAG Agent` | Queries FAISS vector index for matching SOP passages and runbooks |
| `Resolution Agent` | Generates resolution steps; determines if issue is resolved |
| `Ticket Agent` | Creates structured incident ticket with priority and category |
| `Escalation Agent` | Assigns escalation level (L1/L2/L3) and target team |

---

## 3. Project Structure

```text
├── main.py
├── pyproject.toml
├── requirements.txt
├── .env-example
│
├── src/telecom_agent/
│   ├── agent/              # LangGraph multi-agent orchestration
│   │   ├── graph.py        # Graph definition and compilation
│   │   ├── multi_agent.py  # All agent implementations
│   │   ├── state.py        # TriageState TypedDict
│   │   ├── edges.py        # Conditional edge functions
│   │   ├── nodes/          # Original node implementations
│   │   └── policies/       # Routing table, thresholds, budget
│   │
│   ├── api/                # FastAPI HTTP layer
│   │   ├── main.py         # App factory, lifespan, routers
│   │   ├── deps.py         # Dependency injection
│   │   ├── routers/        # chat, classify, tickets, feedback, health, auth
│   │   ├── schemas/        # Pydantic request/response models
│   │   └── middleware/     # auth, logging, rate_limit, request_id
│   │
│   ├── auth/               # Authentication & User Management
│   │   ├── models.py       # SQLAlchemy User model
│   │   ├── database.py     # Engine, session factory
│   │   ├── security.py     # JWT, bcrypt, password validation
│   │   └── service.py      # User CRUD service layer
│   │
│   ├── llm/                # LLM provider abstraction
│   │   ├── router.py       # Provider selection + failover
│   │   ├── base.py         # ChatProvider protocol
│   │   ├── providers/      # azure_foundry.py, groq.py, fake.py
│   │   ├── aliases.py      # Model alias mapping
│   │   └── guards.py       # Circuit breaker, budget guard
│   │
│   ├── rag/                # RAG pipeline
│   │   ├── vector_store.py # FAISS IndexFlatIP vector store
│   │   ├── embeddings.py   # HuggingFace bge-small-en-v1.5
│   │   ├── retriever.py    # Hybrid retrieval (FAISS + BM25)
│   │   ├── ingest.py       # SOP document ingestion
│   │   └── chunking.py     # Text chunking utilities
│   │
│   ├── prompts/            # Versioned YAML prompt templates
│   │   ├── supervisor/     # Supervisor agent prompts
│   │   ├── intent/         # Intent classification prompts
│   │   ├── diagnostic/     # Diagnostic agent prompts
│   │   ├── resolution/     # Resolution agent prompts
│   │   └── escalation/     # Escalation agent prompts
│   │
│   ├── memory/             # Session store + window trimming
│   ├── store/              # SQLAlchemy models + repositories
│   ├── tools/              # Ticketing, kb_search, diagnostics
│   ├── observability/      # Logging (Loguru), metrics, LangSmith
│   ├── config/             # Pydantic Settings
│   └── core/               # Enums, errors, types, utils
│
├── docker/                 # Multi-stage Docker build
│   ├── Dockerfile          # Multi-target (api + ui stages)
│   ├── docker-compose.yml  # Local stack: api + ui
│   └── entrypoint.sh       # Service selector
│
├── tests/                  # Unit tests
│   ├── test_multi_agent.py
│   ├── test_rag_vector_store.py
│   └── test_ui.py
│
└── ui/                     # Streamlit multipage frontend
    ├── app.py              # Entry point
    ├── auth_manager.py     # Session management & RBAC
    ├── api_client.py       # FastAPI HTTP client
    ├── state.py            # Streamlit session state
    ├── components/         # Reusable UI components
    └── pages/              # 8 multipage views
        ├── 00_Signup.py
        ├── 0_Login.py
        ├── 1_Dashboard.py
        ├── 2_AI_Support_Chat.py
        ├── 3_My_Tickets.py
        ├── 4_Knowledge_Center.py
        ├── 5_Analytics.py
        ├── 6_Admin_Panel.py
        ├── 7_Profile.py
        └── 8_User_Management.py
```

---

## 4. Local Setup

```bash
# 1. Clone and install
git clone <repo-url> && cd Telecom-Support-Agent-main
pip install -e ".[dev]"
# or
pip install -r requirements.txt

# 2. Configure environment
cp .env-example .env
# Edit .env with your API keys (or use LLM_PROVIDER=fake for no credentials)

# 3. Run the FastAPI backend
uvicorn src.telecom_agent.api.main:app --reload --port 8000

# 4. Run the Streamlit frontend (separate terminal)
streamlit run ui/app.py --server.port 8501

# 5. Run with fake LLM (no credentials needed)
LLM_PROVIDER=fake uvicorn src.telecom_agent.api.main:app --reload --port 8000
```

### Docker

```bash
cd docker
docker compose up --build
```

- API: http://localhost:8000
- UI: http://localhost:8501

---

## 5. API Endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/auth/register` | User registration |
| `POST` | `/auth/login` | JWT login |
| `GET` | `/auth/me` | Get user profile |
| `PUT` | `/auth/me` | Update profile |
| `PUT` | `/auth/me/password` | Change password |
| `GET` | `/auth/users` | List all users (Admin) |
| `PUT` | `/auth/users/{id}/role` | Change user role (Admin) |
| `PUT` | `/auth/users/{id}/status` | Enable/disable user (Admin) |
| `DELETE` | `/auth/users/{id}` | Delete user (Admin) |
| `POST` | `/v1/chat` | Main multi-agent triage workflow |
| `POST` | `/v1/classify` | Intent classification only |
| `POST` | `/v1/tickets` | Create incident ticket |
| `GET` | `/v1/tickets/{id}` | Ticket status |
| `GET` | `/v1/tickets` | List tickets |
| `POST` | `/v1/feedback` | Submit feedback |
| `GET` | `/health/live` | Liveness probe |
| `GET` | `/health/ready` | Readiness probe |

---

## 6. Environment Variables

```bash
# ---------- App Configuration ----------
APP_ENV=local
API_KEY=dev-key-change-me
LOG_LEVEL=INFO

# ---------- LLM Routing ----------
LLM_PROVIDER=azure_foundry       # azure_foundry | groq | fake
LLM_FAILOVER_ENABLED=true
LLM_BREAKER_COOLDOWN_SECONDS=60
LLM_REQUEST_TIMEOUT_SECONDS=20
SESSION_TOKEN_BUDGET=500

# ---------- Azure AI Foundry (Primary) ----------
AZURE_AI_ENDPOINT=https://<resource-name>.services.ai.azure.com/models
AZURE_AI_API_KEY=your_key_here
AZURE_AI_DEPLOYMENT_CHAT_MAIN=gpt-41

# ---------- Groq (Backup) ----------
GROQ_BASE_URL=https://api.groq.com/openai/v1
GROQ_API_KEY=your_groq_key_here
GROQ_MODEL_CHAT_MAIN=llama-3.1-70b-versatile
GROQ_MODEL_CHAT_MINI=llama-3.1-8b-instant

# ---------- Vector Database ----------
EMBEDDING_MODEL=BAAI/bge-small-en-v1.5
FAISS_INDEX_DIR=./data/index
DATABASE_URL=sqlite:///./data/app.db
RETRIEVAL_TOP_K=5
RETRIEVAL_SCORE_FLOOR=0.35

# ---------- Observability ----------
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=your_langsmith_key
LANGCHAIN_PROJECT=network-support-assistant

# ---------- UI ----------
API_BASE_URL=http://localhost:8000
```

Set `LLM_PROVIDER=fake` to run the full application without any LLM credentials.

---

## 7. Authentication & Roles

The platform implements enterprise role-based access control (RBAC):

| Role | Access |
|---|---|
| **User** | Dashboard, AI Support Chat, My Tickets, Knowledge Center |
| **Network Engineer** | All User pages + Analytics |
| **Admin** | All pages + Admin Panel + User Management |

Features:
- JWT token generation with configurable expiration (8 hours)
- bcrypt password hashing (Passlib)
- Strong password validation (min 8 chars, upper, lower, number, special)
- Session persistence in Streamlit state
- Protected routes with role gates

---

## 8. Streamlit Pages

| Page | Description |
|---|---|
| **Login** | Enterprise sign-in with email/password |
| **Signup** | Employee registration (Employee ID, department, location) |
| **Dashboard** | NOC metrics, active incidents, live severity charts |
| **AI Support Chat** | Multi-agent triage interface with diagnostic cards |
| **My Tickets** | Interactive AgGrid ticket table with timeline |
| **Knowledge Center** | FAISS RAG search for SOPs and runbooks |
| **Analytics** | Plotly charts - category distribution, escalation breakdown |
| **Admin Panel** | SOP upload, FAISS index rebuild, LangSmith status |
| **Profile** | View/update profile, change password |
| **User Management** | Admin CRUD - search, filter, edit roles, enable/disable users |

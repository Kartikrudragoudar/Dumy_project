#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-api}"

case "$MODE" in
  api)
    exec uvicorn src.telecom_agent.api.main:app \
      --host 0.0.0.0 \
      --port 8000 \
      --workers 1
    ;;
  ui)
    exec streamlit run ui/app.py \
      --server.port 8501 \
      --server.address 0.0.0.0 \
      --server.headless true
    ;;
  *)
    echo "Usage: entrypoint.sh {api|ui}"
    exit 1
    ;;
esac

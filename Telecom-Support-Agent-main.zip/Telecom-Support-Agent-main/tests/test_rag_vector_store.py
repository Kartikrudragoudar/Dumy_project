"""Unit tests for FAISS Vector Store & Embeddings."""

import pytest
from telecom_agent.config.settings import Settings
from telecom_agent.rag.embeddings import get_embedder


def test_get_embedder_local():
    settings = Settings(llm_provider="fake")
    embed_fn = get_embedder(settings)
    
    vectors = embed_fn(["ping 8.8.8.8", "vpn gateway timeout"])
    assert isinstance(vectors, list)
    assert len(vectors) == 2
    assert isinstance(vectors[0], list)
    assert len(vectors[0]) > 0

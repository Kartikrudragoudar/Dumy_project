"""Unit tests for Streamlit Multipage UI state and helper functions."""

from __future__ import annotations

from ui.state import init_state, reset_chat, save_feedback


class MockSessionState(dict):
    """Mock Streamlit session state for unit testing without browser dependencies."""
    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError:
            raise AttributeError(key)

    def __setattr__(self, key, value):
        self[key] = value


def test_ui_session_state_initialization(monkeypatch):
    mock_state = MockSessionState()
    import streamlit as st
    monkeypatch.setattr(st, "session_state", mock_state)

    init_state()

    assert "session_id" in mock_state
    assert "messages" in mock_state
    assert isinstance(mock_state["messages"], list)


def test_ui_reset_chat(monkeypatch):
    mock_state = MockSessionState()
    import streamlit as st
    monkeypatch.setattr(st, "session_state", mock_state)

    init_state()
    mock_state["messages"].append({"role": "user", "content": "Hello"})
    
    reset_chat()
    assert len(mock_state["messages"]) == 0


def test_save_feedback(monkeypatch):
    mock_state = MockSessionState()
    import streamlit as st
    monkeypatch.setattr(st, "session_state", mock_state)

    init_state()

    save_feedback("msg-123", "helpful", "Great solution!")
    assert len(mock_state["feedbacks"]) == 1
    assert mock_state["feedbacks"][0]["message_id"] == "msg-123"
    assert mock_state["feedbacks"][0]["rating"] == "helpful"

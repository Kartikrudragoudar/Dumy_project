"""Unit tests for Network Support Assistant multi-agent components."""

import pytest
from telecom_agent.config.settings import Settings
from telecom_agent.core.enums import DiagnosticRoute, NetworkIntent, Priority
from telecom_agent.agent.multi_agent import (
    diagnostic_router_agent,
    intent_classification_agent,
    rag_agent,
)
from telecom_agent.agent.state import TriageState


class MockLLMRouter:
    def __init__(self, text_response: str):
        self._resp = text_response

    def chat(self, session_id, messages, alias=None, json_mode=False):
        class Result:
            text = self._resp
            provider = "fake"
            model = "mock-model"
            prompt_tokens = 10
            completion_tokens = 20
        return Result()


class MockDeps:
    def __init__(self, text_response: str = "{}"):
        self.settings = Settings(llm_provider="fake")
        self.router = MockLLMRouter(text_response)


def test_diagnostic_router_vpn():
    state: TriageState = {"intent": NetworkIntent.VPN_ISSUE, "session_id": "test-1"}
    deps = MockDeps()
    res = diagnostic_router_agent(state, deps)
    assert res["diagnostic_route"] == DiagnosticRoute.VPN_DIAGNOSTIC


def test_diagnostic_router_wifi():
    state: TriageState = {"intent": NetworkIntent.WIFI_ISSUE, "session_id": "test-2"}
    deps = MockDeps()
    res = diagnostic_router_agent(state, deps)
    assert res["diagnostic_route"] == DiagnosticRoute.WIFI_DIAGNOSTIC


def test_intent_classification_agent_parsing():
    mock_json = '{"intent": "vpn_issue", "confidence": 0.92, "affected_service": "cisco_vpn", "priority": "high"}'
    deps = MockDeps(text_response=mock_json)
    state: TriageState = {"session_id": "test-3", "user_input": "VPN connection keeps timing out"}
    
    res = intent_classification_agent(state, deps)
    assert res["intent"] == NetworkIntent.VPN_ISSUE
    assert res["confidence"] == 0.92
    assert res["affected_service"] == "cisco_vpn"
    assert res["priority"] == Priority.HIGH

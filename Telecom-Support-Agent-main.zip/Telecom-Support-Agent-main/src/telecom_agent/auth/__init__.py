"""Authentication module."""

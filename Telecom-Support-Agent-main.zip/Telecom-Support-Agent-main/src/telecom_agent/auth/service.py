"""Authentication service layer — business logic for user operations."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from telecom_agent.auth.models import User
from telecom_agent.auth.security import hash_password, verify_password


def create_user(
    db: Session,
    employee_id: str,
    first_name: str,
    last_name: str,
    email: str,
    password: str,
    department: str,
    location: str,
    role: str = "User",
) -> User:
    user = User(
        employee_id=employee_id,
        first_name=first_name,
        last_name=last_name,
        email=email.lower(),
        password_hash=hash_password(password),
        department=department,
        location=location,
        role=role,
        status=True,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def authenticate_user(db: Session, email: str, password: str) -> User | None:
    user = db.query(User).filter(User.email == email.lower()).first()
    if not user or not user.status:
        return None
    if not verify_password(password, user.password_hash):
        return None
    user.last_login = datetime.now(timezone.utc)
    db.commit()
    return user


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email.lower()).first()


def get_user_by_employee_id(db: Session, employee_id: str) -> User | None:
    return db.query(User).filter(User.employee_id == employee_id).first()


def get_user_by_id(db: Session, user_id: int) -> User | None:
    return db.query(User).filter(User.user_id == user_id).first()


def get_all_users(db: Session) -> list[User]:
    return db.query(User).all()


def update_user_profile(db: Session, user_id: int, department: str | None = None, location: str | None = None) -> User | None:
    user = get_user_by_id(db, user_id)
    if not user:
        return None
    if department:
        user.department = department
    if location:
        user.location = location
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    return user


def update_user_password(db: Session, user_id: int, new_password: str) -> bool:
    user = get_user_by_id(db, user_id)
    if not user:
        return False
    user.password_hash = hash_password(new_password)
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    return True


def update_user_role(db: Session, user_id: int, role: str) -> User | None:
    user = get_user_by_id(db, user_id)
    if not user:
        return None
    user.role = role
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    return user


def toggle_user_status(db: Session, user_id: int, status: bool) -> User | None:
    user = get_user_by_id(db, user_id)
    if not user:
        return None
    user.status = status
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    return user


def delete_user(db: Session, user_id: int) -> bool:
    user = get_user_by_id(db, user_id)
    if not user:
        return False
    db.delete(user)
    db.commit()
    return True

"""FastAPI Authentication Router — Login, Register, Profile, User Management."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from telecom_agent.auth.database import get_db, init_db
from telecom_agent.auth.security import (
    create_access_token,
    decode_access_token,
    validate_email,
    validate_password_strength,
)
from telecom_agent.auth.service import (
    authenticate_user,
    create_user,
    delete_user,
    get_all_users,
    get_user_by_email,
    get_user_by_employee_id,
    get_user_by_id,
    toggle_user_status,
    update_user_password,
    update_user_profile,
    update_user_role,
)

router = APIRouter(prefix="/auth", tags=["Authentication"])


# --- Schemas ---

class RegisterRequest(BaseModel):
    employee_id: str = Field(..., min_length=2, max_length=50)
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    email: str = Field(..., max_length=255)
    password: str = Field(..., min_length=8)
    department: str = Field(..., min_length=1, max_length=100)
    location: str = Field(..., min_length=1, max_length=100)


class LoginRequest(BaseModel):
    email: str
    password: str


class ProfileUpdateRequest(BaseModel):
    department: str | None = None
    location: str | None = None


class PasswordUpdateRequest(BaseModel):
    new_password: str = Field(..., min_length=8)


class RoleUpdateRequest(BaseModel):
    role: str = Field(..., pattern="^(User|Network Engineer|Admin)$")


class StatusUpdateRequest(BaseModel):
    status: bool


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


# --- Endpoints ---

@router.on_event("startup")
async def startup():
    init_db()


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    if not validate_email(req.email):
        raise HTTPException(status_code=400, detail="Invalid email format.")

    valid, msg = validate_password_strength(req.password)
    if not valid:
        raise HTTPException(status_code=400, detail=msg)

    if get_user_by_email(db, req.email):
        raise HTTPException(status_code=409, detail="Email already registered.")

    if get_user_by_employee_id(db, req.employee_id):
        raise HTTPException(status_code=409, detail="Employee ID already registered.")

    user = create_user(
        db=db,
        employee_id=req.employee_id,
        first_name=req.first_name,
        last_name=req.last_name,
        email=req.email,
        password=req.password,
        department=req.department,
        location=req.location,
    )
    return {"message": "Registration successful.", "user_id": user.user_id}


@router.post("/login", response_model=TokenResponse)
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = authenticate_user(db, req.email, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials or account disabled.")

    token = create_access_token(data={"sub": str(user.user_id), "role": user.role, "email": user.email})
    return TokenResponse(access_token=token, user=user.to_dict())


@router.get("/me")
def get_profile(user_id: int, db: Session = Depends(get_db)):
    user = get_user_by_id(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    return user.to_dict()


@router.put("/me")
def update_profile(user_id: int, req: ProfileUpdateRequest, db: Session = Depends(get_db)):
    user = update_user_profile(db, user_id, department=req.department, location=req.location)
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    return {"message": "Profile updated.", "user": user.to_dict()}


@router.put("/me/password")
def change_password(user_id: int, req: PasswordUpdateRequest, db: Session = Depends(get_db)):
    valid, msg = validate_password_strength(req.new_password)
    if not valid:
        raise HTTPException(status_code=400, detail=msg)
    success = update_user_password(db, user_id, req.new_password)
    if not success:
        raise HTTPException(status_code=404, detail="User not found.")
    return {"message": "Password updated successfully."}


@router.get("/users")
def list_users(db: Session = Depends(get_db)):
    users = get_all_users(db)
    return [u.to_dict() for u in users]


@router.put("/users/{user_id}/role")
def change_role(user_id: int, req: RoleUpdateRequest, db: Session = Depends(get_db)):
    user = update_user_role(db, user_id, req.role)
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    return {"message": f"Role updated to {req.role}.", "user": user.to_dict()}


@router.put("/users/{user_id}/status")
def change_status(user_id: int, req: StatusUpdateRequest, db: Session = Depends(get_db)):
    user = toggle_user_status(db, user_id, req.status)
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    return {"message": f"User {'enabled' if req.status else 'disabled'}.", "user": user.to_dict()}


@router.delete("/users/{user_id}")
def remove_user(user_id: int, db: Session = Depends(get_db)):
    success = delete_user(db, user_id)
    if not success:
        raise HTTPException(status_code=404, detail="User not found.")
    return {"message": "User deleted."}

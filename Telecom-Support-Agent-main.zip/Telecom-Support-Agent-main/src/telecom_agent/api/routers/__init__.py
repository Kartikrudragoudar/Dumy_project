"""One module per resource, keeping route files small."""

from telecom_agent.api.routers import admin, chat, classify, feedback, health, tickets

__all__ = ["admin", "chat", "classify", "feedback", "health", "tickets"]

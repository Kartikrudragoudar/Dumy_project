"""One module per resource, keeping route files small."""

from telecom_agent.api.routers import chat, classify, feedback, health, tickets

__all__ = ["chat", "classify", "feedback", "health", "tickets"]

"""Admin & stats endpoints: index stats, system config, KB docs, LLM health."""

from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Depends

from telecom_agent.api.deps import Container, get_container

router = APIRouter(prefix="/v1/admin", tags=["admin"])


@router.get("/stats")
def system_stats(container: Container = Depends(get_container)) -> dict:
    """Aggregate stats: ticket counts by status/priority/category, index info."""
    tickets = container.ticket_repo.list(limit=5000)

    by_status: dict[str, int] = {}
    by_priority: dict[str, int] = {}
    by_category: dict[str, int] = {}
    for t in tickets:
        s = str(t.status)
        by_status[s] = by_status.get(s, 0) + 1
        p = str(t.priority)
        by_priority[p] = by_priority.get(p, 0) + 1
        c = str(t.category)
        by_category[c] = by_category.get(c, 0) + 1

    # FAISS index info
    store = getattr(container.retriever, "_vs", None)
    index_total = 0
    if store and hasattr(store, "_index"):
        index_total = store._index.ntotal

    return {
        "total_tickets": len(tickets),
        "by_status": by_status,
        "by_priority": by_priority,
        "by_category": by_category,
        "index_chunks": index_total,
    }


@router.get("/config")
def system_config(container: Container = Depends(get_container)) -> dict:
    """Return current system configuration (non-secret values)."""
    s = container.settings
    return {
        "llm_provider": s.llm_provider,
        "llm_failover_enabled": s.llm_failover_enabled,
        "llm_breaker_cooldown_seconds": s.llm_breaker_cooldown_seconds,
        "llm_request_timeout_seconds": s.llm_request_timeout_seconds,
        "session_token_budget": s.session_token_budget,
        "retrieval_top_k": s.retrieval_top_k,
        "retrieval_score_floor": s.retrieval_score_floor,
        "index_dir": s.index_dir,
        "kb_dir": s.kb_dir,
        "database_url": s.database_url,
        "langchain_project": s.langchain_project,
        "langchain_tracing_v2": s.langchain_tracing_v2,
        "embedding_model": "BAAI/bge-small-en-v1.5",
        "azure_ai_deployment": s.azure_ai_deployment_chat_main,
    }


@router.get("/llm-health")
def llm_health(container: Container = Depends(get_container)) -> dict:
    """LLM provider health and circuit breaker state."""
    provider_health = container.router.health()
    is_degraded = getattr(container.router, "_degraded", False)
    active_provider = "azure_foundry"
    if is_degraded:
        active_provider = "groq"

    return {
        "providers": provider_health,
        "active_provider": active_provider,
        "circuit_breaker": "OPEN" if is_degraded else "CLOSED",
        "failover_enabled": container.settings.llm_failover_enabled,
        "cooldown_seconds": container.settings.llm_breaker_cooldown_seconds,
    }


@router.get("/kb-docs")
def kb_docs(container: Container = Depends(get_container)) -> dict:
    """List knowledge base documents from the index metadata."""
    store = getattr(container.retriever, "_vs", None)
    docs: dict[str, dict] = {}
    total_chunks = 0

    if store and hasattr(store, "_metadata"):
        total_chunks = len(store._metadata)
        for m in store._metadata:
            doc_id = m.get("doc_id", "unknown")
            if doc_id not in docs:
                docs[doc_id] = {"doc_id": doc_id, "title": m.get("title", doc_id), "chunks": 0, "sections": set()}
            docs[doc_id]["chunks"] += 1
            section = m.get("section", "")
            if section:
                docs[doc_id]["sections"].add(section)

    doc_list = []
    for d in docs.values():
        doc_list.append({
            "doc_id": d["doc_id"],
            "title": d["title"],
            "chunks": d["chunks"],
            "sections": list(d["sections"]) if isinstance(d["sections"], set) else d["sections"],
        })

    return {
        "total_docs": len(doc_list),
        "total_chunks": total_chunks,
        "documents": sorted(doc_list, key=lambda x: x["chunks"], reverse=True),
    }


@router.post("/search")
def kb_search(query: dict, container: Container = Depends(get_container)) -> dict:
    """Search the knowledge base and return results with scores."""
    q = query.get("query", "")
    k = query.get("k", 5)
    if not q:
        return {"results": [], "query": q}

    result = container.retriever.search(q, k=k)
    items = []
    for chunk in result.chunks:
        items.append({
            "doc_id": chunk.doc_id,
            "title": chunk.title,
            "section": chunk.section,
            "text": chunk.text,
            "score": round(chunk.score, 4),
        })

    return {
        "query": q,
        "results": items,
        "max_score": round(result.max_score, 4),
        "total": len(items),
    }

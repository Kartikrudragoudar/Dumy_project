"""Model access, isolated so providers are swappable. Contains no prompt text."""

from telecom_agent.llm.aliases import resolve
from telecom_agent.llm.base import ChatProvider, ChatResult
from telecom_agent.llm.guards import CircuitBreaker, TokenBudget, scan_for_injection
from telecom_agent.llm.router import LLMRouter, build_provider

__all__ = [
    "CircuitBreaker",
    "ChatProvider",
    "ChatResult",
    "LLMRouter",
    "TokenBudget",
    "build_provider",
    "resolve",
    "scan_for_injection",
]

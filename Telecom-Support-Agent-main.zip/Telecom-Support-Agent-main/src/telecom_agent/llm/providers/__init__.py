"""Concrete provider adapters, one file per vendor."""

from telecom_agent.llm.providers.azure_foundry import AzureFoundryProvider
from telecom_agent.llm.providers.fake import FakeProvider
from telecom_agent.llm.providers.groq import GroqProvider

__all__ = ["AzureFoundryProvider", "FakeProvider", "GroqProvider"]

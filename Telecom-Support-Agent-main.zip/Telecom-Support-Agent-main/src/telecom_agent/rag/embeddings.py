"""Embedding helpers: pick an embedder from settings (provider or sentence-transformers)."""

from __future__ import annotations

import logging
from collections.abc import Callable

from telecom_agent.config.settings import Settings
from telecom_agent.core.enums import Provider

log = logging.getLogger(__name__)

EmbedFn = Callable[[list[str]], list[list[float]]]


def get_embedder(settings: Settings) -> EmbedFn:
    """Return an embed function based on the configured provider."""
    provider = settings.default_provider

    if provider == Provider.FAKE:
        from telecom_agent.llm.providers.fake import FakeProvider

        fake = FakeProvider()
        return lambda texts: fake.embed(texts)

    if provider == Provider.AZURE_FOUNDRY:
        return _azure_embedder(settings)

    # Default: sentence-transformers (local, no credentials)
    return _local_embedder()


def _azure_embedder(settings: Settings) -> EmbedFn:
    """Use Azure AI Foundry embeddings endpoint."""
    from telecom_agent.llm.providers.azure_foundry import AzureFoundryProvider

    prov = AzureFoundryProvider(settings)
    return lambda texts: prov.embed(texts)


def _local_embedder(model_name: str = "all-MiniLM-L6-v2") -> EmbedFn:
    """Fallback: sentence-transformers running locally."""
    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(model_name)
        log.info("loaded local embedding model: %s", model_name)
        return lambda texts: model.encode(texts, normalize_embeddings=True).tolist()
    except ImportError:
        log.warning("sentence-transformers not available; using fake embeddings")
        from telecom_agent.llm.providers.fake import FakeProvider

        fake = FakeProvider()
        return lambda texts: fake.embed(texts)

"""Load documents from the KB directory (Markdown, PDF, plain text)."""

from __future__ import annotations

import logging
import re
from pathlib import Path

from telecom_agent.rag.schemas import Document

log = logging.getLogger(__name__)

_SUPPORTED = {".md", ".txt", ".pdf"}


def load_directory(kb_dir: str) -> list[Document]:
    """Recursively load all supported files from *kb_dir*."""
    root = Path(kb_dir)
    if not root.is_dir():
        log.warning("KB directory %s does not exist; returning empty list", kb_dir)
        return []

    docs: list[Document] = []
    for path in sorted(root.rglob("*")):
        if path.suffix.lower() not in _SUPPORTED or not path.is_file():
            continue
        try:
            text = _read(path)
            if not text.strip():
                continue
            doc_id = _doc_id(path, root)
            title = _title_from(text, path)
            docs.append(Document(doc_id=doc_id, title=title, text=text))
            log.debug("loaded %s (%d chars)", doc_id, len(text))
        except Exception as exc:  # noqa: BLE001
            log.warning("skipping %s: %s", path, exc)
    log.info("loaded %d documents from %s", len(docs), kb_dir)
    return docs


def _read(path: Path) -> str:
    if path.suffix.lower() == ".pdf":
        return _read_pdf(path)
    return path.read_text(encoding="utf-8", errors="replace")


def _read_pdf(path: Path) -> str:
    try:
        import fitz  # pymupdf

        with fitz.open(str(path)) as doc:
            return "\n".join(page.get_text() for page in doc)
    except ImportError:
        try:
            from pypdf import PdfReader

            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except ImportError:
            log.warning("no PDF reader available; skipping %s", path)
            return ""


def _doc_id(path: Path, root: Path) -> str:
    """Derive a stable doc_id like KB-001 from the filename."""
    stem = path.stem.upper()
    m = re.search(r"(\d+)", stem)
    num = m.group(1).zfill(3) if m else stem[:6]
    return f"KB-{num}"


def _title_from(text: str, path: Path) -> str:
    """Use the first heading or filename as the document title."""
    for line in text.splitlines()[:10]:
        line = line.strip()
        if line.startswith("#"):
            return line.lstrip("#").strip()
        if line and not line.startswith("---"):
            return line[:120]
    return path.stem.replace("_", " ").replace("-", " ").title()

"""Hybrid retriever: merges FAISS (dense) and BM25 (sparse) results with RRF."""

from __future__ import annotations

import logging
from collections import defaultdict

from telecom_agent.core.types import Chunk
from telecom_agent.rag.embeddings import EmbedFn
from telecom_agent.rag.keyword_index import KeywordIndex
from telecom_agent.rag.schemas import RetrievalResult
from telecom_agent.rag.vector_store import VectorStore

log = logging.getLogger(__name__)

# Reciprocal Rank Fusion constant
_RRF_K = 60


class HybridRetriever:
    def __init__(self, vector_store: VectorStore, keyword_index: KeywordIndex, embed_fn: EmbedFn):
        self._vs = vector_store
        self._kw = keyword_index
        self._embed_fn = embed_fn

    @classmethod
    def load(cls, index_dir: str, embed_fn: EmbedFn) -> HybridRetriever:
        vs = VectorStore.load(index_dir)
        kw = KeywordIndex.load(index_dir)
        return cls(vs, kw, embed_fn)

    def search(self, query: str, k: int = 8) -> RetrievalResult:
        # Dense retrieval
        query_emb = self._embed_fn([query])[0]
        dense_chunks = self._vs.search(query_emb, k=k * 2)

        # Sparse retrieval
        sparse_chunks = self._kw.search(query, k=k * 2)

        # Merge with Reciprocal Rank Fusion
        merged = _rrf_merge(dense_chunks, sparse_chunks, k=k)

        max_score = max((c.score for c in merged), default=0.0)
        log.debug("hybrid search: %d results, max_score=%.3f", len(merged), max_score)
        return RetrievalResult(chunks=merged, max_score=max_score)


def _chunk_key(c: Chunk) -> str:
    return f"{c.doc_id}|{c.section}"


def _rrf_merge(dense: list[Chunk], sparse: list[Chunk], k: int) -> list[Chunk]:
    """Reciprocal Rank Fusion: combine two ranked lists into one."""
    scores: dict[str, float] = defaultdict(float)
    chunk_map: dict[str, Chunk] = {}

    for rank, c in enumerate(dense):
        key = _chunk_key(c)
        scores[key] += 1.0 / (_RRF_K + rank + 1)
        chunk_map[key] = c

    for rank, c in enumerate(sparse):
        key = _chunk_key(c)
        scores[key] += 1.0 / (_RRF_K + rank + 1)
        if key not in chunk_map:
            chunk_map[key] = c

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:k]

    # Normalise fused scores to [0, 1]
    max_fused = ranked[0][1] if ranked else 1.0
    result: list[Chunk] = []
    for key, fused_score in ranked:
        c = chunk_map[key]
        result.append(
            Chunk(
                doc_id=c.doc_id,
                title=c.title,
                section=c.section,
                text=c.text,
                score=round(fused_score / max_fused, 4),
                source="hybrid",
            )
        )
    return result

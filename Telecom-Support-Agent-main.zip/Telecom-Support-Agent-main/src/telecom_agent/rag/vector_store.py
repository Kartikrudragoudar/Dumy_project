"""FAISS vector store: persistent vector index for SOPs and Runbooks."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np

from telecom_agent.core.types import Chunk
from telecom_agent.rag.embeddings import EmbedFn
from telecom_agent.rag.schemas import ChunkRecord

log = logging.getLogger(__name__)

_INDEX_FILE = "faiss_index.bin"
_META_FILE = "faiss_meta.json"


class VectorStore:
    def __init__(self, index, metadata: list[dict], texts: list[str]) -> None:
        self._index = index
        self._metadata = metadata
        self._texts = texts

    @staticmethod
    def exists(index_dir: str) -> bool:
        d = Path(index_dir)
        return (d / _INDEX_FILE).exists() and (d / _META_FILE).exists()

    @classmethod
    def build(cls, records: list[ChunkRecord], embed_fn: EmbedFn, index_dir: str = "./data/index") -> "VectorStore":
        """Build FAISS index from chunk records."""
        import faiss

        d = Path(index_dir)
        d.mkdir(parents=True, exist_ok=True)

        if not records:
            dim = 384
            index = faiss.IndexFlatIP(dim)
            return cls(index, [], [])

        texts = [r.text for r in records]
        embeddings = embed_fn(texts)
        embeddings_np = np.array(embeddings, dtype=np.float32)

        # Normalize for cosine similarity via inner product
        faiss.normalize_L2(embeddings_np)

        dim = embeddings_np.shape[1]
        index = faiss.IndexFlatIP(dim)
        index.add(embeddings_np)

        metadata = [
            {"doc_id": r.doc_id, "title": r.title, "section": r.section}
            for r in records
        ]

        # Persist to disk
        faiss.write_index(index, str(d / _INDEX_FILE))
        (d / _META_FILE).write_text(json.dumps({"metadata": metadata, "texts": texts}, ensure_ascii=False))

        log.info("built FAISS index with %d vectors (dim=%d) at %s", len(records), dim, d)
        return cls(index, metadata, texts)

    def save(self, index_dir: str) -> None:
        import faiss

        d = Path(index_dir)
        d.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(d / _INDEX_FILE))
        (d / _META_FILE).write_text(json.dumps({"metadata": self._metadata, "texts": self._texts}, ensure_ascii=False))
        log.info("FAISS index saved to %s", d)

    @classmethod
    def load(cls, index_dir: str = "./data/index", embed_fn: EmbedFn | None = None) -> "VectorStore":
        import faiss

        d = Path(index_dir)
        index = faiss.read_index(str(d / _INDEX_FILE))
        data = json.loads((d / _META_FILE).read_text())
        metadata = data["metadata"]
        texts = data["texts"]
        log.info("loaded FAISS index from %s (%d vectors)", d, index.ntotal)
        return cls(index, metadata, texts)

    def search(self, query_embedding: list[float], k: int = 8) -> list[Chunk]:
        """Return the top-k chunks by cosine similarity."""
        import faiss

        if self._index.ntotal == 0:
            return []

        query_np = np.array([query_embedding], dtype=np.float32)
        faiss.normalize_L2(query_np)

        scores, indices = self._index.search(query_np, min(k, self._index.ntotal))

        chunks: list[Chunk] = []
        for score, idx in zip(scores[0], indices[0], strict=False):
            if idx < 0:
                continue
            meta = self._metadata[idx]
            chunks.append(
                Chunk(
                    doc_id=meta["doc_id"],
                    title=meta["title"],
                    section=meta["section"],
                    text=self._texts[idx],
                    score=round(float(score), 4),
                    source="dense",
                )
            )
        return chunks

    @property
    def size(self) -> int:
        return self._index.ntotal
    def size(self) -> int:
        return self._index.ntotal

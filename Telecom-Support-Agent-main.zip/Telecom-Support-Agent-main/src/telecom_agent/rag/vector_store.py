"""FAISS vector store: save/load/search over dense embeddings."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np

from telecom_agent.core.types import Chunk
from telecom_agent.rag.embeddings import EmbedFn
from telecom_agent.rag.schemas import ChunkRecord

log = logging.getLogger(__name__)

_INDEX_FILE = "faiss.index"
_META_FILE = "chunks_meta.json"


class VectorStore:
    def __init__(self, index, metadata: list[dict]) -> None:
        self._index = index
        self._metadata = metadata

    @staticmethod
    def exists(index_dir: str) -> bool:
        d = Path(index_dir)
        return (d / _INDEX_FILE).exists() and (d / _META_FILE).exists()

    @classmethod
    def build(cls, records: list[ChunkRecord], embed_fn: EmbedFn) -> VectorStore:
        """Build the FAISS index from chunk records."""
        import faiss

        texts = [r.text for r in records]
        embeddings = embed_fn(texts)
        dim = len(embeddings[0])
        matrix = np.array(embeddings, dtype=np.float32)
        # Normalise for cosine similarity via inner product
        faiss.normalize_L2(matrix)
        index = faiss.IndexFlatIP(dim)
        index.add(matrix)

        metadata = [
            {"doc_id": r.doc_id, "title": r.title, "section": r.section, "text": r.text}
            for r in records
        ]
        log.info("built FAISS index: %d vectors, dim=%d", index.ntotal, dim)
        return cls(index, metadata)

    def save(self, index_dir: str) -> None:
        import faiss

        d = Path(index_dir)
        d.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(d / _INDEX_FILE))
        (d / _META_FILE).write_text(
            json.dumps(self._metadata, ensure_ascii=False), encoding="utf-8"
        )
        log.info("saved index to %s (%d vectors)", index_dir, self._index.ntotal)

    @classmethod
    def load(cls, index_dir: str) -> VectorStore:
        import faiss

        d = Path(index_dir)
        index = faiss.read_index(str(d / _INDEX_FILE))
        metadata = json.loads((d / _META_FILE).read_text(encoding="utf-8"))
        log.info("loaded FAISS index from %s (%d vectors)", index_dir, index.ntotal)
        return cls(index, metadata)

    def search(self, query_embedding: list[float], k: int = 8) -> list[Chunk]:
        """Return the top-k chunks by cosine similarity."""
        import faiss

        q = np.array([query_embedding], dtype=np.float32)
        faiss.normalize_L2(q)
        scores, indices = self._index.search(q, min(k, self._index.ntotal))

        chunks: list[Chunk] = []
        for score, idx in zip(scores[0], indices[0], strict=False):
            if idx < 0:
                continue
            meta = self._metadata[idx]
            chunks.append(
                Chunk(
                    doc_id=meta["doc_id"],
                    title=meta["title"],
                    section=meta["section"],
                    text=meta["text"],
                    score=float(score),
                    source="dense",
                )
            )
        return chunks

    @property
    def size(self) -> int:
        return self._index.ntotal

"""ChromaDB vector store: persistent vector database for SOPs and Runbooks."""

from __future__ import annotations

import logging
from pathlib import Path

from telecom_agent.core.types import Chunk
from telecom_agent.rag.embeddings import EmbedFn
from telecom_agent.rag.schemas import ChunkRecord

log = logging.getLogger(__name__)

_COLLECTION_NAME = "network_sops"


class VectorStore:
    def __init__(self, client, collection) -> None:
        self._client = client
        self._collection = collection

    @staticmethod
    def exists(index_dir: str) -> bool:
        d = Path(index_dir) / "chroma"
        return d.exists() and any(d.iterdir())

    @classmethod
    def build(cls, records: list[ChunkRecord], embed_fn: EmbedFn, index_dir: str = "./data/index") -> VectorStore:
        """Build ChromaDB persistent collection from chunk records."""
        import chromadb

        d = Path(index_dir) / "chroma"
        d.mkdir(parents=True, exist_ok=True)
        client = chromadb.PersistentClient(path=str(d))

        # Recreate collection cleanly
        try:
            client.delete_collection(_COLLECTION_NAME)
        except Exception:
            pass

        collection = client.create_collection(name=_COLLECTION_NAME, metadata={"hnsw:space": "cosine"})

        if records:
            texts = [r.text for r in records]
            embeddings = embed_fn(texts)
            ids = [f"{r.doc_id}_{r.section}_{idx}" for idx, r in enumerate(records)]
            metadatas = [
                {"doc_id": r.doc_id, "title": r.title, "section": r.section}
                for r in records
            ]
            collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=texts,
                metadatas=metadatas,
            )

        log.info("built ChromaDB collection %s with %d records", _COLLECTION_NAME, len(records))
        return cls(client, collection)

    def save(self, index_dir: str) -> None:
        # ChromaDB PersistentClient auto-persists to disk
        log.info("ChromaDB automatically persisted at %s", index_dir)

    @classmethod
    def load(cls, index_dir: str = "./data/index", embed_fn: EmbedFn | None = None) -> VectorStore:
        import chromadb

        d = Path(index_dir) / "chroma"
        client = chromadb.PersistentClient(path=str(d))
        collection = client.get_or_create_collection(name=_COLLECTION_NAME, metadata={"hnsw:space": "cosine"})
        log.info("loaded ChromaDB collection %s from %s", _COLLECTION_NAME, d)
        return cls(client, collection)

    def search(self, query_embedding: list[float], k: int = 8) -> list[Chunk]:
        """Return the top-k chunks by vector similarity."""
        count = self._collection.count()
        if count == 0:
            return []

        results = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(k, count),
            include=["documents", "metadatas", "distances"],
        )

        chunks: list[Chunk] = []
        if results and results.get("documents"):
            docs = results["documents"][0]
            metas = results["metadatas"][0]
            dists = results["distances"][0] if "distances" in results else [0.0] * len(docs)

            for doc, meta, dist in zip(docs, metas, dists, strict=False):
                # Convert distance to similarity score in [0, 1]
                score = round(max(0.0, 1.0 - float(dist)), 4)
                chunks.append(
                    Chunk(
                        doc_id=str(meta.get("doc_id", "SOP-001")),
                        title=str(meta.get("title", "Network Guide")),
                        section=str(meta.get("section", "1.0")),
                        text=doc,
                        score=score,
                        source="dense",
                    )
                )
        return chunks

    @property
    def size(self) -> int:
        return self._collection.count()

        chunks: list[Chunk] = []
        for score, idx in zip(scores[0], indices[0], strict=False):
            if idx < 0:
                continue
            meta = self._metadata[idx]
            chunks.append(
                Chunk(
                    doc_id=meta["doc_id"],
                    title=meta["title"],
                    section=meta["section"],
                    text=meta["text"],
                    score=float(score),
                    source="dense",
                )
            )
        return chunks

    @property
    def size(self) -> int:
        return self._index.ntotal

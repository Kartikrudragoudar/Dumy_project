"""BM25 keyword index for sparse retrieval."""

from __future__ import annotations

import json
import logging
import pickle
import re
from pathlib import Path

from telecom_agent.core.types import Chunk
from telecom_agent.rag.schemas import ChunkRecord

log = logging.getLogger(__name__)

_BM25_FILE = "bm25.pkl"
_BM25_META = "bm25_meta.json"

# Simple tokeniser for BM25
_TOKEN_RE = re.compile(r"[a-z0-9]+")
_STOPWORDS = frozenset(
    "a an and are as at be been but by did do does for from had has have how "
    "i if in into is it its my no not of on or so that the their them then "
    "there this to was were what when where which who will with you your".split()
)


def _tokenize(text: str) -> list[str]:
    return [w for w in _TOKEN_RE.findall(text.lower()) if w not in _STOPWORDS and len(w) >= 2]


class KeywordIndex:
    def __init__(self, bm25, metadata: list[dict]) -> None:
        self._bm25 = bm25
        self._metadata = metadata

    @classmethod
    def build(cls, records: list[ChunkRecord]) -> KeywordIndex:
        from rank_bm25 import BM25Okapi

        corpus = [_tokenize(r.text) for r in records]
        bm25 = BM25Okapi(corpus)
        metadata = [
            {"doc_id": r.doc_id, "title": r.title, "section": r.section, "text": r.text}
            for r in records
        ]
        log.info("built BM25 index: %d documents", len(corpus))
        return cls(bm25, metadata)

    def save(self, index_dir: str) -> None:
        d = Path(index_dir)
        d.mkdir(parents=True, exist_ok=True)
        with open(d / _BM25_FILE, "wb") as f:
            pickle.dump(self._bm25, f)
        (d / _BM25_META).write_text(
            json.dumps(self._metadata, ensure_ascii=False), encoding="utf-8"
        )

    @classmethod
    def load(cls, index_dir: str) -> KeywordIndex:
        d = Path(index_dir)
        with open(d / _BM25_FILE, "rb") as f:
            bm25 = pickle.load(f)  # noqa: S301 — trusted local file
        metadata = json.loads((d / _BM25_META).read_text(encoding="utf-8"))
        log.info("loaded BM25 index from %s (%d docs)", index_dir, len(metadata))
        return cls(bm25, metadata)

    def search(self, query: str, k: int = 8) -> list[Chunk]:
        tokens = _tokenize(query)
        if not tokens:
            return []
        scores = self._bm25.get_scores(tokens)
        top_k = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:k]

        # Normalise BM25 scores to [0, 1]
        max_s = max(scores) if max(scores) > 0 else 1.0
        chunks: list[Chunk] = []
        for idx in top_k:
            if scores[idx] <= 0:
                continue
            meta = self._metadata[idx]
            chunks.append(
                Chunk(
                    doc_id=meta["doc_id"],
                    title=meta["title"],
                    section=meta["section"],
                    text=meta["text"],
                    score=float(scores[idx] / max_s),
                    source="bm25",
                )
            )
        return chunks

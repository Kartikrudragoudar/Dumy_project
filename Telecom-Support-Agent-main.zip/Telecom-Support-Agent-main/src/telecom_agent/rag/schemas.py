"""Data models for the RAG pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field

from telecom_agent.core.types import Chunk, Citation


@dataclass
class RetrievalResult:
    """Unified result from any retrieval method."""

    chunks: list[Chunk] = field(default_factory=list)
    max_score: float = 0.0

    def to_citations(self) -> list[Citation]:
        return [
            Citation(doc_id=c.doc_id, title=c.title, section=c.section, score=c.score)
            for c in self.chunks
        ]


@dataclass
class Document:
    """A raw document before chunking."""

    doc_id: str
    title: str
    text: str
    metadata: dict = field(default_factory=dict)


@dataclass
class ChunkRecord:
    """A chunk with its embedding, ready for indexing."""

    doc_id: str
    title: str
    section: str
    text: str
    embedding: list[float] = field(default_factory=list)

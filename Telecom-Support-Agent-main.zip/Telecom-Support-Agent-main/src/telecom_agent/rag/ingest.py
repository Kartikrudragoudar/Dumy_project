"""Ingestion pipeline: load docs → chunk → embed → build FAISS + BM25 indexes."""

from __future__ import annotations

import logging
from pathlib import Path

from telecom_agent.config.settings import Settings
from telecom_agent.rag.chunking import ChunkingConfig, chunk_documents
from telecom_agent.rag.embeddings import EmbedFn, get_embedder
from telecom_agent.rag.keyword_index import KeywordIndex
from telecom_agent.rag.loaders import load_directory
from telecom_agent.rag.vector_store import VectorStore

log = logging.getLogger(__name__)


def ingest(
    kb_dir: str,
    index_dir: str,
    settings: Settings,
    *,
    embed_fn: EmbedFn | None = None,
    chunking_config: ChunkingConfig | None = None,
) -> int:
    """Run the full ingestion pipeline. Returns the number of chunks indexed."""
    kb_path = Path(kb_dir)
    if not kb_path.is_dir():
        # Create a sample KB so fake mode works out of the box
        _create_sample_kb(kb_path)

    docs = load_directory(kb_dir)
    if not docs:
        log.warning("no documents found in %s; creating sample KB", kb_dir)
        _create_sample_kb(kb_path)
        docs = load_directory(kb_dir)

    records = chunk_documents(docs, chunking_config)
    log.info("chunked %d documents into %d chunks", len(docs), len(records))

    embed = embed_fn or get_embedder(settings)

    vs = VectorStore.build(records, embed)
    vs.save(index_dir)

    kw = KeywordIndex.build(records)
    kw.save(index_dir)

    log.info("ingestion complete: %d chunks indexed at %s", len(records), index_dir)
    return len(records)


def _create_sample_kb(kb_path: Path) -> None:
    """Generate enterprise network SOPs and Runbooks."""
    kb_path.mkdir(parents=True, exist_ok=True)
    articles = {
        "vpn-sop.md": (
            "# VPN SOP & Troubleshooting Guide\n\n"
            "## 1. Overview\n"
            "Standard Operating Procedure for Remote Access VPN client connectivity issues.\n\n"
            "## 2. Common Root Causes\n"
            "- Credential mismatch or expired Active Directory password.\n"
            "- Gateway IP unreachable or port 443/500 blocked by local firewall.\n"
            "- Outdated Cisco AnyConnect / GlobalProtect client version.\n\n"
            "## 3. Step-by-Step Resolution\n"
            "1. Verify active Internet connectivity by pinging 8.8.8.8.\n"
            "2. Ensure credentials are valid in Self-Service Portal.\n"
            "3. Re-install or update the VPN Client to the latest enterprise build.\n"
            "4. Check for local network captive portal or firewall restrictions.\n"
        ),
        "dns-runbook.md": (
            "# DNS Operations Runbook\n\n"
            "## 1. Diagnostic Steps\n"
            "1. Execute `nslookup internal-service.local` to test DNS resolution.\n"
            "2. Flush local DNS cache using `ipconfig /flushdns` (Windows) or `sudo dscacheutil -flushcache` (macOS).\n"
            "3. Verify primary and secondary DNS server IPs in Network Adapter properties.\n\n"
            "## 2. Misconfiguration Remediation\n"
            "If public websites load by IP but not by hostname, override DNS servers to 1.1.1.1 or internal enterprise DNS.\n"
        ),
        "wifi-troubleshooting.md": (
            "# Enterprise WiFi Troubleshooting Guide\n\n"
            "## 1. Scope & Verification\n"
            "Determine if the issue affects a single device or all nearby users in the floor/building.\n\n"
            "## 2. Resolution Steps\n"
            "1. Check SSID visibility and signal strength (RSSI > -65 dBm required).\n"
            "2. Forget the WiFi network profile and re-authenticate via WPA3-Enterprise 802.1X.\n"
            "3. Verify DHCP scope availability on the local Access Point controller.\n"
        ),
        "router-manual.md": (
            "# Branch Router & Gateway Manual\n\n"
            "## 1. LED Status Diagnostics\n"
            "- Power LED: Solid Green = Normal | Flashing Red = Firmware Fault.\n"
            "- LOS Light: Solid Red = Optical Fiber Break / ISP Outage.\n"
            "- WAN Light: Blinking Green = Active Traffic | Off = Link Down.\n\n"
            "## 2. Power Cycle Procedure\n"
            "Disconnect power cable for 30 seconds, reconnect, and allow 3 minutes for optical sync.\n"
        ),
        "network-operations-manual.md": (
            "# Network Operations Center (NOC) Playbook\n\n"
            "## 1. Outage Classification\n"
            "- Single User Issue: Priority LOW / Level 1 (Service Desk).\n"
            "- Multi-User / Floor Degradation: Priority HIGH / Level 2 (NOC L2).\n"
            "- Regional Core Outage / Gateway Failure: Priority CRITICAL / Level 3 (Network Ops L3).\n"
        ),
    }
            "1. Toggle airplane mode for 10 seconds.\n"
            "2. Ensure VoLTE is enabled: Settings → Mobile Networks → VoLTE toggle.\n"
            "3. Check if the issue is location-specific by testing outdoors.\n"
            "4. Update the device software to the latest version.\n\n"
            "## 3. When to Escalate\n"
            "Escalate if the customer reports frequent drops (>3 per day) in a single "
            "location, or if multiple customers in the same circle report similar issues.\n"
        ),
        "kb-003-billing-dispute.md": (
            "# Billing Dispute Resolution\n\n"
            "## 1. Verification\n"
            "- Pull the last 3 billing statements from the CRM.\n"
            "- Cross-check disputed charges against the plan rate card.\n"
            "- Verify any VAS subscriptions activated in the billing period.\n\n"
            "## 2. Common Disputes\n"
            "- Double charge on recharge: usually a payment gateway retry.\n"
            "- Data overage charge: check if the customer's pack expired mid-cycle.\n"
            "- Roaming charges: verify if the customer enabled roaming packs.\n\n"
            "## 3. Resolution\n"
            "Agents may issue a courtesy credit up to ₹200 without supervisor approval. "
            "For amounts above ₹200, escalate to BILLING_OPS queue.\n"
        ),
        "kb-004-sim-activation.md": (
            "# SIM Activation & Porting\n\n"
            "## 1. New SIM Activation\n"
            "- Activation takes 2–4 hours after KYC verification.\n"
            "- Customer receives a confirmation SMS on the new number.\n"
            "- If no activation after 6 hours, check KYC status in the CRM.\n\n"
            "## 2. MNP (Mobile Number Portability)\n"
            "- Port-in request via SMS: send PORT <number> to 1900.\n"
            "- Porting window: 3–7 business days.\n"
            "- During porting, the customer retains service on the donor network.\n\n"
            "## 3. SIM Swap\n"
            "- Identity verification required (Aadhaar OTP or in-store KYC).\n"
            "- Old SIM deactivated immediately; new SIM active within 2 hours.\n"
            "- If swap fails, escalate to SIM_PROVISIONING queue.\n"
        ),
        "kb-005-roaming.md": (
            "# International Roaming\n\n"
            "## 1. Activation\n"
            "- Postpaid: roaming is available by default; activate a roaming pack "
            "via the app or by dialing *222#.\n"
            "- Prepaid: roaming packs must be purchased before departure.\n\n"
            "## 2. Troubleshooting\n"
            "1. Enable data roaming: Settings → Mobile Networks → Data Roaming.\n"
            "2. Set network selection to Automatic.\n"
            "3. If no network, manually select a partner operator from the list.\n\n"
            "## 3. Billing\n"
            "Roaming charges apply per the active pack. Without a pack, default rates "
            "are ₹50/MB data, ₹30/min outgoing calls. Advise customers to purchase "
            "a pack to avoid bill shock.\n"
        ),
        "kb-006-slow-data.md": (
            "# Slow Data / Speed Issues\n\n"
            "## 1. Diagnosis\n"
            "- Ask the customer to run a speed test (fast.com or Ookla).\n"
            "- Check if the data pack has been exhausted (post-limit speed: 64 Kbps).\n"
            "- Verify the customer is on 4G/5G, not falling back to 3G/2G.\n\n"
            "## 2. Steps\n"
            "1. Toggle airplane mode for 10 seconds.\n"
            "2. Reset APN to default (see KB-001).\n"
            "3. Clear the browser/app cache.\n"
            "4. If speeds are <1 Mbps on 4G with data remaining, escalate.\n\n"
            "## 3. Known Throttles\n"
            "Post-FUP speed is capped at 64 Kbps on all unlimited plans. Customers "
            "can purchase a speed booster add-on for ₹49/day.\n"
        ),
    }

    for filename, content in articles.items():
        (kb_path / filename).write_text(content, encoding="utf-8")
    log.info("created %d sample KB articles in %s", len(articles), kb_path)

"""Ingestion pipeline: load docs → chunk → embed → build FAISS + BM25 indexes."""

from __future__ import annotations

import logging
from pathlib import Path

from telecom_agent.config.settings import Settings
from telecom_agent.rag.chunking import ChunkingConfig, chunk_documents
from telecom_agent.rag.embeddings import EmbedFn, get_embedder
from telecom_agent.rag.keyword_index import KeywordIndex
from telecom_agent.rag.loaders import load_directory
from telecom_agent.rag.vector_store import VectorStore

log = logging.getLogger(__name__)


def ingest(
    kb_dir: str,
    index_dir: str,
    settings: Settings,
    *,
    embed_fn: EmbedFn | None = None,
    chunking_config: ChunkingConfig | None = None,
) -> int:
    """Run the full ingestion pipeline. Returns the number of chunks indexed."""
    kb_path = Path(kb_dir)
    if not kb_path.is_dir():
        # Create a sample KB so fake mode works out of the box
        _create_sample_kb(kb_path)

    docs = load_directory(kb_dir)
    if not docs:
        log.warning("no documents found in %s; creating sample KB", kb_dir)
        _create_sample_kb(kb_path)
        docs = load_directory(kb_dir)

    records = chunk_documents(docs, chunking_config)
    log.info("chunked %d documents into %d chunks", len(docs), len(records))

    embed = embed_fn or get_embedder(settings)

    vs = VectorStore.build(records, embed)
    vs.save(index_dir)

    kw = KeywordIndex.build(records)
    kw.save(index_dir)

    log.info("ingestion complete: %d chunks indexed at %s", len(records), index_dir)
    return len(records)


def _create_sample_kb(kb_path: Path) -> None:
    """Generate synthetic KB articles so the app boots without real data."""
    kb_path.mkdir(parents=True, exist_ok=True)
    articles = {
        "kb-001-apn-reset.md": (
            "# APN Reset – Android\n\n"
            "## 1. Overview\n"
            "A corrupted APN profile is the most common cause of data connectivity loss "
            "after a SIM swap or firmware update.\n\n"
            "## 2. Steps\n"
            "1. Go to Settings → Mobile Networks → Access Point Names.\n"
            "2. Tap the three-dot menu → Reset to default.\n"
            "3. Reboot the device.\n"
            "4. If data still fails, manually create an APN with:\n"
            "   - Name: Operator Internet\n"
            "   - APN: internet\n"
            "   - MCC: 404, MNC: varies by circle\n\n"
            "## 3. Escalation\n"
            "If the issue persists after APN reset and reboot, escalate to NOC L2 "
            "with the customer's circle and ICCID.\n"
        ),
        "kb-002-call-drops.md": (
            "# Call Drop Troubleshooting\n\n"
            "## 1. Common Causes\n"
            "- Weak signal in indoor areas or basements.\n"
            "- Network congestion during peak hours.\n"
            "- Handover failure between cell towers while moving.\n\n"
            "## 2. Steps\n"
            "1. Toggle airplane mode for 10 seconds.\n"
            "2. Ensure VoLTE is enabled: Settings → Mobile Networks → VoLTE toggle.\n"
            "3. Check if the issue is location-specific by testing outdoors.\n"
            "4. Update the device software to the latest version.\n\n"
            "## 3. When to Escalate\n"
            "Escalate if the customer reports frequent drops (>3 per day) in a single "
            "location, or if multiple customers in the same circle report similar issues.\n"
        ),
        "kb-003-billing-dispute.md": (
            "# Billing Dispute Resolution\n\n"
            "## 1. Verification\n"
            "- Pull the last 3 billing statements from the CRM.\n"
            "- Cross-check disputed charges against the plan rate card.\n"
            "- Verify any VAS subscriptions activated in the billing period.\n\n"
            "## 2. Common Disputes\n"
            "- Double charge on recharge: usually a payment gateway retry.\n"
            "- Data overage charge: check if the customer's pack expired mid-cycle.\n"
            "- Roaming charges: verify if the customer enabled roaming packs.\n\n"
            "## 3. Resolution\n"
            "Agents may issue a courtesy credit up to ₹200 without supervisor approval. "
            "For amounts above ₹200, escalate to BILLING_OPS queue.\n"
        ),
        "kb-004-sim-activation.md": (
            "# SIM Activation & Porting\n\n"
            "## 1. New SIM Activation\n"
            "- Activation takes 2–4 hours after KYC verification.\n"
            "- Customer receives a confirmation SMS on the new number.\n"
            "- If no activation after 6 hours, check KYC status in the CRM.\n\n"
            "## 2. MNP (Mobile Number Portability)\n"
            "- Port-in request via SMS: send PORT <number> to 1900.\n"
            "- Porting window: 3–7 business days.\n"
            "- During porting, the customer retains service on the donor network.\n\n"
            "## 3. SIM Swap\n"
            "- Identity verification required (Aadhaar OTP or in-store KYC).\n"
            "- Old SIM deactivated immediately; new SIM active within 2 hours.\n"
            "- If swap fails, escalate to SIM_PROVISIONING queue.\n"
        ),
        "kb-005-roaming.md": (
            "# International Roaming\n\n"
            "## 1. Activation\n"
            "- Postpaid: roaming is available by default; activate a roaming pack "
            "via the app or by dialing *222#.\n"
            "- Prepaid: roaming packs must be purchased before departure.\n\n"
            "## 2. Troubleshooting\n"
            "1. Enable data roaming: Settings → Mobile Networks → Data Roaming.\n"
            "2. Set network selection to Automatic.\n"
            "3. If no network, manually select a partner operator from the list.\n\n"
            "## 3. Billing\n"
            "Roaming charges apply per the active pack. Without a pack, default rates "
            "are ₹50/MB data, ₹30/min outgoing calls. Advise customers to purchase "
            "a pack to avoid bill shock.\n"
        ),
        "kb-006-slow-data.md": (
            "# Slow Data / Speed Issues\n\n"
            "## 1. Diagnosis\n"
            "- Ask the customer to run a speed test (fast.com or Ookla).\n"
            "- Check if the data pack has been exhausted (post-limit speed: 64 Kbps).\n"
            "- Verify the customer is on 4G/5G, not falling back to 3G/2G.\n\n"
            "## 2. Steps\n"
            "1. Toggle airplane mode for 10 seconds.\n"
            "2. Reset APN to default (see KB-001).\n"
            "3. Clear the browser/app cache.\n"
            "4. If speeds are <1 Mbps on 4G with data remaining, escalate.\n\n"
            "## 3. Known Throttles\n"
            "Post-FUP speed is capped at 64 Kbps on all unlimited plans. Customers "
            "can purchase a speed booster add-on for ₹49/day.\n"
        ),
    }

    for filename, content in articles.items():
        (kb_path / filename).write_text(content, encoding="utf-8")
    log.info("created %d sample KB articles in %s", len(articles), kb_path)

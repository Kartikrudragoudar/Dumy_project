"""Split documents into overlapping chunks with section numbering."""

from __future__ import annotations

import re
from dataclasses import dataclass

from telecom_agent.rag.schemas import ChunkRecord, Document


@dataclass
class ChunkingConfig:
    max_tokens: int = 300
    overlap_tokens: int = 50
    chars_per_token: int = 4


def chunk_documents(
    docs: list[Document], config: ChunkingConfig | None = None
) -> list[ChunkRecord]:
    config = config or ChunkingConfig()
    records: list[ChunkRecord] = []
    for doc in docs:
        sections = _split_sections(doc.text)
        for idx, (heading, body) in enumerate(sections, 1):
            sub_chunks = _split_by_size(body, config)
            for sub_idx, text in enumerate(sub_chunks, 1):
                section = f"{idx}.{sub_idx}" if len(sub_chunks) > 1 else str(idx)
                records.append(
                    ChunkRecord(
                        doc_id=doc.doc_id,
                        title=heading or doc.title,
                        section=section,
                        text=text.strip(),
                    )
                )
    return records


_HEADING = re.compile(r"^#{1,4}\s+(.+)", re.MULTILINE)


def _split_sections(text: str) -> list[tuple[str, str]]:
    """Split on Markdown headings. Returns (heading, body) pairs."""
    parts = _HEADING.split(text)
    if not parts:
        return [("", text)]
    sections: list[tuple[str, str]] = []
    # Text before the first heading
    if parts[0].strip():
        sections.append(("", parts[0]))
    # Heading/body pairs
    for i in range(1, len(parts), 2):
        heading = parts[i].strip() if i < len(parts) else ""
        body = parts[i + 1] if i + 1 < len(parts) else ""
        if body.strip():
            sections.append((heading, body))
    return sections or [("", text)]


def _split_by_size(text: str, config: ChunkingConfig) -> list[str]:
    """Split text into chunks of approximately max_tokens with overlap."""
    max_chars = config.max_tokens * config.chars_per_token
    overlap_chars = config.overlap_tokens * config.chars_per_token

    if len(text) <= max_chars:
        return [text] if text.strip() else []

    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = start + max_chars
        # Try to break at a paragraph or sentence boundary
        if end < len(text):
            for sep in ["\n\n", "\n", ". ", " "]:
                brk = text.rfind(sep, start + max_chars // 2, end)
                if brk > start:
                    end = brk + len(sep)
                    break
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - overlap_chars
    return chunks

"""Single source of truth for every taxonomy in the system.

Nothing else in the codebase is allowed to define these string values inline. A node,
a prompt renderer, a routing table and an eval runner must all agree on the exact same
set of categories, priorities, queues and providers — so they all import from here.
"""

from __future__ import annotations

from enum import Enum


class StrEnum(str, Enum):
    """str + Enum so values JSON-serialise as their plain string form."""

    def __str__(self) -> str:  # pragma: no cover - trivial
        return str(self.value)


class NetworkIntent(StrEnum):
    INTERNET_DOWN = "internet_down"
    SLOW_INTERNET = "slow_internet"
    WIFI_ISSUE = "wifi_issue"
    VPN_ISSUE = "vpn_issue"
    DNS_ISSUE = "dns_issue"
    ROUTER_ISSUE = "router_issue"
    FIREWALL_ISSUE = "firewall_issue"
    EMAIL_ISSUE = "email_issue"
    ACCOUNT_ACCESS_ISSUE = "account_access_issue"
    NETWORK_OUTAGE = "network_outage"
    UNKNOWN = "unknown"


class DiagnosticRoute(StrEnum):
    VPN_DIAGNOSTIC = "vpn_diagnostic"
    WIFI_DIAGNOSTIC = "wifi_diagnostic"
    DNS_DIAGNOSTIC = "dns_diagnostic"
    ROUTER_DIAGNOSTIC = "router_diagnostic"
    CONNECTIVITY_DIAGNOSTIC = "connectivity_diagnostic"
    RAG_DIRECT = "rag_direct"


class IssueCategory(StrEnum):
    INTERNET_DOWN = "internet_down"
    SLOW_INTERNET = "slow_internet"
    WIFI_ISSUE = "wifi_issue"
    VPN_ISSUE = "vpn_issue"
    DNS_ISSUE = "dns_issue"
    ROUTER_ISSUE = "router_issue"
    FIREWALL_ISSUE = "firewall_issue"
    EMAIL_ISSUE = "email_issue"
    ACCOUNT_ACCESS_ISSUE = "account_access_issue"
    NETWORK_OUTAGE = "network_outage"
    OTHER = "other"


class Priority(StrEnum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"
    P4 = "P4"


class EscalationLevel(StrEnum):
    LEVEL_1 = "L1"
    LEVEL_2 = "L2"
    LEVEL_3 = "L3"


class EscalationQueue(StrEnum):
    NETWORK_OPERATIONS = "Network Operations"
    SECURITY_OPS = "Security Operations"
    SYSTEM_ADMIN = "System Administration"
    DESK_SUPPORT = "Service Desk L1"
    NOC_L2 = "NOC_L2"
    BILLING_OPS = "BILLING_OPS"


class Resolution(StrEnum):
    RESOLVED = "RESOLVED"
    NEEDS_INFO = "NEEDS_INFO"
    ESCALATED = "ESCALATED"


class Provider(StrEnum):
    AZURE_FOUNDRY = "AZURE_FOUNDRY"
    GROQ = "GROQ"
    FAKE = "FAKE"


class Alias(StrEnum):
    """Stable model aliases used everywhere in code; mapped to concrete model ids
    per provider in ``llm/aliases.py``. A model upgrade is a portal/config change,
    never a code change."""

    CHAT_MAIN = "chat-main"
    CHAT_MINI = "chat-mini"
    EMBED = "embed"


class TicketStatus(StrEnum):
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


# Convenience: all category / priority / queue string values, handy for validators & evals.
CATEGORY_VALUES = tuple(c.value for c in IssueCategory)
PRIORITY_VALUES = tuple(p.value for p in Priority)
QUEUE_VALUES = tuple(q.value for q in EscalationQueue)
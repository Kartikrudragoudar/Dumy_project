"""You cannot debug or grade what you cannot see. Wired from the start, not bolted on."""

from telecom_agent.observability.cost import estimate_cost
from telecom_agent.observability.logging import RedactionFilter, bind, configure_logging, redact
from telecom_agent.observability.telemetry import configure_azure_monitor, instrument_fastapi

__all__ = [
    "RedactionFilter",
    "bind",
    "configure_azure_monitor",
    "configure_logging",
    "estimate_cost",
    "instrument_fastapi",
    "redact",
]

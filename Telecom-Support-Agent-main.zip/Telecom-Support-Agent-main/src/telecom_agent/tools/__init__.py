"""Side-effecting functions the agent may call. Tools never make LLM calls."""

from telecom_agent.tools.diagnostics import check_outage
from telecom_agent.tools.kb_search import KbSearchTool
from telecom_agent.tools.registry import ToolRegistry, ToolSpec, build_registry
from telecom_agent.tools.ticketing import TicketingTool
from telecom_agent.tools.validators import clean_text, coerce_category, coerce_priority, coerce_queue

__all__ = [
    "KbSearchTool",
    "TicketingTool",
    "ToolRegistry",
    "ToolSpec",
    "build_registry",
    "check_outage",
    "clean_text",
    "coerce_category",
    "coerce_priority",
    "coerce_queue",
]

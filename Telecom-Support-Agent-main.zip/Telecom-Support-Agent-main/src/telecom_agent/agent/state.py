"""``TriageState`` — the single shared contract every graph node reads and updates.

Frozen at end of Day 1. Nodes return a *partial* update of this object and never mutate
globals. Keys mirror README §3.2 exactly.
"""

from __future__ import annotations

from typing import Annotated, TypedDict

from telecom_agent.core.enums import (
    EscalationQueue,
    IssueCategory,
    Priority,
    Provider,
    Resolution,
)
from telecom_agent.core.types import (
    Chunk,
    Citation,
    CustomerCtx,
    Message,
    Ticket,
    TokenUsage,
)


def _accumulate_usage(existing: TokenUsage | None, update: TokenUsage | None) -> TokenUsage:
    """LangGraph reducer: token usage is *summed* across nodes within a turn rather than
    overwritten, so per-turn cost is the total of every LLM call the graph made."""
    if existing is None:
        return update or TokenUsage()
    if update is None:
        return existing
    return existing.add(update)


class TriageState(TypedDict, total=False):
    # --- identity & tracing ---
    session_id: str
    trace_id: str
    # --- provider pinning ---
    provider: Provider
    degraded: bool
    # --- conversation ---
    messages: list[Message]
    customer_ctx: CustomerCtx
    user_input: str
    # --- multi-agent hierarchy state ---
    intent: str
    confidence: float
    affected_service: str
    priority: str
    category: IssueCategory | str
    diagnostic_route: str
    diagnostic_summary: str
    diagnostic_questions: list[str]
    # --- retrieval output ---
    retrieved: list[Chunk]
    citations: list[Citation]
    rag_context: str
    # --- generation & resolution ---
    draft: str
    groundedness: float
    attempt: int
    root_cause: str
    resolution_steps: list[str]
    resolved: bool
    # --- escalation & ticketing ---
    escalation_level: str
    assigned_team: str
    resolution: Resolution
    answer: str
    ticket: Ticket | None
    queue: EscalationQueue | str | None
    clarify_question: str
    error_code: str
    # --- budget ---
    token_usage: Annotated[TokenUsage, _accumulate_usage]

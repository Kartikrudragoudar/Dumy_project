"""Diagnostic Router Agent & Multi-Agent Node Implementations."""

from __future__ import annotations

import json
from telecom_agent.agent.deps import AgentDeps
from telecom_agent.agent.nodes._shared import extract_json, node_messages, track_usage
from telecom_agent.agent.state import TriageState
from telecom_agent.core.enums import Alias, DiagnosticRoute, NetworkIntent, Priority
from telecom_agent.core.types import IntentOutput, TokenUsage
from telecom_agent.observability.logging import bind
from telecom_agent.prompts import registry


def intent_classification_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 1: Intent Classification Agent."""
    session_id = state["session_id"]
    user_input = state.get("user_input", "")
    log = bind(__name__, trace_id=state.get("trace_id", ""), session_id=session_id, node="intent_classifier")

    node_system = registry.render("intent", "v1", user_input=user_input)
    messages = node_messages(deps.settings.system_version, node_system, user_input)

    try:
        result = deps.router.chat(session_id, messages, alias=Alias.CHAT_MINI, json_mode=True)
        usage = track_usage("intent_classifier", result)
        data = extract_json(result.text)
        out = IntentOutput.model_validate(data)
    except Exception as exc:
        log.warning("Intent classification failed (%s), defaulting to unknown", exc)
        out = IntentOutput(intent=NetworkIntent.UNKNOWN, confidence=0.5, affected_service="general", priority=Priority.MEDIUM)
        usage = TokenUsage()

    return {
        "intent": out.intent,
        "confidence": out.confidence,
        "affected_service": out.affected_service,
        "priority": out.priority,
        "category": out.intent,
        "token_usage": usage,
    }


def diagnostic_router_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 2: Diagnostic Router Agent."""
    intent = state.get("intent", NetworkIntent.UNKNOWN)
    
    route_map = {
        NetworkIntent.VPN_ISSUE: DiagnosticRoute.VPN_DIAGNOSTIC,
        NetworkIntent.WIFI_ISSUE: DiagnosticRoute.WIFI_DIAGNOSTIC,
        NetworkIntent.DNS_ISSUE: DiagnosticRoute.DNS_DIAGNOSTIC,
        NetworkIntent.ROUTER_ISSUE: DiagnosticRoute.ROUTER_DIAGNOSTIC,
        NetworkIntent.INTERNET_DOWN: DiagnosticRoute.CONNECTIVITY_DIAGNOSTIC,
        NetworkIntent.SLOW_INTERNET: DiagnosticRoute.CONNECTIVITY_DIAGNOSTIC,
        NetworkIntent.NETWORK_OUTAGE: DiagnosticRoute.CONNECTIVITY_DIAGNOSTIC,
    }

    selected_route = route_map.get(intent, DiagnosticRoute.RAG_DIRECT)
    return {"diagnostic_route": selected_route}


def specialized_diagnostic_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 3A-3E: Specialized Diagnostic Agents."""
    session_id = state["session_id"]
    user_input = state.get("user_input", "")
    route = state.get("diagnostic_route", DiagnosticRoute.CONNECTIVITY_DIAGNOSTIC)
    
    agent_names = {
        DiagnosticRoute.VPN_DIAGNOSTIC: "VPN Diagnostic Agent",
        DiagnosticRoute.WIFI_DIAGNOSTIC: "WiFi Diagnostic Agent",
        DiagnosticRoute.DNS_DIAGNOSTIC: "DNS Diagnostic Agent",
        DiagnosticRoute.ROUTER_DIAGNOSTIC: "Router Diagnostic Agent",
        DiagnosticRoute.CONNECTIVITY_DIAGNOSTIC: "Connectivity Diagnostic Agent",
    }
    agent_name = agent_names.get(route, "Connectivity Diagnostic Agent")

    node_system = registry.render(
        "diagnostic", "v1", agent_type=agent_name, user_input=user_input, intent=state.get("intent", "unknown")
    )
    messages = node_messages(deps.settings.system_version, node_system, user_input)

    try:
        result = deps.router.chat(session_id, messages, alias=Alias.CHAT_MINI)
        usage = track_usage("specialized_diagnostic", result)
        summary = result.text.strip()
    except Exception:
        summary = f"[{agent_name}] Diagnostic check complete for {user_input[:100]}."
        usage = TokenUsage()

    return {
        "diagnostic_summary": summary,
        "token_usage": usage,
    }


def rag_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 4: RAG Agent - Query ChromaDB Vector Database for SOPs."""
    query = f"{state.get('intent', '')} {state.get('user_input', '')}"
    
    result = deps.retriever.search(query, k=deps.settings.retrieval_top_k)
    
    formatted_context = "\n\n".join(
        [f"[{c.doc_id} §{c.section}] {c.title}\n{c.text}" for c in result.chunks]
    )

    return {
        "retrieved": result.chunks,
        "citations": result.to_citations(),
        "rag_context": formatted_context,
    }


def resolution_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 5: Resolution Agent."""
    session_id = state["session_id"]
    user_input = state.get("user_input", "")
    diag_summary = state.get("diagnostic_summary", "")
    sop_context = state.get("rag_context", "")

    node_system = registry.render(
        "resolution", "v1", user_input=user_input, diagnostic_summary=diag_summary, sop_context=sop_context
    )
    messages = node_messages(deps.settings.system_version, node_system, user_input)

    try:
        result = deps.router.chat(session_id, messages, alias=Alias.CHAT_MAIN)
        usage = track_usage("resolution_agent", result)
        draft = result.text.strip()
    except Exception:
        draft = "Resolution Steps:\n1. Verify physical cables\n2. Power cycle device\n3. Contact NOC"
        usage = TokenUsage()

    # Determine if issue is resolved or needs escalation
    resolved = "resolved" in draft.lower() or state.get("confidence", 0.0) >= 0.85

    return {
        "draft": draft,
        "answer": draft,
        "resolved": resolved,
        "token_usage": usage,
    }


def ticket_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 6: Ticket Agent."""
    session_id = state["session_id"]
    category = state.get("category", "General")
    priority = state.get("priority", "Medium")
    summary = f"[{priority}/{category}] {state.get('user_input', '')[:200]}"

    ticket = deps.ticketing.create_ticket(
        session_id=session_id,
        category=category,
        priority=priority,
        queue=state.get("assigned_team", "Service Desk L1"),
        summary=summary,
        trace_id=state.get("trace_id", ""),
    )

    return {"ticket": ticket}


def escalation_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Agent 7: Escalation Agent."""
    session_id = state["session_id"]
    user_input = state.get("user_input", "")
    intent = state.get("intent", "unknown")
    priority = state.get("priority", "Medium")

    node_system = registry.render("escalation", "v1", user_input=user_input, intent=intent, priority=priority)
    messages = node_messages(deps.settings.system_version, node_system, user_input)

    try:
        result = deps.router.chat(session_id, messages, alias=Alias.CHAT_MINI, json_mode=True)
        usage = track_usage("escalation_agent", result)
        data = extract_json(result.text)
        escalation_level = data.get("escalation_level", "L1")
        assigned_team = data.get("assigned_team", "Service Desk L1")
    except Exception:
        escalation_level = "L1"
        assigned_team = "Service Desk L1"
        usage = TokenUsage()

    return {
        "escalation_level": escalation_level,
        "assigned_team": assigned_team,
        "queue": assigned_team,
        "token_usage": usage,
    }


def supervisor_agent(state: TriageState, deps: AgentDeps) -> dict:
    """Supervisor Agent: Orchestrates final synthesis."""
    session_id = state["session_id"]
    user_input = state.get("user_input", "")
    intent = state.get("intent", "general")
    diag_summary = state.get("diagnostic_summary", "Diagnostics completed.")
    rag_context = state.get("rag_context", "")

    node_system = registry.render(
        "supervisor", "v1", user_input=user_input, current_intent=intent, diagnostic_summary=diag_summary, rag_context=rag_context
    )
    messages = node_messages(deps.settings.system_version, node_system, user_input)

    try:
        result = deps.router.chat(session_id, messages, alias=Alias.CHAT_MAIN)
        usage = track_usage("supervisor_agent", result)
        final_answer = result.text.strip()
    except Exception:
        final_answer = state.get("draft", "Network diagnostics process finished.")
        usage = TokenUsage()

    return {
        "answer": final_answer,
        "token_usage": usage,
    }

"""Builds and compiles the LangGraph.

Only this file wires edges — nodes live one-per-file so five people can add nodes without
colliding in ``graph.py`` (README §19 merge-conflict mitigation). Nodes are bound to the
shared :class:`AgentDeps` via ``partial`` so they stay ``(state) -> dict`` for LangGraph
while still receiving their collaborators.
"""

from __future__ import annotations

from functools import partial

from langgraph.graph import END, StateGraph

from telecom_agent.agent.deps import AgentDeps
from telecom_agent.agent.edges import after_classify, after_retrieve, after_verify
from telecom_agent.agent.nodes.clarify import clarify
from telecom_agent.agent.nodes.classify import classify
from telecom_agent.agent.nodes.draft_answer import draft_answer
from telecom_agent.agent.nodes.escalate import escalate
from telecom_agent.agent.nodes.load_session import load_session
from telecom_agent.agent.nodes.persist import persist
from telecom_agent.agent.nodes.respond import respond
from telecom_agent.agent.nodes.retrieve import retrieve
from telecom_agent.agent.nodes.verify import verify
from telecom_agent.agent.state import TriageState


from telecom_agent.agent.multi_agent import (
    diagnostic_router_agent,
    escalation_agent,
    intent_classification_agent,
    rag_agent,
    resolution_agent,
    specialized_diagnostic_agent,
    supervisor_agent,
    ticket_agent,
)
from telecom_agent.agent.nodes.load_session import load_session
from telecom_agent.agent.nodes.persist import persist
from telecom_agent.agent.state import TriageState


def after_resolution(state: TriageState) -> str:
    """Check if issue was resolved by Resolution Agent; if resolved, close case; if unresolved, open ticket & escalate."""
    if state.get("resolved"):
        return "supervisor_agent"
    return "ticket_agent"


def build_graph(deps: AgentDeps):
    g = StateGraph(TriageState)

    # Multi-agent hierarchy nodes
    g.add_node("load_session", partial(load_session, deps=deps))
    g.add_node("intent_classification_agent", partial(intent_classification_agent, deps=deps))
    g.add_node("diagnostic_router_agent", partial(diagnostic_router_agent, deps=deps))
    g.add_node("specialized_diagnostic_agent", partial(specialized_diagnostic_agent, deps=deps))
    g.add_node("rag_agent", partial(rag_agent, deps=deps))
    g.add_node("resolution_agent", partial(resolution_agent, deps=deps))
    g.add_node("ticket_agent", partial(ticket_agent, deps=deps))
    g.add_node("escalation_agent", partial(escalation_agent, deps=deps))
    g.add_node("supervisor_agent", partial(supervisor_agent, deps=deps))
    g.add_node("persist", partial(persist, deps=deps))

    g.set_entry_point("load_session")
    g.add_edge("load_session", "intent_classification_agent")
    g.add_edge("intent_classification_agent", "diagnostic_router_agent")
    g.add_edge("diagnostic_router_agent", "specialized_diagnostic_agent")
    g.add_edge("specialized_diagnostic_agent", "rag_agent")
    g.add_edge("rag_agent", "resolution_agent")

    g.add_conditional_edges(
        "resolution_agent",
        after_resolution,
        {
            "supervisor_agent": "supervisor_agent",
            "ticket_agent": "ticket_agent",
        },
    )

    g.add_edge("ticket_agent", "escalation_agent")
    g.add_edge("escalation_agent", "supervisor_agent")
    g.add_edge("supervisor_agent", "persist")
    g.add_edge("persist", END)

    return g.compile()

"""Streamlit session state helpers."""

from __future__ import annotations

import uuid

import streamlit as st

from ui.api_client import ApiClient


def init_state() -> None:
    """Initialize session state keys on first load."""
    if "session_id" not in st.session_state:
        st.session_state.session_id = f"sess_{uuid.uuid4().hex[:8]}"
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "client" not in st.session_state:
        st.session_state.client = ApiClient()
    if "degraded" not in st.session_state:
        st.session_state.degraded = False


def reset_chat() -> None:
    """Start a new conversation."""
    st.session_state.session_id = f"sess_{uuid.uuid4().hex[:8]}"
    st.session_state.messages = []
    st.session_state.degraded = False

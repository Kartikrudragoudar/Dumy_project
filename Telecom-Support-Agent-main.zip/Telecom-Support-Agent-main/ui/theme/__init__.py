"""Obsidian Flux theme utilities for NOC Multi-Agent Assistant."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

# ── Color tokens ─────────────────────────────────────────────────────────────
SURFACE = "#0b1326"
SURFACE_CONTAINER = "#171f33"
SURFACE_CONTAINER_HIGH = "#222a3d"
SURFACE_CONTAINER_HIGHEST = "#2d3449"
ON_SURFACE = "#dae2fd"
ON_SURFACE_VARIANT = "#c7c4d7"
OUTLINE = "#908fa0"
OUTLINE_VARIANT = "#464554"
PRIMARY = "#c0c1ff"
PRIMARY_CONTAINER = "#8083ff"
SECONDARY = "#b4c5ff"
TERTIARY = "#4ae176"
ERROR = "#ffb4ab"
ERROR_CONTAINER = "#93000a"


def inject_css() -> None:
    """Inject the Obsidian Flux stylesheet into the current page."""
    css_path = Path(__file__).parent / "styles.css"
    if css_path.exists():
        st.markdown(f"<style>{css_path.read_text()}</style>", unsafe_allow_html=True)


def page_setup(title: str, icon: str = "🌐", layout: str = "wide") -> None:
    """Common page config + CSS injection."""
    st.set_page_config(page_title=f"NOC — {title}", page_icon=icon, layout=layout)
    inject_css()


# ── Reusable HTML components ────────────────────────────────────────────────

def noc_header(title: str, subtitle: str = "", badge: str = "") -> None:
    """Render a page header with optional subtitle and badge."""
    badge_html = f'<span style="background:rgba(192,193,255,0.15);color:#c0c1ff;border:1px solid rgba(192,193,255,0.3);padding:2px 10px;border-radius:9999px;font-family:JetBrains Mono,monospace;font-size:11px;margin-left:12px;">{badge}</span>' if badge else ""
    sub_html = f'<p style="color:#c7c4d7;font-size:14px;margin:4px 0 0 0;">{subtitle}</p>' if subtitle else ""
    st.markdown(f"""
    <div style="margin-bottom:20px;">
        <h1 style="margin:0;font-size:28px;color:#dae2fd;">{title}{badge_html}</h1>
        {sub_html}
    </div>
    """, unsafe_allow_html=True)


def kpi_card(label: str, value: str, delta: str = "", icon: str = "", color: str = PRIMARY) -> str:
    """Return HTML for a KPI metric card."""
    delta_html = ""
    if delta:
        is_up = delta.startswith("+") or delta.startswith("↑")
        d_color = TERTIARY if is_up else ERROR
        delta_html = f'<div style="font-family:JetBrains Mono,monospace;font-size:12px;color:{d_color};margin-top:4px;">{delta}</div>'
    icon_html = f'<span style="font-size:20px;margin-right:8px;">{icon}</span>' if icon else ""
    return f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;height:100%;">
        <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;color:{ON_SURFACE_VARIANT};margin-bottom:8px;">{icon_html}{label}</div>
        <div style="font-family:JetBrains Mono,monospace;font-size:28px;font-weight:700;color:{color};">{value}</div>
        {delta_html}
    </div>
    """


def status_badge(text: str, variant: str = "blue") -> str:
    """Return HTML for a status badge. variant: green|red|blue|purple|gray"""
    colors = {
        "green": ("rgba(74,225,118,0.15)", "#4ae176", "rgba(74,225,118,0.3)"),
        "red": ("rgba(147,0,10,0.3)", "#ffb4ab", "rgba(255,180,171,0.3)"),
        "blue": ("rgba(180,197,255,0.15)", "#b4c5ff", "rgba(180,197,255,0.3)"),
        "purple": ("rgba(192,193,255,0.15)", "#c0c1ff", "rgba(192,193,255,0.3)"),
        "gray": ("rgba(144,143,160,0.15)", "#908fa0", "rgba(144,143,160,0.3)"),
    }
    bg, fg, bd = colors.get(variant, colors["blue"])
    return f'<span style="display:inline-block;padding:2px 10px;border-radius:9999px;font-family:JetBrains Mono,monospace;font-size:11px;font-weight:500;background:{bg};color:{fg};border:1px solid {bd};">{text}</span>'


def card(content: str, border_color: str = OUTLINE_VARIANT) -> str:
    """Wrap content in a card div."""
    return f'<div style="background:{SURFACE_CONTAINER};border:1px solid {border_color};border-radius:12px;padding:16px 20px;margin-bottom:12px;">{content}</div>'


def terminal_block(lines: list[str]) -> str:
    """Render a terminal-style block."""
    content = "<br>".join(lines)
    return f"""
    <div style="background:#000;border:1px solid {OUTLINE_VARIANT};border-radius:8px;padding:12px 16px;font-family:JetBrains Mono,monospace;font-size:12px;color:{TERTIARY};max-height:300px;overflow-y:auto;line-height:1.6;">
        {content}
    </div>
    """


def data_label(label: str, value: str) -> str:
    """Small label + value pair."""
    return f'<span style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;color:{ON_SURFACE_VARIANT};">{label}</span><br><span style="font-family:JetBrains Mono,monospace;font-size:14px;color:{ON_SURFACE};font-weight:500;">{value}</span>'


def pulsing_dot(color: str = TERTIARY) -> str:
    """A small pulsing status dot."""
    return f'<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{color};box-shadow:0 0 6px {color};animation:pulse 2s infinite;margin-right:6px;"></span>'


def plotly_dark_layout() -> dict:
    """Return a Plotly layout dict matching the Obsidian Flux theme."""
    return dict(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=SURFACE_CONTAINER,
        font=dict(family="Inter, sans-serif", color=ON_SURFACE, size=12),
        xaxis=dict(gridcolor=OUTLINE_VARIANT, zerolinecolor=OUTLINE_VARIANT),
        yaxis=dict(gridcolor=OUTLINE_VARIANT, zerolinecolor=OUTLINE_VARIANT),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=ON_SURFACE_VARIANT)),
        margin=dict(l=40, r=20, t=40, b=40),
    )

"""Page 00: Enterprise Sign Up / Registration."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, is_authenticated

st.set_page_config(page_title="NOC Portal - Sign Up", page_icon="📝", layout="centered")

init_auth_state()

if is_authenticated():
    st.success(f"✅ Already signed in as **{st.session_state['user_name']}**")
    st.info("Navigate to **Dashboard** from the sidebar.")
    st.stop()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

st.markdown(
    """
    <div style='text-align: center; padding: 2rem 0 1rem 0;'>
        <h1>🌐 Network Support Operations Center</h1>
        <p style='color: gray;'>New Employee Registration</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown("---")

with st.form("signup_form", clear_on_submit=False):
    st.subheader("📝 Create Your Account")

    col1, col2 = st.columns(2)
    first_name = col1.text_input("First Name *", placeholder="John")
    last_name = col2.text_input("Last Name *", placeholder="Doe")

    employee_id = st.text_input("Employee ID *", placeholder="EMP-12345")
    email = st.text_input("Corporate Email *", placeholder="john.doe@company.com")

    col3, col4 = st.columns(2)
    department = col3.selectbox("Department *", [
        "Network Operations",
        "IT Infrastructure",
        "Security Operations",
        "Field Engineering",
        "Service Desk",
        "Cloud Operations",
    ])
    location = col4.selectbox("Location *", [
        "Bengaluru",
        "Hyderabad",
        "Chennai",
        "Pune",
        "Mumbai",
        "Delhi NCR",
        "Remote",
    ])

    password = st.text_input("Password *", type="password", placeholder="Min 8 chars, upper, lower, number, special")
    confirm_password = st.text_input("Confirm Password *", type="password", placeholder="Re-enter password")

    st.caption("**Password Requirements:** Min 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character")

    submitted = st.form_submit_button("📝 Register Account", use_container_width=True)

    if submitted:
        if not all([first_name, last_name, employee_id, email, password, confirm_password]):
            st.error("All fields marked with * are required.")
        elif password != confirm_password:
            st.error("❌ Passwords do not match.")
        else:
            try:
                resp = requests.post(
                    f"{API_BASE}/auth/register",
                    json={
                        "employee_id": employee_id,
                        "first_name": first_name,
                        "last_name": last_name,
                        "email": email,
                        "password": password,
                        "department": department,
                        "location": location,
                    },
                    timeout=10,
                )
                if resp.status_code == 201:
                    st.success("✅ Registration successful! You can now sign in from the **Login** page.")
                    st.balloons()
                elif resp.status_code == 409:
                    st.error(f"⚠️ {resp.json().get('detail', 'Duplicate entry.')}")
                elif resp.status_code == 400:
                    st.error(f"❌ {resp.json().get('detail', 'Validation failed.')}")
                else:
                    st.error(f"Registration failed: {resp.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("⚠️ Unable to connect to the API server.")

st.markdown("---")
st.caption("Already have an account? Navigate to the **Login** page from the sidebar.")

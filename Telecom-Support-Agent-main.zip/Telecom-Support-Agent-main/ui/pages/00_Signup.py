"""Page 00: Enterprise Sign Up — Obsidian Flux theme."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, is_authenticated
from ui.theme import (
    inject_css, SURFACE_CONTAINER, OUTLINE_VARIANT,
    ON_SURFACE, ON_SURFACE_VARIANT, PRIMARY, SECONDARY,
)

st.set_page_config(page_title="NOC — Sign Up", page_icon="📝", layout="centered")
inject_css()
init_auth_state()

if is_authenticated():
    st.markdown(f"""
    <div style="text-align:center;padding:60px 0;">
        <div style="font-size:48px;margin-bottom:12px;">✅</div>
        <h2 style="color:{ON_SURFACE};">Already signed in</h2>
        <p style="color:{ON_SURFACE_VARIANT};">Navigate to <b>Dashboard</b> from the sidebar.</p>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

st.markdown(f"""
<div style="text-align:center;padding:32px 0 20px 0;">
    <div style="font-size:48px;margin-bottom:8px;">🌐</div>
    <h1 style="font-size:28px;color:{ON_SURFACE};margin:0;">New Employee Registration</h1>
    <p style="color:{ON_SURFACE_VARIANT};font-size:13px;font-family:JetBrains Mono,monospace;text-transform:uppercase;letter-spacing:0.06em;margin-top:4px;">NOC Portal Access Request</p>
</div>
""", unsafe_allow_html=True)

with st.form("signup_form", clear_on_submit=False):
    col1, col2 = st.columns(2)
    first_name = col1.text_input("First Name *", placeholder="John")
    last_name = col2.text_input("Last Name *", placeholder="Doe")

    employee_id = st.text_input("Employee ID *", placeholder="NOC-12345-XX")
    email = st.text_input("Corporate Email *", placeholder="john.doe@company.com")

    col3, col4 = st.columns(2)
    department = col3.selectbox("Department *", [
        "Network Operations", "IT Infrastructure", "Security Operations",
        "Field Engineering", "Service Desk", "Cloud Operations",
    ])
    location = col4.selectbox("Location *", [
        "North America Node Ashburn", "EU West London", "AP South Singapore",
        "Bengaluru", "Hyderabad", "Chennai", "Pune", "Mumbai", "Remote",
    ])

    password = st.text_input("Password *", type="password", placeholder="Min 8 chars, upper, lower, number, special")
    confirm_password = st.text_input("Confirm Password *", type="password", placeholder="Re-enter password")

    # Password requirements
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:8px;padding:10px 14px;margin:4px 0 12px 0;font-size:12px;color:{ON_SURFACE_VARIANT};font-family:JetBrains Mono,monospace;">
        <div style="margin-bottom:4px;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;">Password Requirements</div>
        <div>• Min 8 characters &nbsp; • Uppercase &amp; lowercase &nbsp; • At least one number &nbsp; • Special character</div>
    </div>
    """, unsafe_allow_html=True)

    submitted = st.form_submit_button("Register Account", use_container_width=True)

    if submitted:
        if not all([first_name, last_name, employee_id, email, password, confirm_password]):
            st.error("All fields marked with * are required.")
        elif password != confirm_password:
            st.error("Passwords do not match.")
        else:
            try:
                resp = requests.post(
                    f"{API_BASE}/auth/register",
                    json={
                        "employee_id": employee_id,
                        "first_name": first_name,
                        "last_name": last_name,
                        "email": email,
                        "password": password,
                        "department": department,
                        "location": location,
                    },
                    timeout=10,
                )
                if resp.status_code == 201:
                    st.success("Registration successful! You can now sign in from the **Login** page.")
                    st.balloons()
                elif resp.status_code == 409:
                    st.error(resp.json().get("detail", "Duplicate entry."))
                elif resp.status_code == 400:
                    st.error(resp.json().get("detail", "Validation failed."))
                else:
                    st.error(f"Registration failed: {resp.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("Unable to connect to the API server.")

st.markdown(f"""
<div style="text-align:center;margin-top:16px;">
    <span style="font-size:12px;color:{ON_SURFACE_VARIANT};">Already have an account? Navigate to <b style="color:{SECONDARY};">Login</b> page.</span>
</div>
""", unsafe_allow_html=True)

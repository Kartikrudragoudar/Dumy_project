"""Page 4: Knowledge Center (FAISS RAG)."""

from __future__ import annotations

import streamlit as st

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role

st.set_page_config(page_title="Knowledge Center", page_icon="📚", layout="wide")

init_auth_state()
require_role("Knowledge Center")
render_sidebar_profile()

st.title("📚 Knowledge Center (FAISS RAG)")
st.caption("Search SOPs, Runbooks, and Manuals")

query = st.text_input("🔍 Search SOPs and Guides", value="VPN connection error steps")

if st.button("🔎 Search Knowledge Base", use_container_width=True):
    st.markdown("### 📄 Retrieved SOP Passages")
    with st.expander("📖 VPN SOP & Troubleshooting Guide (§2.0) — Match Score: 94%"):
        st.markdown("""
        **Document ID:** `SOP-VPN-01`
        
        **Steps:**
        1. Verify active Internet connectivity by pinging 8.8.8.8.
        2. Ensure credentials are valid in Self-Service Portal.
        3. Re-install or update the VPN Client to the latest enterprise build.
        """)
    with st.expander("📖 Network Operations Center Playbook (§1.2) — Match Score: 88%"):
        st.markdown("""
        **Document ID:** `RUNBOOK-NOC-02`
        
        **Escalation Rules:**
        - Regional Core Outage / Gateway Failure → Priority CRITICAL / Level 3 (Network Ops L3).
        """)

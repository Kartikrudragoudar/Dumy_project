"""Page 4: Knowledge Center — Obsidian Flux theme (dynamic search)."""

from __future__ import annotations

import streamlit as st
import plotly.graph_objects as go

from ui.api_client import ApiClient
from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.state import init_state
from ui.theme import (
    inject_css, noc_header, status_badge, plotly_dark_layout,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — Knowledge Center", page_icon="📚", layout="wide")
inject_css()
init_auth_state()
require_role("Knowledge Center")
render_sidebar_profile()
init_state()

client: ApiClient = st.session_state.client

# ── Fetch index stats ────────────────────────────────────────────────────────
kb_info = client.kb_docs()
total_chunks = kb_info.get("total_chunks", 0)
total_docs = kb_info.get("total_docs", 0)
config = client.system_config()
embed_model = config.get("embedding_model", "bge-small-en-v1.5")

# ── Header with vector metrics ───────────────────────────────────────────────
hc1, hc2 = st.columns([5, 3])
with hc1:
    noc_header("Knowledge Center", "FAISS-Powered SOP & Runbook Search")
with hc2:
    st.markdown(f"""
    <div style="display:flex;gap:12px;justify-content:flex-end;align-items:center;padding-top:12px;">
        {status_badge(f"{total_chunks:,} Chunks", "purple")}
        {status_badge(embed_model, "blue")}
    </div>
    """, unsafe_allow_html=True)

# ── Search bar ───────────────────────────────────────────────────────────────
query = st.text_input("search", placeholder="Search SOPs, runbooks, diagnostic guides...", label_visibility="collapsed")

# Build filter pills from actual KB categories
all_docs = kb_info.get("documents", [])
categories: set[str] = set()
for doc in all_docs:
    for sec in doc.get("sections", []):
        categories.add(sec)

pill_labels = ["All SOPs"] + sorted(categories)[:6]
pill_html = ""
for i, p in enumerate(pill_labels):
    if i == 0:
        pill_html += f'<span style="display:inline-block;padding:4px 14px;border-radius:9999px;font-size:12px;font-weight:500;background:rgba(192,193,255,0.2);color:{PRIMARY};border:1px solid {PRIMARY};margin-right:6px;">{p}</span>'
    else:
        pill_html += f'<span style="display:inline-block;padding:4px 14px;border-radius:9999px;font-size:12px;font-weight:500;background:transparent;color:{ON_SURFACE_VARIANT};border:1px solid {OUTLINE_VARIANT};margin-right:6px;">{p}</span>'
st.markdown(f'<div style="margin:8px 0 16px 0;">{pill_html}</div>', unsafe_allow_html=True)

st.markdown(f'<div style="border-top:1px solid {OUTLINE_VARIANT};margin:0 0 16px 0;"></div>', unsafe_allow_html=True)

# ── Execute search ───────────────────────────────────────────────────────────
top_k = config.get("retrieval_top_k", 5)
search_results: list[dict] = []
if query:
    sr = client.kb_search(query, k=top_k)
    search_results = sr.get("results", [])

# ── Results + SOP Viewer ─────────────────────────────────────────────────────
res_col, viewer_col = st.columns([13, 7])

with res_col:
    if query:
        st.markdown(f"""
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <span style="font-size:13px;color:{ON_SURFACE_VARIANT};">{len(search_results)} results</span>
            <span style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">Sort: Relevance Hybrid</span>
        </div>
        """, unsafe_allow_html=True)

    if not query:
        st.markdown(f"""
        <div style="text-align:center;padding:60px 20px;color:{ON_SURFACE_VARIANT};">
            <div style="font-size:32px;margin-bottom:8px;">🔍</div>
            <p style="font-size:14px;">Enter a search query to find SOPs and runbooks.</p>
            <p style="font-size:12px;font-family:JetBrains Mono,monospace;color:{PRIMARY};">Try: "VPN authentication failure" or "DNS cache flush"</p>
        </div>
        """, unsafe_allow_html=True)
    elif not search_results:
        st.markdown(f"""
        <div style="text-align:center;padding:40px 20px;color:{ON_SURFACE_VARIANT};">
            <p style="font-size:13px;">No results found for "{query}".</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        score_floor = config.get("retrieval_score_floor", 0.35)
        for i, r in enumerate(search_results):
            score = r.get("score", 0)
            pct = int(score * 100)
            title = r.get("title", r.get("doc_id", "Unknown"))
            section = r.get("section", "")
            text = r.get("text", "")[:300]
            doc_id = r.get("doc_id", "")

            border_left = f"border-left:4px solid {PRIMARY};" if i == 0 else ""
            method_badge = "FAISS (Cosine)" if score >= score_floor else "BM25 Keyword"
            verified = f'{status_badge("Verified ✓", "green")}' if score >= 0.8 else ""

            st.markdown(f"""
            <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};{border_left}border-radius:12px;padding:16px 20px;margin-bottom:12px;">
                <div style="display:flex;gap:8px;margin-bottom:6px;">
                    {status_badge(section or doc_id, "blue")}
                    {verified}
                </div>
                <div style="font-size:15px;font-weight:600;color:{ON_SURFACE};margin-bottom:4px;">{title}: {section}</div>
                <div style="display:flex;gap:8px;margin-bottom:8px;">
                    {status_badge(f"{pct}% Match", "purple")}
                    <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">{method_badge}</span>
                </div>
                <div style="font-size:12px;color:{ON_SURFACE_VARIANT};line-height:1.5;margin-bottom:6px;">
                    {text}
                </div>
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">Doc: {doc_id}</div>
            </div>
            """, unsafe_allow_html=True)

with viewer_col:
    # SOP Viewer — show first result detail
    if search_results:
        top = search_results[0]
        st.markdown(f"""
        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;margin-bottom:12px;">
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};letter-spacing:0.05em;margin-bottom:8px;">Selected SOP Viewer</div>
            <div style="font-size:14px;font-weight:600;color:{ON_SURFACE};margin-bottom:12px;">{top.get('title', top.get('doc_id', 'N/A'))}</div>

            <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Full Passage</div>
            <div style="background:#000;border-radius:6px;padding:10px;font-family:JetBrains Mono,monospace;font-size:11px;color:{TERTIARY};margin-bottom:12px;line-height:1.6;max-height:300px;overflow-y:auto;">
                {top.get('text', 'No content available.').replace(chr(10), '<br>')}
            </div>

            <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">
                Doc ID: <span style="color:{PRIMARY};">{top.get('doc_id', '')}</span> ·
                Section: <span style="color:{PRIMARY};">{top.get('section', '')}</span> ·
                Score: <span style="color:{TERTIARY};">{top.get('score', 0):.4f}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:40px 20px;text-align:center;">
            <div style="font-size:28px;margin-bottom:8px;color:{ON_SURFACE_VARIANT};">📄</div>
            <div style="font-size:12px;color:{ON_SURFACE_VARIANT};">Search to view SOP details here.</div>
        </div>
        """, unsafe_allow_html=True)

    # Vector Retrieval Analytics
    if search_results:
        st.markdown(f"""
        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};letter-spacing:0.05em;margin-bottom:8px;">Vector Retrieval Analytics</div>
        </div>
        """, unsafe_allow_html=True)

        scores = [r.get("score", 0) for r in search_results]
        labels = [f"R{i+1}" for i in range(len(scores))]
        score_floor = config.get("retrieval_score_floor", 0.35)
        colors = [PRIMARY if s >= score_floor else ON_SURFACE_VARIANT for s in scores]

        fig = go.Figure()
        fig.add_trace(go.Bar(x=labels, y=scores, marker_color=colors, text=[f"{s:.2f}" for s in scores], textposition="outside", textfont=dict(size=10, color=ON_SURFACE_VARIANT)))
        fig.add_hline(y=score_floor, line_dash="dash", line_color=ERROR, annotation_text=f"Cutoff {score_floor}", annotation_position="top left", annotation_font=dict(color=ERROR, size=10))
        layout = plotly_dark_layout()
        layout.update(height=200, yaxis=dict(range=[0, max(scores + [1.0]) * 1.15], **layout.get("yaxis", {})), showlegend=False)
        fig.update_layout(**layout)
        st.plotly_chart(fig, use_container_width=True)

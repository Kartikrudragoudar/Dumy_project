"""Page 8: User Management — Obsidian Flux theme (dynamic)."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.theme import (
    inject_css, noc_header, status_badge,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — User Management", page_icon="👥", layout="wide")
inject_css()
init_auth_state()
require_role("User Management")
render_sidebar_profile()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

noc_header("User Management", "Manage User Accounts, Roles & Access Control")

# ── Fetch users from API ─────────────────────────────────────────────────────
users: list[dict] = []
api_error = False
try:
    resp = requests.get(f"{API_BASE}/auth/users", timeout=10)
    if resp.status_code == 200:
        users = resp.json()
    else:
        api_error = True
except requests.exceptions.ConnectionError:
    api_error = True

if api_error:
    st.warning("Unable to fetch users from API. Ensure the backend is running.")

# ── Filter bar ───────────────────────────────────────────────────────────────
# Build role/status options dynamically from fetched users
available_roles = sorted(set(u.get("role", "User") for u in users)) if users else ["User", "Network Engineer", "Admin"]
fc1, fc2, fc3, fc4 = st.columns([4, 1.5, 1.5, 2])
search_query = fc1.text_input("search", placeholder="Search users by name, email, or employee ID...", label_visibility="collapsed")
role_filter = fc2.selectbox("Role", ["All"] + available_roles, label_visibility="collapsed")
status_filter = fc3.selectbox("Status", ["All", "Active", "Disabled"], label_visibility="collapsed")
fc4.button("Invite New User", use_container_width=True)

st.markdown(f'<div style="border-top:1px solid {OUTLINE_VARIANT};margin:8px 0 16px 0;"></div>', unsafe_allow_html=True)

# Apply filters
filtered = users
if search_query:
    q = search_query.lower()
    filtered = [u for u in filtered if q in u.get("first_name", "").lower() or q in u.get("last_name", "").lower() or q in u.get("email", "").lower() or q in u.get("employee_id", "").lower()]
if role_filter != "All":
    filtered = [u for u in filtered if u.get("role") == role_filter]
if status_filter != "All":
    is_active = status_filter == "Active"
    filtered = [u for u in filtered if u.get("status") == is_active]

# ── User Data Grid ───────────────────────────────────────────────────────────
st.markdown(f"""
<div style="display:flex;padding:8px 20px;font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;color:{ON_SURFACE_VARIANT};background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px 12px 0 0;">
    <div style="width:22%;">User</div>
    <div style="width:22%;">Email</div>
    <div style="width:16%;">Department</div>
    <div style="width:16%;">Role</div>
    <div style="width:10%;">Status</div>
    <div style="width:14%;">Actions</div>
</div>
""", unsafe_allow_html=True)

if not filtered:
    st.markdown(f"""
    <div style="text-align:center;padding:40px 20px;border:1px solid {OUTLINE_VARIANT};border-top:none;border-radius:0 0 12px 12px;color:{ON_SURFACE_VARIANT};">
        <div style="font-size:28px;margin-bottom:8px;">👥</div>
        <p style="font-size:13px;">{'No users found matching your filters.' if users else 'No user data available.'}</p>
    </div>
    """, unsafe_allow_html=True)
else:
    for u in filtered:
        name = f"{u.get('first_name', '')} {u.get('last_name', '')}"
        eid = u.get("employee_id", "")
        email = u.get("email", "")
        dept = u.get("department", "")
        role = u.get("role", "User")
        active = u.get("status", True)

        role_color = TERTIARY if role == "Admin" else PRIMARY if role == "Network Engineer" else ON_SURFACE_VARIANT
        status_variant = "green" if active else "gray"
        status_text = "ACTIVE" if active else "DISABLED"
        row_opacity = "1" if active else "0.5"
        initial = name.strip()[0].upper() if name.strip() else "?"

        st.markdown(f"""
        <div style="display:flex;align-items:center;padding:10px 20px;border-bottom:1px solid {OUTLINE_VARIANT};border-left:1px solid {OUTLINE_VARIANT};border-right:1px solid {OUTLINE_VARIANT};font-size:13px;opacity:{row_opacity};">
            <div style="width:22%;display:flex;align-items:center;gap:10px;">
                <div style="width:32px;height:32px;border-radius:50%;background:{PRIMARY};display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#0b1326;">{initial}</div>
                <div>
                    <div style="color:{ON_SURFACE};font-weight:500;">{name}</div>
                    <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">{eid}</div>
                </div>
            </div>
            <div style="width:22%;color:{ON_SURFACE_VARIANT};font-size:12px;">{email}</div>
            <div style="width:16%;color:{ON_SURFACE_VARIANT};font-size:12px;">{dept}</div>
            <div style="width:16%;font-family:JetBrains Mono,monospace;font-size:11px;color:{role_color};">{role}</div>
            <div style="width:10%;">{status_badge(status_text, status_variant)}</div>
            <div style="width:14%;font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">
                <span title="Reset Password" style="cursor:pointer;margin-right:8px;">🔑</span>
                <span title="Delete User" style="cursor:pointer;">🗑️</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown(f'<div style="border-bottom:1px solid {OUTLINE_VARIANT};border-radius:0 0 12px 12px;height:2px;"></div>', unsafe_allow_html=True)

# Pagination
st.markdown(f"""
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px;font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">
    <span>Showing {len(filtered)} of {len(users)} users</span>
</div>
""", unsafe_allow_html=True)

st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

# ── Quick Actions ────────────────────────────────────────────────────────────
st.markdown(f'<div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:12px;">Quick Actions</div>', unsafe_allow_html=True)

ac1, ac2 = st.columns(2)

with ac1:
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;margin-bottom:8px;">
        <div style="font-weight:500;color:{ON_SURFACE};margin-bottom:12px;">Change User Role</div>
    </div>
    """, unsafe_allow_html=True)
    with st.form("role_form"):
        target_user_id = st.number_input("User ID", min_value=1, step=1, key="role_uid")
        new_role = st.selectbox("New Role", ["User", "Network Engineer", "Admin"], key="role_new")
        if st.form_submit_button("Update Role", use_container_width=True):
            try:
                resp = requests.put(f"{API_BASE}/auth/users/{target_user_id}/role", json={"role": new_role}, timeout=10)
                if resp.status_code == 200:
                    st.success(f"User {target_user_id} role updated to `{new_role}`.")
                    st.rerun()
                else:
                    st.error(resp.json().get("detail", "Update failed."))
            except requests.exceptions.ConnectionError:
                st.error("API server unreachable.")

with ac2:
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;margin-bottom:8px;">
        <div style="font-weight:500;color:{ON_SURFACE};margin-bottom:12px;">Toggle User Status</div>
    </div>
    """, unsafe_allow_html=True)
    with st.form("status_form"):
        target_status_uid = st.number_input("User ID", min_value=1, step=1, key="status_uid")
        new_status = st.selectbox("Action", ["Enable", "Disable"], key="status_action")
        if st.form_submit_button("Update Status", use_container_width=True):
            try:
                resp = requests.put(f"{API_BASE}/auth/users/{target_status_uid}/status", json={"status": new_status == "Enable"}, timeout=10)
                if resp.status_code == 200:
                    st.success(f"User {target_status_uid} {'enabled' if new_status == 'Enable' else 'disabled'}.")
                    st.rerun()
                else:
                    st.error(resp.json().get("detail", "Update failed."))
            except requests.exceptions.ConnectionError:
                st.error("API server unreachable.")

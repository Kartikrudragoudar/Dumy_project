"""Page 8: User Management (Admin Only)."""

from __future__ import annotations

import streamlit as st
import pandas as pd
import requests

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_auth, require_role

st.set_page_config(page_title="User Management", page_icon="👥", layout="wide")

init_auth_state()
require_role("User Management")
render_sidebar_profile()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

st.title("👥 User Management")
st.caption("Admin Panel — View, Search, Edit & Manage All Users")

st.markdown("---")

# Fetch all users
try:
    resp = requests.get(f"{API_BASE}/auth/users", timeout=10)
    if resp.status_code == 200:
        users = resp.json()
    else:
        users = []
        st.error("Failed to fetch users.")
except requests.exceptions.ConnectionError:
    users = []
    st.warning("⚠️ API server unreachable. Showing placeholder data.")
    users = [
        {"user_id": 1, "first_name": "Admin", "last_name": "User", "email": "admin@company.com", "employee_id": "EMP-001", "department": "IT Infrastructure", "role": "Admin", "status": True, "last_login": "2026-08-05"},
        {"user_id": 2, "first_name": "Network", "last_name": "Engineer", "email": "neteng@company.com", "employee_id": "EMP-002", "department": "Network Operations", "role": "Network Engineer", "status": True, "last_login": "2026-08-04"},
        {"user_id": 3, "first_name": "Service", "last_name": "Agent", "email": "agent@company.com", "employee_id": "EMP-003", "department": "Service Desk", "role": "User", "status": True, "last_login": "2026-08-03"},
    ]

# Filters
col1, col2 = st.columns([2, 1])
search_query = col1.text_input("🔍 Search Users", placeholder="Name, email, or employee ID")
role_filter = col2.selectbox("Filter by Role", ["All", "User", "Network Engineer", "Admin"])

# Apply filters
filtered_users = users
if search_query:
    q = search_query.lower()
    filtered_users = [
        u for u in filtered_users
        if q in u.get("first_name", "").lower()
        or q in u.get("last_name", "").lower()
        or q in u.get("email", "").lower()
        or q in u.get("employee_id", "").lower()
    ]
if role_filter != "All":
    filtered_users = [u for u in filtered_users if u.get("role") == role_filter]

st.markdown(f"**Total Users:** {len(filtered_users)}")

# User Table
if filtered_users:
    df = pd.DataFrame(filtered_users)
    display_cols = ["user_id", "first_name", "last_name", "email", "department", "role", "status", "last_login"]
    available_cols = [c for c in display_cols if c in df.columns]
    st.dataframe(df[available_cols], use_container_width=True, hide_index=True)

st.markdown("---")

# User Actions
st.subheader("⚡ User Actions")

col_a, col_b = st.columns(2)

with col_a:
    st.markdown("### 🔄 Change User Role")
    with st.form("role_form"):
        target_user_id = st.number_input("User ID", min_value=1, step=1, key="role_uid")
        new_role = st.selectbox("New Role", ["User", "Network Engineer", "Admin"], key="role_new")
        if st.form_submit_button("Update Role", use_container_width=True):
            try:
                resp = requests.put(
                    f"{API_BASE}/auth/users/{target_user_id}/role",
                    json={"role": new_role},
                    timeout=10,
                )
                if resp.status_code == 200:
                    st.success(f"✅ User {target_user_id} role updated to `{new_role}`.")
                else:
                    st.error(resp.json().get("detail", "Update failed."))
            except requests.exceptions.ConnectionError:
                st.error("⚠️ API server unreachable.")

with col_b:
    st.markdown("### 🔒 Enable / Disable User")
    with st.form("status_form"):
        target_status_uid = st.number_input("User ID", min_value=1, step=1, key="status_uid")
        new_status = st.selectbox("Action", ["Enable", "Disable"], key="status_action")
        if st.form_submit_button("Update Status", use_container_width=True):
            try:
                resp = requests.put(
                    f"{API_BASE}/auth/users/{target_status_uid}/status",
                    json={"status": new_status == "Enable"},
                    timeout=10,
                )
                if resp.status_code == 200:
                    st.success(f"✅ User {target_status_uid} {'enabled' if new_status == 'Enable' else 'disabled'}.")
                else:
                    st.error(resp.json().get("detail", "Update failed."))
            except requests.exceptions.ConnectionError:
                st.error("⚠️ API server unreachable.")

st.markdown("---")

st.markdown("### 🗑️ Delete User")
with st.form("delete_form"):
    delete_uid = st.number_input("User ID to Delete", min_value=1, step=1, key="delete_uid")
    confirm_delete = st.checkbox("I confirm this action is irreversible")
    if st.form_submit_button("🗑️ Delete User", use_container_width=True):
        if not confirm_delete:
            st.warning("Please confirm the deletion.")
        else:
            try:
                resp = requests.delete(f"{API_BASE}/auth/users/{delete_uid}", timeout=10)
                if resp.status_code == 200:
                    st.success(f"✅ User {delete_uid} deleted.")
                else:
                    st.error(resp.json().get("detail", "Deletion failed."))
            except requests.exceptions.ConnectionError:
                st.error("⚠️ API server unreachable.")

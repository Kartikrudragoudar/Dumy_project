"""Page 5: Analytics."""

from __future__ import annotations

import streamlit as st

st.set_page_config(page_title="Analytics", page_icon="📈", layout="wide")

st.title("📈 Analytics & Performance Dashboard")
st.caption("Ticket Trends, Resolution Metrics & Category Distribution")

col1, col2, col3 = st.columns(3)
col1.metric("Avg. Resolution Time", "14.2 mins", delta="-2.1 mins")
col2.metric("First-Contact Resolution", "78.4%", delta="+4.2%")
col3.metric("Auto-Triage Accuracy", "96.1%", delta="+1.0%")

st.markdown("---")

col_l, col_r = st.columns(2)

with col_l:
    st.subheader("📊 Category Distribution")
    st.bar_chart({
        "vpn_issue": 35,
        "wifi_issue": 24,
        "dns_issue": 18,
        "slow_internet": 15,
        "router_issue": 8,
    })

with col_r:
    st.subheader("⚡ Escalation Levels Distribution")
    st.bar_chart({
        "L1 (Service Desk)": 58,
        "L2 (NOC / SysAdmin)": 28,
        "L3 (Network Ops L3)": 14,
    })

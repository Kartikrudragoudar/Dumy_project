"""Page 5: Incident Intelligence & Analytics — Obsidian Flux theme (dynamic)."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta

import streamlit as st
import plotly.graph_objects as go

from ui.api_client import ApiClient
from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.state import init_state
from ui.theme import (
    inject_css, noc_header, kpi_card, status_badge, plotly_dark_layout,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — Analytics", page_icon="📈", layout="wide")
inject_css()
init_auth_state()
require_role("Analytics")
render_sidebar_profile()
init_state()

client: ApiClient = st.session_state.client

# ── Fetch live data ──────────────────────────────────────────────────────────
stats = client.system_stats()
llm_info = client.llm_health()
config = client.system_config()
tickets = client.list_tickets(limit=5000)

total = stats.get("total_tickets", len(tickets))
by_status = stats.get("by_status", {})
by_priority = stats.get("by_priority", {})
by_category = stats.get("by_category", {})

resolved_count = by_status.get("RESOLVED", 0) + by_status.get("CLOSED", 0)
open_count = by_status.get("OPEN", 0) + by_status.get("IN_PROGRESS", 0)
escalated_count = by_status.get("IN_PROGRESS", 0)

# FCR approximation: resolved / total (if total > 0)
fcr_rate = round(resolved_count / total * 100, 1) if total > 0 else 0.0
escalation_rate = round(open_count / total * 100, 1) if total > 0 else 0.0

now = datetime.now()
date_range = f"{(now - timedelta(days=6)).strftime('%b %d')} - {now.strftime('%b %d, %Y')}"

# ── Header ───────────────────────────────────────────────────────────────────
hc1, hc2 = st.columns([5, 3])
with hc1:
    noc_header("Incident Intelligence & Analytics", "AI-Driven Operations Insights")
with hc2:
    st.markdown(f"""
    <div style="display:flex;gap:10px;justify-content:flex-end;align-items:center;padding-top:12px;">
        {status_badge(f"Last 7 Days · {date_range}", "blue")}
    </div>
    """, unsafe_allow_html=True)

# ── KPI Row ──────────────────────────────────────────────────────────────────
k1, k2, k3, k4 = st.columns(4)
with k1:
    st.markdown(kpi_card("Total Resolved", f"{resolved_count:,}", f"of {total:,} total", "📊", PRIMARY), unsafe_allow_html=True)
with k2:
    st.markdown(kpi_card("Resolution Rate", f"{fcr_rate}%", f"{resolved_count} resolved", "🎯", TERTIARY), unsafe_allow_html=True)
with k3:
    st.markdown(kpi_card("Open / In Progress", f"{open_count}", f"{escalation_rate}% of total", "⬆️", ERROR), unsafe_allow_html=True)
with k4:
    cb_state = llm_info.get("circuit_breaker", "CLOSED")
    active = llm_info.get("active_provider", "—")
    st.markdown(kpi_card("LLM Status", cb_state, f"Active: {active}", "⚡", TERTIARY if cb_state == "CLOSED" else ERROR), unsafe_allow_html=True)

st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

# ── Charts Row ───────────────────────────────────────────────────────────────
ch1, ch2 = st.columns(2)

with ch1:
    st.markdown(f'<div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;"><div style="font-weight:600;color:{ON_SURFACE};font-size:14px;margin-bottom:8px;">Volume by Category</div></div>', unsafe_allow_html=True)

    if by_category:
        cats = sorted(by_category.items(), key=lambda x: x[1], reverse=True)[:8]
        cat_names = [c[0].replace("_", " ").title() for c in cats]
        cat_vals = [c[1] for c in cats]

        fig_vol = go.Figure()
        fig_vol.add_trace(go.Bar(x=cat_names, y=cat_vals, marker_color=PRIMARY, text=cat_vals, textposition="outside", textfont=dict(color=ON_SURFACE_VARIANT, size=10)))
        layout = plotly_dark_layout()
        layout.update(height=300)
        fig_vol.update_layout(**layout)
        st.plotly_chart(fig_vol, use_container_width=True)
    else:
        st.info("No ticket data available for category chart.")

with ch2:
    st.markdown(f'<div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;"><div style="font-weight:600;color:{ON_SURFACE};font-size:14px;margin-bottom:8px;">Status Breakdown</div></div>', unsafe_allow_html=True)

    if by_status:
        status_labels = [s.replace("_", " ").title() for s in by_status.keys()]
        status_vals = list(by_status.values())
        status_colors = []
        for s in by_status.keys():
            if s == "OPEN":
                status_colors.append(ERROR)
            elif s == "IN_PROGRESS":
                status_colors.append(SECONDARY)
            elif s == "RESOLVED":
                status_colors.append(TERTIARY)
            else:
                status_colors.append(ON_SURFACE_VARIANT)

        fig_donut = go.Figure(go.Pie(
            labels=status_labels,
            values=status_vals,
            hole=0.6,
            marker=dict(colors=status_colors),
            textinfo="label+percent",
            textfont=dict(size=11, color=ON_SURFACE_VARIANT),
        ))
        layout = plotly_dark_layout()
        total_display = f"{total:,}<br>Total"
        layout.update(height=300, annotations=[dict(text=total_display, x=0.5, y=0.5, font=dict(size=16, color=ON_SURFACE), showarrow=False)])
        fig_donut.update_layout(**layout)
        st.plotly_chart(fig_donut, use_container_width=True)
    else:
        st.info("No ticket data available for status chart.")

# ── Bottom Row ───────────────────────────────────────────────────────────────
st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
b1, b2 = st.columns([3, 2])

with b1:
    st.markdown(f'<div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;"><div style="font-weight:600;color:{ON_SURFACE};font-size:14px;margin-bottom:12px;">Priority Distribution</div></div>', unsafe_allow_html=True)

    if by_priority:
        prio_items = sorted(by_priority.items(), key=lambda x: x[1], reverse=True)
        prio_labels = [p[0] for p in prio_items]
        prio_vals = [p[1] for p in prio_items]
        prio_colors = [ERROR if p in ("Critical", "P1") else SECONDARY if p in ("High", "P2") else ON_SURFACE_VARIANT for p in [x[0] for x in prio_items]]

        fig_prio = go.Figure()
        fig_prio.add_trace(go.Bar(y=prio_labels, x=prio_vals, orientation="h", marker_color=prio_colors, text=prio_vals, textposition="outside", textfont=dict(color=ON_SURFACE_VARIANT, size=10)))
        layout = plotly_dark_layout()
        layout.update(height=220)
        fig_prio.update_layout(**layout)
        st.plotly_chart(fig_prio, use_container_width=True)
    else:
        st.info("No priority data available.")

with b2:
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
        <div style="font-weight:600;color:{ON_SURFACE};font-size:14px;margin-bottom:12px;">LLM Provider Health</div>
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:16px;">
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{TERTIARY if llm_info.get('circuit_breaker') == 'CLOSED' else ERROR};box-shadow:0 0 6px {TERTIARY if llm_info.get('circuit_breaker') == 'CLOSED' else ERROR};"></span>
            {status_badge(llm_info.get('circuit_breaker', 'UNKNOWN'), "green" if llm_info.get('circuit_breaker') == 'CLOSED' else "red")}
        </div>
    """, unsafe_allow_html=True)

    providers = llm_info.get("providers", {})
    active_prov = llm_info.get("active_provider", "")
    for pname, is_healthy in providers.items():
        display_name = pname.replace("_", " ").title()
        role = "Primary" if pname == active_prov else "Failover"
        color = TERTIARY if is_healthy else ERROR
        status_text = "Active" if is_healthy else "Down"

        st.markdown(f"""
        <div style="border:1px solid {OUTLINE_VARIANT};border-radius:8px;padding:10px 14px;margin-bottom:8px;">
            <div style="font-size:13px;color:{ON_SURFACE};font-weight:500;">{display_name}</div>
            <div style="display:flex;gap:16px;margin-top:4px;">
                <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{color};">{role}</span>
                <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{color};">{status_text}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

    cooldown = llm_info.get("cooldown_seconds", config.get("llm_breaker_cooldown_seconds", "—"))
    st.markdown(f"""
        <div style="border-top:1px solid {OUTLINE_VARIANT};margin-top:8px;padding-top:8px;">
            <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};text-transform:uppercase;">Circuit Breaker:</span>
            <span style="font-family:JetBrains Mono,monospace;font-size:11px;color:{TERTIARY};margin-left:4px;">{llm_info.get('circuit_breaker', 'UNKNOWN')}</span><br>
            <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">Cooldown: {cooldown}s · Failover: {'Enabled' if llm_info.get('failover_enabled', False) else 'Disabled'}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

"""Page 5: Analytics."""

from __future__ import annotations

import streamlit as st
import pandas as pd
import plotly.express as px

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role

st.set_page_config(page_title="Analytics", page_icon="📈", layout="wide")

init_auth_state()
require_role("Analytics")
render_sidebar_profile()

st.title("📈 Analytics & Performance Dashboard")
st.caption("Ticket Trends, Resolution Metrics & Category Distribution")

col1, col2, col3 = st.columns(3)
col1.metric("Avg. Resolution Time", "14.2 mins", delta="-2.1 mins")
col2.metric("First-Contact Resolution", "78.4%", delta="+4.2%")
col3.metric("Auto-Triage Accuracy", "96.1%", delta="+1.0%")

st.markdown("---")

col_l, col_r = st.columns(2)

with col_l:
    st.subheader("📊 Category Distribution")
    df_cat = pd.DataFrame({
        "Category": ["vpn_issue", "wifi_issue", "dns_issue", "slow_internet", "router_issue"],
        "Count": [35, 24, 18, 15, 8]
    })
    fig_cat = px.pie(df_cat, values="Count", names="Category", title="Incident Categories")
    st.plotly_chart(fig_cat, use_container_width=True)

with col_r:
    st.subheader("⚡ Escalation Levels Distribution")
    df_esc = pd.DataFrame({
        "Level": ["L1 (Service Desk)", "L2 (NOC / SysAdmin)", "L3 (Network Ops L3)"],
        "Count": [58, 28, 14]
    })
    fig_esc = px.bar(df_esc, x="Level", y="Count", color="Level", title="Escalation Breakdown")
    st.plotly_chart(fig_esc, use_container_width=True)

"""Page 0: Enterprise Login Page."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, is_authenticated, login_user

st.set_page_config(page_title="NOC Portal - Sign In", page_icon="🔐", layout="centered")

init_auth_state()

if is_authenticated():
    st.success(f"✅ Already signed in as **{st.session_state['user_name']}** ({st.session_state['role']})")
    st.info("Navigate to **Dashboard** or other pages from the sidebar.")
    st.stop()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

# Header
st.markdown(
    """
    <div style='text-align: center; padding: 2rem 0 1rem 0;'>
        <h1>🌐 Network Support Operations Center</h1>
        <p style='color: gray;'>Enterprise Portal Sign In</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown("---")

with st.form("login_form", clear_on_submit=False):
    st.subheader("🔐 Sign In")

    email = st.text_input("Corporate Email", placeholder="you@company.com")
    password = st.text_input("Password", type="password", placeholder="Enter your password")
    remember_me = st.checkbox("Remember Me")

    submitted = st.form_submit_button("🚀 Sign In", use_container_width=True)

    if submitted:
        if not email or not password:
            st.error("Please enter both email and password.")
        else:
            try:
                resp = requests.post(
                    f"{API_BASE}/auth/login",
                    json={"email": email, "password": password},
                    timeout=10,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    login_user(data["user"], data["access_token"])
                    st.success(f"Welcome back, **{data['user']['first_name']}**!")
                    st.rerun()
                elif resp.status_code == 401:
                    st.error("❌ Invalid credentials or account disabled.")
                else:
                    st.error(f"Login failed: {resp.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("⚠️ Unable to connect to the API server. Please ensure the backend is running.")

st.markdown("---")

col1, col2 = st.columns(2)
with col1:
    st.caption("🔑 [Forgot Password?](#)")
with col2:
    st.caption("📝 Don't have an account? Navigate to **Sign Up** page.")

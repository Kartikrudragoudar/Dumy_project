"""Page 0: Enterprise Login — Obsidian Flux theme."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, is_authenticated, login_user
from ui.theme import (
    inject_css, SURFACE, SURFACE_CONTAINER, OUTLINE_VARIANT,
    ON_SURFACE, ON_SURFACE_VARIANT, PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — Sign In", page_icon="🔐", layout="centered")
inject_css()
init_auth_state()

if is_authenticated():
    st.markdown(f"""
    <div style="text-align:center;padding:60px 0;">
        <div style="font-size:48px;margin-bottom:12px;">✅</div>
        <h2 style="color:{ON_SURFACE};">Already signed in</h2>
        <p style="color:{ON_SURFACE_VARIANT};">Signed in as <b style="color:{PRIMARY};">{st.session_state['user_name']}</b> ({st.session_state['role']})</p>
        <p style="color:{ON_SURFACE_VARIANT};font-size:13px;">Navigate to <b>Dashboard</b> from the sidebar.</p>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

# Header
st.markdown(f"""
<div style="text-align:center;padding:40px 0 24px 0;">
    <div style="font-size:48px;margin-bottom:8px;">🌐</div>
    <h1 style="font-size:28px;color:{ON_SURFACE};margin:0;">Network Operations Center</h1>
    <p style="color:{ON_SURFACE_VARIANT};font-size:13px;font-family:JetBrains Mono,monospace;text-transform:uppercase;letter-spacing:0.06em;margin-top:4px;">Enterprise Portal Sign In</p>
</div>
""", unsafe_allow_html=True)

# Login form
with st.form("login_form", clear_on_submit=False):
    st.markdown(f'<div style="font-size:13px;color:{ON_SURFACE_VARIANT};margin-bottom:4px;">Corporate Email</div>', unsafe_allow_html=True)
    email = st.text_input("email", placeholder="you@company.com", label_visibility="collapsed")

    st.markdown(f'<div style="font-size:13px;color:{ON_SURFACE_VARIANT};margin-bottom:4px;margin-top:8px;">Password</div>', unsafe_allow_html=True)
    password = st.text_input("password", type="password", placeholder="Enter your password", label_visibility="collapsed")

    submitted = st.form_submit_button("Sign In", use_container_width=True)

    if submitted:
        if not email or not password:
            st.error("Please enter both email and password.")
        else:
            try:
                resp = requests.post(
                    f"{API_BASE}/auth/login",
                    json={"email": email, "password": password},
                    timeout=10,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    login_user(data["user"], data["access_token"])
                    st.success(f"Welcome back, **{data['user']['first_name']}**!")
                    st.rerun()
                elif resp.status_code == 401:
                    st.error("Invalid credentials or account disabled.")
                else:
                    st.error(f"Login failed: {resp.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("Unable to connect to the API server. Ensure the backend is running.")

st.markdown(f"""
<div style="text-align:center;margin-top:20px;">
    <span style="font-size:12px;color:{ON_SURFACE_VARIANT};">Don't have an account? Navigate to <b style="color:{SECONDARY};">Sign Up</b> page.</span>
</div>
""", unsafe_allow_html=True)

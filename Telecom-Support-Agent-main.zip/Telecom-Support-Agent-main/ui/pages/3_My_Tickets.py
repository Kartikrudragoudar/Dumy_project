"""Page 3: My Tickets."""

from __future__ import annotations

import streamlit as st

st.set_page_config(page_title="My Tickets", page_icon="🎫", layout="wide")

st.title("🎫 My Tickets")
st.caption("Search, Tracking, and Incident Timeline")

# Search and Filters
col1, col2, col3 = st.columns([2, 1, 1])
search_id = col1.text_input("🔍 Search Ticket ID or Keyword", value="NET-1001")
status_filter = col2.selectbox("Filter Status", ["ALL", "OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"])
priority_filter = col3.selectbox("Filter Priority", ["ALL", "Critical", "High", "Medium", "Low"])

st.markdown("---")

# Sample Detail View
st.subheader(f"Incident Details: {search_id}")

col_a, col_b, col_c, col_d = st.columns(4)
col_a.markdown("**Priority:** `Critical`")
col_b.markdown("**Category:** `vpn_issue`")
col_c.markdown("**Status:** `OPEN`")
col_d.markdown("**Assigned Team:** `Network Operations`")

st.markdown("**Summary:**")
st.info("VPN Gateway Authentication Timeout affecting remote users in Region AP-East.")

st.subheader("⏱️ Incident Timeline")
st.markdown("""
- **10:14 AM**: Incident created via AI Support Chat (`NET-1001`)
- **10:15 AM**: Intent classified as `vpn_issue` (Confidence: 0.95)
- **10:16 AM**: Specialized VPN Diagnostic executed — credential/gateway error detected
- **10:17 AM**: Escalation Agent assigned ticket to `Network Operations` (Level L2)
- **10:20 AM**: NOC On-Call Engineer acknowledged incident
""")

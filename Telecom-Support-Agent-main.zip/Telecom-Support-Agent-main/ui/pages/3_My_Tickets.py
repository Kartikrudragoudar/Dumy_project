"""Page 3: My Tickets with Interactive AgGrid Table."""

from __future__ import annotations

import streamlit as st
import pandas as pd

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role

try:
    from st_aggrid import AgGrid, GridOptionsBuilder
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False

st.set_page_config(page_title="My Tickets", page_icon="🎫", layout="wide")

init_auth_state()
require_role("My Tickets")
render_sidebar_profile()

st.title("🎫 My Tickets")
st.caption("Interactive Ticket Management & Incident Search")

# Sample Tickets Data
data = [
    {"Ticket ID": "NET-1001", "Category": "vpn_issue", "Priority": "Critical", "Status": "OPEN", "Assigned Team": "Network Operations", "Created": "2026-08-05 10:14"},
    {"Ticket ID": "NET-1002", "Category": "wifi_issue", "Priority": "High", "Status": "IN_PROGRESS", "Assigned Team": "Field Service", "Created": "2026-08-05 09:30"},
    {"Ticket ID": "NET-1003", "Category": "dns_issue", "Priority": "Medium", "Status": "RESOLVED", "Assigned Team": "SysAdmin", "Created": "2026-08-04 16:45"},
    {"Ticket ID": "NET-1004", "Category": "slow_internet", "Priority": "Low", "Status": "CLOSED", "Assigned Team": "Helpdesk L1", "Created": "2026-08-04 14:10"},
]
df_tickets = pd.DataFrame(data)

st.subheader("🔍 Interactive Incident Table")

if HAS_AGGRID:
    gb = GridOptionsBuilder.from_dataframe(df_tickets)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_selection('single', use_checkbox=True)
    gridOptions = gb.build()

    grid_response = AgGrid(
        df_tickets,
        gridOptions=gridOptions,
        data_return_mode='AS_INPUT', 
        update_mode='MODEL_CHANGED',
        fit_columns_on_grid_load=True,
        enable_enterprise_modules=False,
        height=300,
        reload_data=True
    )
else:
    st.dataframe(df_tickets, use_container_width=True)

st.markdown("---")

st.subheader("⏱️ Incident Timeline (NET-1001)")
st.markdown("""
- **10:14 AM**: Incident created via AI Support Chat (`NET-1001`)
- **10:15 AM**: Intent classified as `vpn_issue` (Confidence: 0.95)
- **10:16 AM**: Specialized VPN Diagnostic executed — credential/gateway error detected
- **10:17 AM**: Escalation Agent assigned ticket to `Network Operations` (Level L2)
- **10:20 AM**: NOC On-Call Engineer acknowledged incident
""")

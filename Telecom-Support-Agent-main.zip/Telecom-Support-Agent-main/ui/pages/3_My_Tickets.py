"""Page 3: My Tickets — Obsidian Flux theme (dynamic data)."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ApiClient
from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.state import init_state
from ui.theme import (
    inject_css, noc_header, status_badge, card,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — My Tickets", page_icon="🎫", layout="wide")
inject_css()
init_auth_state()
require_role("My Tickets")
render_sidebar_profile()
init_state()

client: ApiClient = st.session_state.client

noc_header("My Tickets", "Incident Management & Resolution Tracking")

# ── Filter bar ───────────────────────────────────────────────────────────────
fc1, fc2, fc3, fc4, fc5 = st.columns([3, 1.5, 1.5, 1.5, 1.5])
search = fc1.text_input("search", placeholder="Search IDs, keywords...", label_visibility="collapsed")
cat_filter = fc2.selectbox("Category", ["All", "vpn_issue", "dns_issue", "wifi_issue", "router_issue", "internet_down", "slow_internet", "firewall_issue", "other"], label_visibility="collapsed")
prio_filter = fc3.selectbox("Priority", ["All", "Critical", "P1", "High", "P2", "Medium", "P3", "Low", "P4"], label_visibility="collapsed")
stat_filter = fc4.selectbox("Status", ["All", "OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"], label_visibility="collapsed")
fc5.button("🔄 Refresh", use_container_width=True, on_click=lambda: st.rerun())

st.markdown(f'<div style="border-top:1px solid {OUTLINE_VARIANT};margin:8px 0 16px 0;"></div>', unsafe_allow_html=True)

# ── Fetch tickets from API ───────────────────────────────────────────────────
api_priority = None
if prio_filter != "All":
    api_priority = prio_filter
api_status = None
if stat_filter != "All":
    api_status = stat_filter

raw_tickets = client.list_tickets(priority=api_priority, status=api_status, limit=200)

# Client-side filters for category & search (API doesn't filter by category in list)
tickets = raw_tickets
if cat_filter != "All":
    tickets = [t for t in tickets if t.get("category") == cat_filter]
if search:
    q = search.lower()
    tickets = [t for t in tickets if q in t.get("ticket_id", "").lower() or q in t.get("summary", "").lower() or q in t.get("category", "").lower()]

# Sort newest first
tickets = sorted(tickets, key=lambda t: t.get("created_at", ""), reverse=True)

# ── Display helpers ──────────────────────────────────────────────────────────
_CAT_COLORS = {"vpn_issue": "blue", "dns_issue": "green", "wifi_issue": "purple", "router_issue": "blue", "firewall_issue": "red", "internet_down": "red", "slow_internet": "gray", "other": "gray"}
_CAT_DISPLAY = {
    "vpn_issue": "VPN", "dns_issue": "DNS", "wifi_issue": "WiFi", "router_issue": "Router",
    "internet_down": "Outage", "slow_internet": "Slow Net", "firewall_issue": "Firewall",
    "email_issue": "Email", "account_access_issue": "Auth", "network_outage": "Outage", "other": "Other",
}
_PRIO_COLORS = {"Critical": ERROR, "P1": ERROR, "High": SECONDARY, "P2": SECONDARY}
_PRIO_LABEL = {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4"}
_STAT_COLORS = {"OPEN": "red", "IN_PROGRESS": "blue", "RESOLVED": "green", "CLOSED": "gray"}

# ── Tickets table ────────────────────────────────────────────────────────────
st.markdown(f"""
<div style="display:flex;padding:8px 20px;font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;color:{ON_SURFACE_VARIANT};background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px 12px 0 0;">
    <div style="width:12%;">Ticket ID</div>
    <div style="width:14%;">Created</div>
    <div style="width:10%;">Category</div>
    <div style="width:30%;">Summary</div>
    <div style="width:8%;">Priority</div>
    <div style="width:12%;">Status</div>
    <div style="width:14%;">Queue</div>
</div>
""", unsafe_allow_html=True)

if not tickets:
    st.markdown(f"""
    <div style="text-align:center;padding:40px 20px;border:1px solid {OUTLINE_VARIANT};border-top:none;border-radius:0 0 12px 12px;color:{ON_SURFACE_VARIANT};">
        <div style="font-size:28px;margin-bottom:8px;">📋</div>
        <p style="font-size:13px;">No tickets found matching your filters.</p>
    </div>
    """, unsafe_allow_html=True)
else:
    for t in tickets:
        tid = t.get("ticket_id", "—")
        created = t.get("created_at", "")[:16]
        cat = t.get("category", "other")
        summary = t.get("summary", "No summary")[:80]
        prio = t.get("priority", "Medium")
        stat = t.get("status", "OPEN")
        queue = t.get("queue", "—")

        p_display = _PRIO_LABEL.get(prio, prio)
        p_color = _PRIO_COLORS.get(prio, ON_SURFACE_VARIANT)
        s_color = _STAT_COLORS.get(stat, "gray")
        cat_display = _CAT_DISPLAY.get(cat, cat)
        cat_color = _CAT_COLORS.get(cat, "gray")

        st.markdown(f"""
        <div style="display:flex;align-items:center;padding:10px 20px;border-bottom:1px solid {OUTLINE_VARIANT};border-left:1px solid {OUTLINE_VARIANT};border-right:1px solid {OUTLINE_VARIANT};font-size:13px;">
            <div style="width:12%;font-family:JetBrains Mono,monospace;color:{PRIMARY};font-size:12px;">{tid}</div>
            <div style="width:14%;font-family:JetBrains Mono,monospace;color:{ON_SURFACE_VARIANT};font-size:11px;">{created}</div>
            <div style="width:10%;">{status_badge(cat_display, cat_color)}</div>
            <div style="width:30%;color:{ON_SURFACE};">{summary}</div>
            <div style="width:8%;font-family:JetBrains Mono,monospace;color:{p_color};font-weight:600;font-size:12px;">{p_display}</div>
            <div style="width:12%;">{status_badge(stat.replace('_', ' ').title(), s_color)}</div>
            <div style="width:14%;color:{ON_SURFACE_VARIANT};font-size:12px;">{queue}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown(f'<div style="border-bottom:1px solid {OUTLINE_VARIANT};border-radius:0 0 12px 12px;height:2px;"></div>', unsafe_allow_html=True)

st.markdown(f'<div style="text-align:right;margin-top:8px;font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">Showing {len(tickets)} of {len(raw_tickets)} incidents</div>', unsafe_allow_html=True)

# ── Ticket Detail (expandable per ticket) ────────────────────────────────────
st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

if tickets:
    st.markdown(f'<div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:12px;">Ticket Detail</div>', unsafe_allow_html=True)

    ticket_ids = [t.get("ticket_id", "—") for t in tickets[:20]]
    selected_id = st.selectbox("Select a ticket to inspect", ticket_ids, label_visibility="collapsed")

    if selected_id:
        detail = client.get_ticket(selected_id)
        if detail:
            dc1, dc2 = st.columns(2)
            with dc1:
                st.markdown(f"""
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Ticket ID</div>
                <div style="color:{PRIMARY};font-size:14px;font-family:JetBrains Mono,monospace;margin-bottom:12px;">{detail.get('ticket_id', 'N/A')}</div>
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Category</div>
                <div style="color:{ON_SURFACE};font-size:13px;margin-bottom:12px;">{_CAT_DISPLAY.get(detail.get('category', ''), detail.get('category', 'N/A'))}</div>
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Priority</div>
                <div style="margin-bottom:12px;">{status_badge(_PRIO_LABEL.get(detail.get('priority', ''), detail.get('priority', '')), 'red' if detail.get('priority') in ('Critical', 'P1') else 'blue')}</div>
                """, unsafe_allow_html=True)
            with dc2:
                st.markdown(f"""
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Status</div>
                <div style="margin-bottom:12px;">{status_badge(detail.get('status', 'OPEN').replace('_', ' ').title(), _STAT_COLORS.get(detail.get('status', ''), 'gray'))}</div>
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Assigned Queue</div>
                <div style="color:{ON_SURFACE};font-size:13px;margin-bottom:12px;">{detail.get('queue', 'N/A')}</div>
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Created At</div>
                <div style="color:{ON_SURFACE};font-size:13px;font-family:JetBrains Mono,monospace;margin-bottom:12px;">{detail.get('created_at', 'N/A')}</div>
                """, unsafe_allow_html=True)

            if detail.get("summary"):
                st.markdown(f"""
                <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:8px;padding:12px 16px;margin-top:8px;">
                    <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Summary</div>
                    <div style="font-size:13px;color:{ON_SURFACE};line-height:1.5;">{detail['summary']}</div>
                </div>
                """, unsafe_allow_html=True)

            # Session link
            sid = detail.get("session_id", "")
            if sid:
                st.markdown(f"""
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};margin-top:8px;">
                    Session: <span style="color:{SECONDARY};">{sid}</span>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.warning(f"Could not fetch details for {selected_id}.")

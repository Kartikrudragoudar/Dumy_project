"""Page 7: User Profile."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_auth

st.set_page_config(page_title="My Profile", page_icon="👤", layout="wide")

init_auth_state()
require_auth()
render_sidebar_profile()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

st.title("👤 My Profile")
st.caption("View and update your account details")

st.markdown("---")

# Profile Display
col1, col2 = st.columns(2)

with col1:
    st.markdown("### 📋 Account Information")
    st.markdown(f"**First Name:** {st.session_state.get('user_name', '').split(' ')[0]}")
    st.markdown(f"**Last Name:** {' '.join(st.session_state.get('user_name', '').split(' ')[1:])}")
    st.markdown(f"**Employee ID:** `{st.session_state.get('employee_id', 'N/A')}`")
    st.markdown(f"**Email:** {st.session_state.get('email', 'N/A')}")

with col2:
    st.markdown("### 🏢 Organization")
    st.markdown(f"**Department:** {st.session_state.get('department', 'N/A')}")
    st.markdown(f"**Location:** {st.session_state.get('location', 'N/A')}")
    st.markdown(f"**Role:** `{st.session_state.get('role', 'N/A')}`")
    st.markdown(f"**Last Login:** {st.session_state.get('last_login', 'N/A')}")

st.markdown("---")

# Update Profile
st.subheader("✏️ Update Profile")

with st.form("update_profile_form"):
    new_department = st.selectbox("Department", [
        "Network Operations",
        "IT Infrastructure",
        "Security Operations",
        "Field Engineering",
        "Service Desk",
        "Cloud Operations",
    ], index=0)

    new_location = st.selectbox("Location", [
        "Bengaluru",
        "Hyderabad",
        "Chennai",
        "Pune",
        "Mumbai",
        "Delhi NCR",
        "Remote",
    ], index=0)

    if st.form_submit_button("💾 Update Profile", use_container_width=True):
        try:
            resp = requests.put(
                f"{API_BASE}/auth/me",
                params={"user_id": st.session_state["user_id"]},
                json={"department": new_department, "location": new_location},
                timeout=10,
            )
            if resp.status_code == 200:
                st.session_state["department"] = new_department
                st.session_state["location"] = new_location
                st.success("✅ Profile updated successfully!")
            else:
                st.error(f"Update failed: {resp.json().get('detail', 'Unknown error')}")
        except requests.exceptions.ConnectionError:
            st.error("⚠️ Unable to connect to API server.")

st.markdown("---")

# Change Password
st.subheader("🔑 Change Password")

with st.form("change_password_form"):
    new_password = st.text_input("New Password", type="password", placeholder="Min 8 chars, upper, lower, number, special")
    confirm_password = st.text_input("Confirm New Password", type="password")

    if st.form_submit_button("🔐 Update Password", use_container_width=True):
        if not new_password or not confirm_password:
            st.error("Please fill in both password fields.")
        elif new_password != confirm_password:
            st.error("❌ Passwords do not match.")
        else:
            try:
                resp = requests.put(
                    f"{API_BASE}/auth/me/password",
                    params={"user_id": st.session_state["user_id"]},
                    json={"new_password": new_password},
                    timeout=10,
                )
                if resp.status_code == 200:
                    st.success("✅ Password changed successfully!")
                else:
                    st.error(f"❌ {resp.json().get('detail', 'Password update failed.')}")
            except requests.exceptions.ConnectionError:
                st.error("⚠️ Unable to connect to API server.")

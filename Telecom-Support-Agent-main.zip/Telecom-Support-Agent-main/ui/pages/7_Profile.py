"""Page 7: User Profile & Security — Obsidian Flux theme (dynamic)."""

from __future__ import annotations

import streamlit as st
import requests

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_auth
from ui.theme import (
    inject_css, noc_header, status_badge,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — Profile", page_icon="👤", layout="wide")
inject_css()
init_auth_state()
require_auth()
render_sidebar_profile()

API_BASE = st.session_state.get("api_base_url", "http://localhost:8000")

# ── Fetch user profile from API ──────────────────────────────────────────────
user_profile: dict = {}
try:
    resp = requests.get(
        f"{API_BASE}/auth/me",
        params={"user_id": st.session_state.get("user_id")},
        timeout=10,
    )
    if resp.status_code == 200:
        user_profile = resp.json()
except requests.exceptions.ConnectionError:
    pass

# Fall back to session state if API fails
user_name = user_profile.get("first_name", "") + " " + user_profile.get("last_name", "") if user_profile else st.session_state.get("user_name", "N/A")
user_email = user_profile.get("email", st.session_state.get("email", ""))
employee_id = user_profile.get("employee_id", st.session_state.get("employee_id", ""))
department = user_profile.get("department", st.session_state.get("department", ""))
location = user_profile.get("location", st.session_state.get("location", ""))
role = user_profile.get("role", st.session_state.get("role", "User"))
last_login = user_profile.get("last_login", st.session_state.get("last_login", ""))

# ── Fetch available departments & locations from existing users for dropdowns ─
departments: list[str] = ["Network Operations", "IT Infrastructure", "Security Operations", "Field Engineering", "Service Desk", "Cloud Operations", "Network Routing & Switching"]
locations: list[str] = ["North America Node Ashburn", "EU West London", "AP South Singapore", "Bengaluru", "Hyderabad", "Chennai", "Pune", "Mumbai", "Remote"]

try:
    all_users_resp = requests.get(f"{API_BASE}/auth/users", timeout=5)
    if all_users_resp.status_code == 200:
        all_users = all_users_resp.json()
        api_depts = sorted(set(u.get("department", "") for u in all_users if u.get("department")))
        api_locs = sorted(set(u.get("location", "") for u in all_users if u.get("location")))
        if api_depts:
            departments = list(dict.fromkeys(api_depts + departments))
        if api_locs:
            locations = list(dict.fromkeys(api_locs + locations))
except (requests.exceptions.ConnectionError, Exception):
    pass

# ── Header ───────────────────────────────────────────────────────────────────
hc1, hc2 = st.columns([5, 3])
with hc1:
    noc_header("User Profile & Security", "Manage your account details and credentials")
with hc2:
    tier = "3" if role == "Admin" else "2" if role == "Network Engineer" else "1"
    st.markdown(f"""
    <div style="display:flex;justify-content:flex-end;padding-top:12px;">
        {status_badge(f"Access Level: Tier {tier}", "green")}
    </div>
    """, unsafe_allow_html=True)

st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)

# ── Personal Info + Security ─────────────────────────────────────────────────
info_col, sec_col = st.columns([7, 5])

with info_col:
    initial = user_name.strip()[0].upper() if user_name.strip() else "?"
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:20px 24px;">
        <div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:16px;">Personal Information</div>
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;">
            <div style="width:64px;height:64px;border-radius:50%;background:{PRIMARY};display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;color:#0b1326;">
                {initial}
            </div>
            <div>
                <div style="font-size:16px;font-weight:600;color:{ON_SURFACE};">{user_name}</div>
                <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">{user_email}</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    with st.form("update_profile_form"):
        fc1, fc2 = st.columns(2)
        fc1.text_input("Full Name", value=user_name.strip(), disabled=True)
        fc2.text_input("Employee ID", value=employee_id, disabled=True)

        fc3, fc4 = st.columns(2)
        dept_index = departments.index(department) if department in departments else 0
        loc_index = locations.index(location) if location in locations else 0
        new_department = fc3.selectbox("Department", departments, index=dept_index)
        new_location = fc4.selectbox("Operational Location", locations, index=loc_index)

        if st.form_submit_button("Save Changes", use_container_width=True):
            try:
                resp = requests.put(
                    f"{API_BASE}/auth/me",
                    params={"user_id": st.session_state["user_id"]},
                    json={"department": new_department, "location": new_location},
                    timeout=10,
                )
                if resp.status_code == 200:
                    st.session_state["department"] = new_department
                    st.session_state["location"] = new_location
                    st.success("Profile updated successfully!")
                else:
                    st.error(f"Update failed: {resp.json().get('detail', 'Unknown error')}")
            except requests.exceptions.ConnectionError:
                st.error("Unable to connect to API server.")

with sec_col:
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:20px 24px;">
        <div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:16px;">Security Management</div>
    </div>
    """, unsafe_allow_html=True)

    with st.form("change_password_form"):
        current_pw = st.text_input("Current Password", type="password")
        new_password = st.text_input("New Password", type="password")
        confirm_password = st.text_input("Confirm New Password", type="password")

        has_len = len(new_password) >= 8 if new_password else False
        has_case = (any(c.isupper() for c in new_password) and any(c.islower() for c in new_password)) if new_password else False
        has_num = any(c.isdigit() for c in new_password) if new_password else False
        has_special = any(c in "!@#$%^&*()_+-=[]{}|;:',.<>?/`~" for c in new_password) if new_password else False

        reqs = [("Min 8 characters", has_len), ("Uppercase & lowercase", has_case), ("At least one number", has_num), ("Special character", has_special)]
        req_html = ""
        for label, met in reqs:
            icon = f'<span style="color:{TERTIARY};">✓</span>' if met else f'<span style="color:{ON_SURFACE_VARIANT};">○</span>'
            color = TERTIARY if met else ON_SURFACE_VARIANT
            req_html += f'<div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{color};margin-bottom:2px;">{icon} {label}</div>'

        st.markdown(f"""
        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:8px;padding:10px 14px;margin:8px 0 12px 0;">
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">Password Requirements</div>
            {req_html}
        </div>
        """, unsafe_allow_html=True)

        if st.form_submit_button("Update Password", use_container_width=True):
            if not new_password or not confirm_password:
                st.error("Please fill in both password fields.")
            elif new_password != confirm_password:
                st.error("Passwords do not match.")
            else:
                try:
                    resp = requests.put(
                        f"{API_BASE}/auth/me/password",
                        params={"user_id": st.session_state["user_id"]},
                        json={"new_password": new_password},
                        timeout=10,
                    )
                    if resp.status_code == 200:
                        st.success("Password changed successfully!")
                    else:
                        st.error(resp.json().get("detail", "Password update failed."))
                except requests.exceptions.ConnectionError:
                    st.error("Unable to connect to API server.")

    # Account metadata
    if last_login:
        st.markdown(f"""
        <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};margin-top:8px;">
            Last login: <span style="color:{SECONDARY};">{last_login}</span>
        </div>
        """, unsafe_allow_html=True)

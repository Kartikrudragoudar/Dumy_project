"""Page 6: System Administration — Obsidian Flux theme (dynamic)."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ApiClient
from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.state import init_state
from ui.theme import (
    inject_css, noc_header, status_badge, terminal_block,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — Admin Panel", page_icon="⚙️", layout="wide")
inject_css()
init_auth_state()
require_role("Admin Panel")
render_sidebar_profile()
init_state()

client: ApiClient = st.session_state.client

# ── Fetch live system data ───────────────────────────────────────────────────
readiness = client.readyz() or {}
checks = readiness.get("checks", {})
llm_info = client.llm_health()
config = client.system_config()
kb_info = client.kb_docs()

index_ok = checks.get("index", False)
db_ok = checks.get("db", False)
total_chunks = kb_info.get("total_chunks", 0)
total_docs = kb_info.get("total_docs", 0)

tracing_enabled = config.get("langchain_tracing_v2", False)
langchain_project = config.get("langchain_project", "—")

cb_state = llm_info.get("circuit_breaker", "UNKNOWN")
active_prov = llm_info.get("active_provider", "—")
cooldown = llm_info.get("cooldown_seconds", config.get("llm_breaker_cooldown_seconds", 60))
failover = llm_info.get("failover_enabled", config.get("llm_failover_enabled", False))

noc_header("System Administration", "Vector Store, Observability & Configuration Management")

# ── Status Cards ─────────────────────────────────────────────────────────────
sc1, sc2, sc3 = st.columns(3)

with sc1:
    faiss_color = TERTIARY if index_ok else ERROR
    faiss_text = "Healthy" if index_ok else "Offline"
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <span style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};">FAISS Vector Store</span>
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{faiss_color};box-shadow:0 0 6px {faiss_color};"></span>
        </div>
        <div style="font-size:20px;font-weight:700;color:{ON_SURFACE};margin-bottom:4px;">{faiss_text}</div>
        <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">{total_chunks:,} Chunks · IndexFlatIP</div>
    </div>
    """, unsafe_allow_html=True)
    st.button("Trigger Re-index", key="reindex_btn", use_container_width=True)

with sc2:
    trace_color = SECONDARY if tracing_enabled else ON_SURFACE_VARIANT
    trace_text = "Connected" if tracing_enabled else "Disabled"
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <span style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};">LangSmith Tracing</span>
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{trace_color};box-shadow:0 0 6px {trace_color};"></span>
        </div>
        <div style="font-size:20px;font-weight:700;color:{ON_SURFACE};margin-bottom:4px;">{trace_text}</div>
        <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">Project: {langchain_project}</div>
    </div>
    """, unsafe_allow_html=True)

with sc3:
    cb_color = TERTIARY if cb_state == "CLOSED" else ERROR
    cb_label = "Primary Active" if cb_state == "CLOSED" else "Failover Active"
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <span style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};">LLM Circuit Breaker</span>
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{cb_color};box-shadow:0 0 6px {cb_color};"></span>
        </div>
        <div style="font-size:20px;font-weight:700;color:{ON_SURFACE};margin-bottom:4px;">{cb_label}</div>
        <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">Active: {active_prov.replace('_', ' ').title()} · Cooldown: {cooldown}s</div>
    </div>
    """, unsafe_allow_html=True)
    st.button("Test Failover", key="failover_btn", use_container_width=True)

st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

# ── SOP Ingestion + Active KB ────────────────────────────────────────────────
ing_col, kb_col = st.columns([3, 2])

with ing_col:
    st.markdown(f'<div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:12px;">SOP & Runbook Ingestion</div>', unsafe_allow_html=True)

    uploaded_file = st.file_uploader("Upload SOP/Runbook (PDF, TXT, MD)", type=["txt", "pdf", "md"], label_visibility="collapsed")

    embed_model = config.get("embedding_model", "bge-small-en-v1.5")
    oc1, oc2, oc3 = st.columns(3)
    auto_chunk = oc1.checkbox(f"Auto-Chunking ({config.get('session_token_budget', 500)}/50)", value=True)
    gen_embed = oc2.checkbox(f"Embeddings ({embed_model})", value=True)
    rebuild_bm25 = oc3.checkbox("Rebuild BM25", value=True)

    if uploaded_file:
        st.progress(78, text="Processing... 78%")
        if st.button("Ingest Document", use_container_width=True):
            st.success(f"Successfully processed `{uploaded_file.name}` and indexed into FAISS!")

    # Ingestion log placeholder (shows real config info)
    index_dir = config.get("index_dir", "./data/index")
    st.markdown(terminal_block([
        f'<span style="color:{ON_SURFACE_VARIANT};">[system]</span> <span style="color:{TERTIARY};">INFO</span> FAISS index at: {index_dir}',
        f'<span style="color:{ON_SURFACE_VARIANT};">[system]</span> <span style="color:{TERTIARY};">INFO</span> Total indexed chunks: {total_chunks:,}',
        f'<span style="color:{ON_SURFACE_VARIANT};">[system]</span> <span style="color:{TERTIARY};">INFO</span> Embedding model: {embed_model}',
        f'<span style="color:{ON_SURFACE_VARIANT};">[system]</span> <span style="color:{SECONDARY};">CONFIG</span> DB: {config.get("database_url", "—")}',
        f'<span style="color:{ON_SURFACE_VARIANT};">[system]</span> <span style="color:{TERTIARY};">INFO</span> Ready for document ingestion',
    ]), unsafe_allow_html=True)

with kb_col:
    st.markdown(f"""
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <span style="font-weight:600;color:{ON_SURFACE};font-size:15px;">Active Knowledge Base</span>
        {status_badge(f"{total_docs} Docs", "purple")}
    </div>
    """, unsafe_allow_html=True)

    # KB table header
    st.markdown(f"""
    <div style="display:flex;padding:8px 12px;font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;color:{ON_SURFACE_VARIANT};background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:8px 8px 0 0;">
        <div style="width:55%;">Document</div>
        <div style="width:20%;">Chunks</div>
        <div style="width:25%;">Sections</div>
    </div>
    """, unsafe_allow_html=True)

    documents = kb_info.get("documents", [])
    if not documents:
        st.markdown(f"""
        <div style="text-align:center;padding:30px 12px;border:1px solid {OUTLINE_VARIANT};border-top:none;border-radius:0 0 8px 8px;color:{ON_SURFACE_VARIANT};font-size:12px;">
            No documents in the knowledge base.
        </div>
        """, unsafe_allow_html=True)
    else:
        for doc in documents[:15]:
            doc_id = doc.get("doc_id", "unknown")
            chunks = doc.get("chunks", 0)
            sections = doc.get("sections", [])
            section_display = ", ".join(sections[:2]) if sections else "—"
            st.markdown(f"""
            <div style="display:flex;align-items:center;padding:8px 12px;border-bottom:1px solid {OUTLINE_VARIANT};border-left:1px solid {OUTLINE_VARIANT};border-right:1px solid {OUTLINE_VARIANT};font-size:12px;">
                <div style="width:55%;color:{ON_SURFACE};font-family:JetBrains Mono,monospace;font-size:11px;">{doc_id}</div>
                <div style="width:20%;color:{ON_SURFACE_VARIANT};">{chunks}</div>
                <div style="width:25%;">{status_badge(section_display, "gray")}</div>
            </div>
            """, unsafe_allow_html=True)

st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

# ── System Parameters ────────────────────────────────────────────────────────
st.markdown(f'<div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:12px;">System Parameters</div>', unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["LLM Guards", "Retrieval", "DB & Logs"])

with tab1:
    gc1, gc2, gc3 = st.columns(3)
    token_budget = gc1.number_input("Token Budget", value=config.get("session_token_budget", 500), step=50)
    timeout = gc2.number_input("Timeout Threshold (sec)", value=config.get("llm_request_timeout_seconds", 20), step=5)
    cooldown_val = gc3.number_input("Breaker Cooldown (sec)", value=config.get("llm_breaker_cooldown_seconds", 60), step=10)
    st.button("Save Config", key="save_llm_guards", use_container_width=True)

with tab2:
    rc1, rc2 = st.columns(2)
    top_k = rc1.number_input("Top-K Results", value=config.get("retrieval_top_k", 8), step=1)
    score_cutoff = rc2.number_input("Score Cutoff", value=config.get("retrieval_score_floor", 0.35), step=0.05, format="%.2f")
    st.button("Save Config", key="save_retrieval", use_container_width=True)

with tab3:
    index_dir = config.get("index_dir", "./data/index")
    db_url = config.get("database_url", "sqlite:///./data/app.db")
    st.markdown(f"""
    <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};margin-top:8px;">
        FAISS Index: <span style="color:{PRIMARY};">{index_dir}</span><br>
        KB Source: <span style="color:{PRIMARY};">{config.get("kb_dir", "./data/kb")}</span><br>
        DB: <span style="color:{PRIMARY};">{db_url}</span><br>
        LLM Provider: <span style="color:{PRIMARY};">{config.get("llm_provider", "—")}</span><br>
        Azure Deployment: <span style="color:{PRIMARY};">{config.get("azure_ai_deployment", "—")}</span>
    </div>
    """, unsafe_allow_html=True)

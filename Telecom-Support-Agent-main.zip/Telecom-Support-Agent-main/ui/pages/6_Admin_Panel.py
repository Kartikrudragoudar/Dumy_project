"""Page 6: Admin Panel (Admin Only)."""

from __future__ import annotations

import streamlit as st

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role

st.set_page_config(page_title="Admin Panel", page_icon="⚙️", layout="wide")

init_auth_state()
require_role("Admin Panel")
render_sidebar_profile()

st.title("⚙️ Admin & System Settings")
st.caption("Manage SOP Documents, Rebuild FAISS Index & View Observability")

st.subheader("📤 Document Management (FAISS Ingestion)")

uploaded_file = st.file_uploader("Upload Network SOP / Manual (TXT or PDF)", type=["txt", "pdf"])

if uploaded_file and st.button("🚀 Ingest Document into FAISS"):
    st.success(f"Successfully processed `{uploaded_file.name}` and indexed chunks into FAISS!")

st.markdown("---")

st.subheader("🛠️ Index Management")
if st.button("🔄 Rebuild FAISS Vector Index"):
    st.info("FAISS vector index rebuilt successfully from `./data/sop_docs`.")

st.markdown("---")

st.subheader("🔍 Observability & Tracing")
st.markdown("""
- **LangSmith Tracing Project:** `network-support-assistant`
- **Tracing Status:** `ENABLED (v2)`
- **Vector DB:** `FAISS IndexFlatIP` (`./data/index`)
""")

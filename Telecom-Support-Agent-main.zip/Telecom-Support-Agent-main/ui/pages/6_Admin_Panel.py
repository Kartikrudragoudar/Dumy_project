"""Page 6: Admin Panel."""

from __future__ import annotations

import streamlit as st

st.set_page_config(page_title="Admin Panel", page_icon="⚙️", layout="wide")

st.title("⚙️ Admin & System Settings")
st.caption("Manage SOP Documents, Rebuild ChromaDB & View Observability")

st.subheader("📤 Document Management (ChromaDB Ingestion)")

uploaded_file = st.file_uploader("Upload Network SOP / Manual (TXT or PDF)", type=["txt", "pdf"])

if uploaded_file and st.button("🚀 Ingest Document into ChromaDB"):
    st.success(f"Successfully processed `{uploaded_file.name}` and indexed chunks into ChromaDB!")

st.markdown("---")

st.subheader("🛠️ Index Management")
if st.button("🔄 Rebuild ChromaDB Vector Index"):
    st.info("ChromaDB vector store rebuilt successfully from `./data/sop_docs`.")

st.markdown("---")

st.subheader("🔍 Observability & Tracing")
st.markdown("""
- **LangSmith Tracing Project:** `network-support-assistant`
- **Tracing Status:** `ENABLED (v2)`
- **Vector DB Client:** `ChromaDB PersistentClient` (`./data/chroma_db`)
""")

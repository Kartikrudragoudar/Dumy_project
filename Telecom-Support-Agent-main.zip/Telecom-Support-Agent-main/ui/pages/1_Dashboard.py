"""Page 1: NOC Operations Dashboard — Obsidian Flux theme (dynamic data)."""

from __future__ import annotations

from datetime import datetime

import streamlit as st

from ui.api_client import ApiClient
from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.state import init_state
from ui.theme import (
    inject_css, noc_header, kpi_card, status_badge,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — Dashboard", page_icon="📊", layout="wide")
inject_css()
init_auth_state()
require_role("Dashboard")
render_sidebar_profile()
init_state()

client: ApiClient = st.session_state.client

# ── Fetch live data ──────────────────────────────────────────────────────────
tickets = client.list_tickets(limit=200)
readiness = client.readyz() or {}
checks = readiness.get("checks", {})

# Derive KPIs from live tickets
open_tickets = [t for t in tickets if t.get("status") in ("OPEN", "IN_PROGRESS")]
critical_tickets = [t for t in open_tickets if t.get("priority") in ("Critical", "P1")]
resolved_tickets = [t for t in tickets if t.get("status") == "RESOLVED"]
closed_tickets = [t for t in tickets if t.get("status") == "CLOSED"]
total_done = len(resolved_tickets) + len(closed_tickets)

noc_header("NOC Operations Dashboard", "Real-time Network Health, Incident Metrics & AI Activity")

# ── KPI Row ──────────────────────────────────────────────────────────────────
c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(kpi_card("Total Incidents", str(len(tickets)), f"{len(open_tickets)} open", "📋", PRIMARY), unsafe_allow_html=True)
with c2:
    st.markdown(kpi_card("Critical / P1", str(len(critical_tickets)), f"of {len(open_tickets)} open", "⚠️", ERROR), unsafe_allow_html=True)
with c3:
    st.markdown(kpi_card("Resolved", str(total_done), f"{len(resolved_tickets)} resolved + {len(closed_tickets)} closed", "✅", TERTIARY), unsafe_allow_html=True)
with c4:
    api_ok = client.health()
    uptime_text = "Online" if api_ok else "Offline"
    up_color = TERTIARY if api_ok else ERROR
    st.markdown(kpi_card("System Status", uptime_text, "API + Backend", "🌐", up_color), unsafe_allow_html=True)

st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

if st.button("🔄 Refresh Data", use_container_width=False):
    st.rerun()

# ── Recent Incidents + Live AI Feed ──────────────────────────────────────────
col_left, col_right = st.columns([2, 1])

# Status / priority mappings
_STATUS_COLOR = {"OPEN": "red", "IN_PROGRESS": "blue", "RESOLVED": "green", "CLOSED": "gray"}
_PRIO_COLOR = {"Critical": ERROR, "P1": ERROR, "High": SECONDARY, "P2": SECONDARY, "Medium": ON_SURFACE_VARIANT, "P3": ON_SURFACE_VARIANT, "Low": ON_SURFACE_VARIANT, "P4": ON_SURFACE_VARIANT}
_PRIO_LABEL = {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4"}
_CAT_DISPLAY = {
    "vpn_issue": "VPN", "dns_issue": "DNS", "wifi_issue": "WiFi", "router_issue": "Router",
    "internet_down": "Outage", "slow_internet": "Slow Net", "firewall_issue": "Firewall",
    "email_issue": "Email", "account_access_issue": "Auth", "network_outage": "Outage", "other": "Other",
}

with col_left:
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <span style="font-weight:600;color:{ON_SURFACE};font-size:15px;">Recent Incidents</span>
            <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};text-transform:uppercase;">Live · {len(tickets)} total</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Show the 10 most recent tickets (sorted newest first by created_at)
    display_tickets = sorted(tickets, key=lambda t: t.get("created_at", ""), reverse=True)[:10]

    if not display_tickets:
        st.markdown(f"""
        <div style="text-align:center;padding:40px 20px;color:{ON_SURFACE_VARIANT};">
            <div style="font-size:28px;margin-bottom:8px;">📋</div>
            <p style="font-size:13px;">No incidents found. The system is quiet.</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        for t in display_tickets:
            tid = t.get("ticket_id", "N/A")
            summary = t.get("summary", "No summary")[:80]
            prio = t.get("priority", "Medium")
            stat = t.get("status", "OPEN")
            queue = t.get("queue", "—")
            cat = t.get("category", "other")
            created = t.get("created_at", "")[:16]

            p_display = _PRIO_LABEL.get(prio, prio)
            p_color = _PRIO_COLOR.get(prio, ON_SURFACE_VARIANT)
            s_color = _STATUS_COLOR.get(stat, "gray")
            cat_display = _CAT_DISPLAY.get(cat, cat)

            st.markdown(f"""
            <div style="display:flex;align-items:center;padding:10px 20px;border-bottom:1px solid {OUTLINE_VARIANT};gap:10px;font-size:13px;">
                <div style="width:12%;">{status_badge(stat.replace('_', ' ').title(), s_color)}</div>
                <div style="width:12%;font-family:JetBrains Mono,monospace;color:{PRIMARY};font-size:12px;">{tid}</div>
                <div style="width:8%;">{status_badge(cat_display, 'blue')}</div>
                <div style="width:32%;color:{ON_SURFACE};">{summary}</div>
                <div style="width:14%;color:{ON_SURFACE_VARIANT};font-size:11px;">{queue}</div>
                <div style="width:8%;font-family:JetBrains Mono,monospace;color:{p_color};font-weight:600;font-size:12px;">{p_display}</div>
                <div style="width:14%;font-family:JetBrains Mono,monospace;color:{ON_SURFACE_VARIANT};font-size:10px;">{created}</div>
            </div>
            """, unsafe_allow_html=True)

with col_right:
    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;margin-bottom:12px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{TERTIARY};box-shadow:0 0 6px {TERTIARY};"></span>
            <span style="font-weight:600;color:{ON_SURFACE};font-size:15px;">Live AI Feed</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Build feed entries dynamically from recent tickets
    now = datetime.now()
    feed_entries: list[tuple[str, str, str, str]] = []

    for t in sorted(tickets, key=lambda x: x.get("created_at", ""), reverse=True)[:6]:
        tid = t.get("ticket_id", "?")
        cat = _CAT_DISPLAY.get(t.get("category", ""), "Issue")
        stat = t.get("status", "OPEN")
        prio = _PRIO_LABEL.get(t.get("priority", ""), t.get("priority", ""))
        ts = t.get("created_at", "")
        ts_display = ts[11:19] if len(ts) > 18 else ts[:8]

        if stat == "RESOLVED":
            feed_entries.append((TERTIARY, "RESOLVED", ts_display, f"{tid} ({cat}) resolved by AI triage pipeline."))
        elif stat == "IN_PROGRESS":
            feed_entries.append((SECONDARY, "DIAGNOSTIC", ts_display, f"{tid} ({cat}) — diagnostic agent investigating. Priority: {prio}."))
        elif prio in ("P1", "Critical"):
            feed_entries.append((ERROR, "CRITICAL", ts_display, f"{tid} ({cat}) — escalated. Priority: {prio}. SLA active."))
        else:
            feed_entries.append((PRIMARY, "TRIAGE", ts_display, f"{tid} ({cat}) — auto-triage initiated. Priority: {prio}."))

    if not feed_entries:
        feed_entries = [(TERTIARY, "IDLE", now.strftime("%H:%M:%S"), "No recent activity. System is idle.")]

    feed_html = ""
    for color, label, ts, text in feed_entries:
        feed_html += f"""
        <div style="border-left:3px solid {color};padding:6px 10px;margin-bottom:8px;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <span style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{color};letter-spacing:0.04em;">{label}</span>
                <span style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">{ts}</span>
            </div>
            <div style="font-size:12px;color:{ON_SURFACE};margin-top:2px;">{text}</div>
        </div>"""

    st.markdown(f"""
    <div style="background:#000;border:1px solid {OUTLINE_VARIANT};border-radius:8px;padding:12px;max-height:340px;overflow-y:auto;font-family:JetBrains Mono,monospace;">
        {feed_html}
        <div style="color:{TERTIARY};font-size:12px;animation:blink 1s step-end infinite;">▌</div>
    </div>
    <style>@keyframes blink {{ 0%,100% {{ opacity:1; }} 50% {{ opacity:0; }} }}</style>
    """, unsafe_allow_html=True)

# ── Infrastructure Status (from /readyz) ─────────────────────────────────────
st.markdown("<div style='height:16px;'></div>", unsafe_allow_html=True)
st.markdown(f'<div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:12px;">Infrastructure Status</div>', unsafe_allow_html=True)

index_ok = checks.get("index", False)
db_ok = checks.get("db", False)
llm_azure = checks.get("llm_AZURE_FOUNDRY", checks.get("llm_azure_foundry", False))
llm_groq = checks.get("llm_GROQ", checks.get("llm_groq", False))

infra = [
    ("Primary LLM", "Azure AI Foundry (GPT-4.1)", "Active" if llm_azure else "Down", "green" if llm_azure else "red"),
    ("Backup LLM", "Groq (Llama 3.1 70B)", "Active" if llm_groq else ("Standby" if llm_azure else "Down"), "green" if llm_groq else ("blue" if llm_azure else "red")),
    ("Vector Store", "FAISS + BM25", "Synced" if index_ok else "Offline", "green" if index_ok else "red"),
    ("Database", "SQLite / Ticket Store", "Writable" if db_ok else "Error", "green" if db_ok else "red"),
]

inf_cols = st.columns(4)
for col, (name, detail, stat, variant) in zip(inf_cols, infra):
    dot_c = TERTIARY if variant == "green" else (SECONDARY if variant == "blue" else ERROR)
    with col:
        st.markdown(f"""
        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:14px 16px;">
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;color:{ON_SURFACE_VARIANT};margin-bottom:6px;">{name}</div>
            <div style="font-size:13px;color:{ON_SURFACE};margin-bottom:4px;">{detail}</div>
            <div style="display:flex;align-items:center;gap:6px;">
                <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{dot_c};box-shadow:0 0 6px {dot_c};"></span>
                <span style="font-family:JetBrains Mono,monospace;font-size:11px;color:{dot_c};">{stat}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

# ── Category Breakdown ───────────────────────────────────────────────────────
if tickets:
    st.markdown("<div style='height:16px;'></div>", unsafe_allow_html=True)
    st.markdown(f'<div style="font-weight:600;color:{ON_SURFACE};font-size:15px;margin-bottom:12px;">Incident Breakdown by Category</div>', unsafe_allow_html=True)

    from collections import Counter
    cat_counts = Counter(t.get("category", "other") for t in tickets)
    sorted_cats = cat_counts.most_common(8)

    cat_cols = st.columns(min(len(sorted_cats), 4))
    for i, (cat, count) in enumerate(sorted_cats):
        with cat_cols[i % len(cat_cols)]:
            display = _CAT_DISPLAY.get(cat, cat)
            pct = round(count / len(tickets) * 100, 1)
            st.markdown(f"""
            <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:12px 16px;margin-bottom:8px;">
                <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;color:{ON_SURFACE_VARIANT};">{display}</div>
                <div style="font-size:22px;font-weight:700;color:{PRIMARY};font-family:JetBrains Mono,monospace;">{count}</div>
                <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{ON_SURFACE_VARIANT};">{pct}%</div>
            </div>
            """, unsafe_allow_html=True)

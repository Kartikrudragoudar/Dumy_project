"""Page 1: NOC Operations Dashboard."""

from __future__ import annotations

import streamlit as st

st.set_page_config(page_title="NOC Dashboard", page_icon="📊", layout="wide")

st.title("📊 NOC Operations Dashboard")
st.caption("Real-time Network Health, Incident Metrics & Ticket Activity")

# Top Metrics
col1, col2, col3, col4 = st.columns(4)
col1.metric("Open Incidents", "14", delta="-2")
col2.metric("Critical Outages", "1", delta="0", delta_color="inverse")
col3.metric("Resolved Today", "28", delta="+5")
col4.metric("Network Health", "98.4%", delta="+0.2%")

st.markdown("---")

# Incident Summary & Network Health
col_left, col_right = st.columns([2, 1])

with col_left:
    st.subheader("🔥 Active Critical Incidents")
    st.error("🚨 **NET-1001**: Regional Gateway Unreachable in Region AP-East (Impact: High)")
    st.warning("⚠️ **NET-1004**: High Latency detected on Core Router CR-04 (Impact: Medium)")

    st.subheader("🕒 Recent Ticket Activity")
    tickets_data = [
        {"ID": "NET-1001", "Category": "vpn_issue", "Priority": "Critical", "Status": "OPEN", "Team": "Network Operations"},
        {"ID": "NET-1002", "Category": "wifi_issue", "Priority": "Medium", "Status": "IN_PROGRESS", "Team": "Service Desk L1"},
        {"ID": "NET-1003", "Category": "dns_issue", "Priority": "High", "Status": "RESOLVED", "Team": "System Administration"},
        {"ID": "NET-1004", "Category": "router_issue", "Priority": "Critical", "Status": "OPEN", "Team": "Network Operations"},
    ]
    st.table(tickets_data)

with col_right:
    st.subheader("📡 Infrastructure Status")
    st.success("🟢 VPN Gateways: Healthy (99.8%)")
    st.success("🟢 Core DNS Clusters: Healthy (100%)")
    st.warning("🟡 Regional AP Controllers: Degraded (94.2%)")
    st.success("🟢 Core Switches: Healthy (99.9%)")

    st.markdown("---")
    st.subheader("⚡ Quick Actions")
    if st.button("🔄 Refresh System Health", use_container_width=True):
        st.toast("System status updated!", icon="✅")

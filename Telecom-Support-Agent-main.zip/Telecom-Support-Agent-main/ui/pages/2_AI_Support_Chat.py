"""Page 2: AI Triage Chat — Obsidian Flux theme (dynamic pipeline)."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ApiClient
from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.state import init_state, reset_chat
from ui.theme import (
    inject_css, noc_header, status_badge,
    SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT,
    PRIMARY, SECONDARY, TERTIARY, ERROR,
)

st.set_page_config(page_title="NOC — AI Triage Chat", page_icon="💬", layout="wide")
inject_css()
init_auth_state()
require_role("AI Support Chat")
render_sidebar_profile()
init_state()

client: ApiClient = st.session_state.client

# ── Header bar ───────────────────────────────────────────────────────────────
hdr_c1, hdr_c2, hdr_c3 = st.columns([5, 3, 2])
with hdr_c1:
    st.markdown(f"""
    <div>
        <span style="font-size:20px;font-weight:700;color:{ON_SURFACE};">NOC Intelligent Triage Assistant</span>
        <span style="margin-left:10px;">{status_badge(f"SID-{st.session_state.session_id[-8:]}", "purple")}</span>
    </div>
    """, unsafe_allow_html=True)
with hdr_c3:
    if st.button("New Session", use_container_width=True):
        reset_chat()
        st.rerun()

st.markdown(f'<div style="border-top:1px solid {OUTLINE_VARIANT};margin:8px 0 16px 0;"></div>', unsafe_allow_html=True)

# ── Main layout: Chat (70%) + Pipeline (30%) ────────────────────────────────
chat_col, pipe_col = st.columns([7, 3])

with chat_col:
    chat_container = st.container(height=480)
    with chat_container:
        if not st.session_state.messages:
            st.markdown(f"""
            <div style="text-align:center;padding:80px 20px;color:{ON_SURFACE_VARIANT};">
                <div style="font-size:36px;margin-bottom:12px;">💬</div>
                <p style="font-size:14px;">Describe a network issue to trigger multi-agent triage.</p>
                <p style="font-size:12px;font-family:JetBrains Mono,monospace;color:{PRIMARY};">Try: "VPN gateway timeout for users in AP-East region"</p>
            </div>
            """, unsafe_allow_html=True)
        else:
            for msg in st.session_state.messages:
                role = msg["role"]
                content = msg["content"]
                if role == "user":
                    st.markdown(f"""
                    <div style="display:flex;justify-content:flex-end;margin-bottom:12px;">
                        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px 12px 2px 12px;padding:12px 16px;max-width:75%;">
                            <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{SECONDARY};text-transform:uppercase;margin-bottom:4px;">Network Engineer</div>
                            <div style="color:{ON_SURFACE};font-size:13px;">{content}</div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    meta = msg.get("meta", {})
                    citations_html = ""
                    if meta.get("citations"):
                        for cit in meta["citations"][:2]:
                            score = cit.get("score", 0)
                            citations_html += f"""
                            <div style="border-left:3px solid {PRIMARY};padding:6px 10px;margin-top:8px;background:rgba(192,193,255,0.05);border-radius:0 6px 6px 0;">
                                <div style="font-family:JetBrains Mono,monospace;font-size:11px;color:{PRIMARY};">{cit.get('title', 'SOP Reference')} {status_badge(f"{int(score*100)}% Match", "purple")}</div>
                                <div style="font-size:11px;color:{ON_SURFACE_VARIANT};margin-top:2px;">{cit.get('snippet', '')[:120]}</div>
                            </div>"""

                    st.markdown(f"""
                    <div style="display:flex;justify-content:flex-start;margin-bottom:12px;">
                        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px 12px 12px 2px;padding:12px 16px;max-width:80%;">
                            <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{TERTIARY};text-transform:uppercase;margin-bottom:4px;">Triage Assistant</div>
                            <div style="color:{ON_SURFACE};font-size:13px;line-height:1.5;">{content}</div>
                            {citations_html}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

    # Chat input
    with st.form("chat_input", clear_on_submit=True):
        ic1, ic2 = st.columns([6, 1])
        user_msg = ic1.text_input("message", placeholder="Describe your network issue...", label_visibility="collapsed")
        send = ic2.form_submit_button("Send", use_container_width=True)

    if send and user_msg:
        st.session_state.messages.append({"role": "user", "content": user_msg})
        try:
            resp = client.chat(user_msg, st.session_state.session_id)
            st.session_state.messages.append({
                "role": "assistant",
                "content": resp.answer,
                "meta": {
                    "trace_id": resp.trace_id,
                    "category": resp.category,
                    "priority": resp.priority,
                    "citations": resp.citations,
                    "latency_ms": resp.latency_ms,
                    "llm": resp.llm,
                    "ticket": resp.ticket,
                },
            })
        except Exception as e:
            st.session_state.messages.append({
                "role": "assistant",
                "content": f"Error: Unable to process request. {e}",
                "meta": {},
            })
        st.rerun()

with pipe_col:
    # Get last response metadata for pipeline display
    last_meta = {}
    if st.session_state.messages:
        for m in reversed(st.session_state.messages):
            if m["role"] == "assistant" and m.get("meta"):
                last_meta = m["meta"]
                break

    has_response = bool(last_meta)
    latency = last_meta.get("latency_ms", 0)
    llm_info = last_meta.get("llm", {})
    category = last_meta.get("category", "")
    priority = last_meta.get("priority", "")
    provider_name = llm_info.get("provider", llm_info.get("model", "—"))
    model_name = llm_info.get("model", "—")
    citations = last_meta.get("citations", [])

    latency_display = f"{latency}ms" if latency else "—"

    st.markdown(f"""
    <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:16px 20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
            <span style="font-weight:600;color:{ON_SURFACE};font-size:14px;">Execution Pipeline</span>
            <span style="font-family:JetBrains Mono,monospace;font-size:11px;color:{SECONDARY};">
                {status_badge(latency_display, "blue")}
            </span>
        </div>
    """, unsafe_allow_html=True)

    # Build pipeline steps dynamically from response metadata
    pipeline_steps = [
        ("Intent Classification Agent", f"Intent: {category} | Priority: {priority}" if category else ""),
        ("Diagnostic Agent", f"Domain: {category.replace('_', '/').title()}" if category else ""),
        ("RAG Agent", f"Retrieved {len(citations)} SOP passages from FAISS" if citations else ""),
        ("Resolution Agent", "Answer generated" if has_response else ""),
        ("Ticket Agent", f"Ticket: {last_meta.get('ticket', {}).get('ticket_id', '')}" if last_meta.get("ticket") else ""),
        ("Escalation Agent", ""),
    ]

    for i, (name, output) in enumerate(pipeline_steps):
        if has_response:
            if output:
                icon = f'<span style="color:{TERTIARY};font-size:14px;">✓</span>'
                line_color = TERTIARY
            elif i <= 3:
                icon = f'<span style="color:{TERTIARY};font-size:14px;">✓</span>'
                line_color = TERTIARY
            else:
                icon = f'<span style="color:{ON_SURFACE_VARIANT};font-size:14px;">○</span>'
                line_color = OUTLINE_VARIANT
        else:
            if i == 0 and st.session_state.messages:
                icon = f'<span style="color:{SECONDARY};font-size:14px;">◉</span>'
                line_color = SECONDARY
            else:
                icon = f'<span style="color:{ON_SURFACE_VARIANT};font-size:14px;">○</span>'
                line_color = OUTLINE_VARIANT

        connector = f'<div style="border-left:2px solid {line_color};height:12px;margin-left:7px;"></div>' if i < 5 else ""
        output_html = f'<div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};margin-top:2px;">{output}</div>' if output else ""

        st.markdown(f"""
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:2px;">
            <div>{icon}</div>
            <div>
                <div style="font-size:12px;color:{ON_SURFACE};font-weight:500;">{name}</div>
                {output_html}
            </div>
        </div>
        {connector}
        """, unsafe_allow_html=True)

    # Footer from actual response metadata
    st.markdown(f"""
        <div style="border-top:1px solid {OUTLINE_VARIANT};margin-top:12px;padding-top:10px;">
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};">
                <span>Routing: {provider_name} {model_name}</span><br>
                <span>Total Latency: {latency_display}</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

"""Page 2: AI Support Chat with Multi-Agent Triage."""

from __future__ import annotations

import streamlit as st

from ui.auth_manager import init_auth_state, render_sidebar_profile, require_role
from ui.components.chat_panel import render_chat_panel
from ui.components.citation_card import render_citations
from ui.components.debug_drawer import render_debug_drawer
from ui.components.degraded_banner import render_degraded_banner
from ui.components.feedback_widget import render_feedback
from ui.components.ticket_panel import render_ticket_panel
from ui.state import init_state, reset_chat

st.set_page_config(page_title="AI Support Chat", page_icon="💬", layout="wide")

init_auth_state()
require_role("AI Support Chat")
render_sidebar_profile()

init_state()

with st.sidebar:
    st.title("🤖 Multi-Agent Triage")
    st.caption("NOC Autonomous Support")
    st.markdown("---")
    st.markdown(f"**Session:** `{st.session_state.session_id}`")

    if st.button("🔄 New Conversation", use_container_width=True):
        reset_chat()
        st.rerun()

    st.markdown("---")
    st.markdown(
        "**Multi-Agent Hierarchy:**\n"
        "- 👑 Supervisor Agent\n"
        "- 🎯 Intent Classifier\n"
        "- 🔀 Diagnostic Router\n"
        "- 🔧 Specialized Diagnostic (VPN/WiFi/DNS/Router)\n"
        "- 📚 RAG Agent (FAISS)\n"
        "- 🛠️ Resolution Agent\n"
        "- 🎫 Ticket & Escalation Agents"
    )

render_degraded_banner()

st.title("💬 AI Support Chat")
st.caption("Ask network questions or report incidents to trigger automated multi-agent triage.")

render_chat_panel()

if st.session_state.messages:
    last = st.session_state.messages[-1]
    if last["role"] == "assistant" and last.get("meta"):
        meta = last["meta"]
        st.markdown("---")
        render_citations(meta)
        render_feedback(meta)
        render_debug_drawer(meta)
        render_ticket_panel(meta)

"""Thumbs up/down feedback widget per response."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ChatMessage


def render_feedback(response: ChatMessage) -> None:
    """Inline thumbs up/down buttons for the latest response."""
    col1, col2, col3 = st.columns([1, 1, 8])
    key_prefix = response.trace_id

    with col1:
        if st.button("👍", key=f"up_{key_prefix}"):
            ok = st.session_state.client.send_feedback(
                trace_id=response.trace_id,
                session_id=response.session_id,
                thumbs="up",
            )
            if ok:
                st.toast("Thanks for the feedback!", icon="✅")
    with col2:
        if st.button("👎", key=f"down_{key_prefix}"):
            ok = st.session_state.client.send_feedback(
                trace_id=response.trace_id,
                session_id=response.session_id,
                thumbs="down",
            )
            if ok:
                st.toast("Feedback recorded. We'll improve!", icon="📝")

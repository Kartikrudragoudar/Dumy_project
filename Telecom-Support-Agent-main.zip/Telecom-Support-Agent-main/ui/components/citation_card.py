"""Renders KB citations as expandable cards."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ChatMessage


def render_citations(response: ChatMessage) -> None:
    """Show citation cards for the latest response."""
    if not response.citations:
        return
    st.markdown("**Sources**")
    for cit in response.citations:
        score_pct = int(cit.get("score", 0) * 100)
        with st.expander(f"📄 {cit['title']} §{cit['section']}  —  {score_pct}% match"):
            st.markdown(f"**Doc ID:** `{cit['doc_id']}`")
            st.markdown(f"**Section:** {cit['section']}")
            st.progress(cit.get("score", 0))

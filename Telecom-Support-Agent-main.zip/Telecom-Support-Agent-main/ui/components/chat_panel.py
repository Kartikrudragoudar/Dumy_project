"""Main chat interface: message history and input."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ChatMessage


def render_chat_panel() -> None:
    """Render the conversation history and the chat input box."""
    for msg in st.session_state.messages:
        role = msg["role"]
        with st.chat_message(role):
            st.markdown(msg["content"])
            if role == "assistant" and msg.get("meta"):
                _render_badges(msg["meta"])

    if prompt := st.chat_input("Describe your telecom issue..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.chat_message("assistant"):
            with st.spinner("Analysing your issue..."):
                try:
                    response: ChatMessage = st.session_state.client.chat(
                        message=prompt,
                        session_id=st.session_state.session_id,
                    )
                    st.markdown(response.answer)
                    _render_badges(response)

                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response.answer,
                        "meta": response,
                    })
                    st.session_state.degraded = response.llm.get("degraded", False)

                except Exception as exc:
                    error_msg = f"⚠️ Failed to reach the API: {exc}"
                    st.error(error_msg)
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": error_msg,
                    })


def _render_badges(meta: ChatMessage | dict) -> None:
    """Show category/priority/resolution badges inline."""
    if isinstance(meta, dict):
        cat = meta.get("category")
        pri = meta.get("priority")
        res = meta.get("resolution")
    else:
        cat = meta.category
        pri = meta.priority
        res = meta.resolution

    badges = []
    if cat:
        badges.append(f"🏷️ `{cat}`")
    if pri:
        color = {"P1": "🔴", "P2": "🟠", "P3": "🟡", "P4": "🟢"}.get(pri, "⚪")
        badges.append(f"{color} `{pri}`")
    if res:
        icon = {"RESOLVED": "✅", "ESCALATED": "🔁", "NEEDS_INFO": "❓"}.get(res, "❔")
        badges.append(f"{icon} `{res}`")
    if badges:
        st.caption(" · ".join(badges))

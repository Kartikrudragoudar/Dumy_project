"""Ticket panel shown in the sidebar when a case is escalated."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ChatMessage


def render_ticket_panel(response: ChatMessage) -> None:
    """Display ticket details in the sidebar when an escalation occurs."""
    if not response.ticket:
        return

    ticket = response.ticket
    st.sidebar.markdown("---")
    st.sidebar.subheader("🎫 Escalation Ticket")
    st.sidebar.markdown(f"**Ticket ID:** `{ticket['ticket_id']}`")
    st.sidebar.markdown(f"**Queue:** `{ticket['queue']}`")
    st.sidebar.markdown(f"**Priority:** `{ticket['priority']}`")
    st.sidebar.markdown(f"**Status:** `{ticket['status']}`")

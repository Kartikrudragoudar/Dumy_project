"""Warning banner when running on the backup LLM provider."""

from __future__ import annotations

import streamlit as st


def render_degraded_banner() -> None:
    """Show a warning if the current session is in degraded (failover) mode."""
    if st.session_state.get("degraded"):
        st.warning(
            "⚡ Running on backup LLM provider (Groq). "
            "Primary provider (Azure AI Foundry) is temporarily unavailable.",
            icon="⚠️",
        )

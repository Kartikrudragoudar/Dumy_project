"""Debug expander showing trace, provider, usage and latency."""

from __future__ import annotations

import streamlit as st

from ui.api_client import ChatMessage


def render_debug_drawer(response: ChatMessage) -> None:
    """Collapsible debug info for the latest response."""
    with st.expander("🔍 Debug Info"):
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"**Trace ID:** `{response.trace_id}`")
            st.markdown(f"**Session:** `{response.session_id}`")
            st.markdown(f"**Latency:** {response.latency_ms} ms")
        with col2:
            llm = response.llm
            st.markdown(f"**Provider:** `{llm.get('provider', '?')}`")
            st.markdown(f"**Alias:** `{llm.get('alias', '?')}`")
            st.markdown(f"**Degraded:** {'⚠️ Yes' if llm.get('degraded') else '✅ No'}")

        usage = response.usage
        st.markdown("---")
        ucol1, ucol2, ucol3 = st.columns(3)
        ucol1.metric("Prompt tokens", usage.get("prompt_tokens", 0))
        ucol2.metric("Completion tokens", usage.get("completion_tokens", 0))
        ucol3.metric("Est. cost", f"${usage.get('est_cost_usd', 0):.4f}")

"""Streamlit session management utilities for authentication."""

from __future__ import annotations

import streamlit as st

ROLE_PAGE_ACCESS = {
    "User": ["Dashboard", "AI Support Chat", "My Tickets", "Knowledge Center"],
    "Network Engineer": ["Dashboard", "AI Support Chat", "My Tickets", "Knowledge Center", "Analytics"],
    "Admin": ["Dashboard", "AI Support Chat", "My Tickets", "Knowledge Center", "Analytics", "Admin Panel", "User Management", "Profile"],
}


def init_auth_state() -> None:
    defaults = {
        "authenticated": False,
        "user_id": None,
        "user_name": "",
        "email": "",
        "role": "",
        "department": "",
        "location": "",
        "employee_id": "",
        "access_token": "",
        "last_login": "",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def login_user(user_data: dict, token: str) -> None:
    st.session_state["authenticated"] = True
    st.session_state["user_id"] = user_data.get("user_id")
    st.session_state["user_name"] = f"{user_data.get('first_name', '')} {user_data.get('last_name', '')}"
    st.session_state["email"] = user_data.get("email", "")
    st.session_state["role"] = user_data.get("role", "User")
    st.session_state["department"] = user_data.get("department", "")
    st.session_state["location"] = user_data.get("location", "")
    st.session_state["employee_id"] = user_data.get("employee_id", "")
    st.session_state["access_token"] = token
    st.session_state["last_login"] = user_data.get("last_login", "")


def logout_user() -> None:
    keys = ["authenticated", "user_id", "user_name", "email", "role", "department", "location", "employee_id", "access_token", "last_login"]
    for key in keys:
        if key in st.session_state:
            del st.session_state[key]
    init_auth_state()


def is_authenticated() -> bool:
    return st.session_state.get("authenticated", False)


def get_current_role() -> str:
    return st.session_state.get("role", "")


def has_page_access(page_name: str) -> bool:
    role = get_current_role()
    allowed_pages = ROLE_PAGE_ACCESS.get(role, [])
    return page_name in allowed_pages


def require_auth() -> None:
    if not is_authenticated():
        st.error("🔒 Access Denied: Please sign in to continue.")
        st.info("Navigate to the **Login** page from the sidebar.")
        st.stop()


def require_role(page_name: str) -> None:
    require_auth()
    if not has_page_access(page_name):
        st.warning(f"⚠️ Restricted: Your role `{get_current_role()}` does not have access to **{page_name}**.")
        st.stop()


def render_sidebar_profile() -> None:
    if is_authenticated():
        st.sidebar.markdown("---")
        st.sidebar.markdown(f"👤 **{st.session_state['user_name']}**")
        st.sidebar.markdown(f"🏷️ Role: `{st.session_state['role']}`")
        st.sidebar.markdown(f"🏢 {st.session_state['department']}")
        st.sidebar.markdown(f"📍 {st.session_state['location']}")
        if st.session_state.get("last_login"):
            st.sidebar.caption(f"Last login: {st.session_state['last_login']}")
        st.sidebar.markdown("---")
        if st.sidebar.button("🚪 Logout", use_container_width=True):
            logout_user()
            st.rerun()

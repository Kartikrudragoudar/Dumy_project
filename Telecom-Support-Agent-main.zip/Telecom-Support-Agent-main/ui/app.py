"""Telecom Support Agent — Streamlit UI entry point.

Run with: streamlit run ui/app.py --server.port 8501
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow imports from the project root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from ui.components.chat_panel import render_chat_panel
from ui.components.citation_card import render_citations
from ui.components.debug_drawer import render_debug_drawer
from ui.components.degraded_banner import render_degraded_banner
from ui.components.feedback_widget import render_feedback
from ui.components.ticket_panel import render_ticket_panel
from ui.state import init_state, reset_chat

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Telecom Support Agent",
    page_icon="📡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Load custom CSS ──────────────────────────────────────────────────────────
_CSS = Path(__file__).parent / "theme" / "styles.css"
if _CSS.exists():
    st.markdown(f"<style>{_CSS.read_text()}</style>", unsafe_allow_html=True)

# ── Init state ───────────────────────────────────────────────────────────────
init_state()

# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📡 Telecom Support")
    st.caption("AI-powered network issue triage")
    st.markdown("---")
    st.markdown(f"**Session:** `{st.session_state.session_id}`")

    if st.button("🔄 New Conversation", use_container_width=True):
        reset_chat()
        st.rerun()

    st.markdown("---")
    st.markdown(
        "**How it works:**\n"
        "1. Describe your issue\n"
        "2. AI classifies & retrieves solutions\n"
        "3. Get grounded answers or escalation"
    )

    # Health indicator
    st.markdown("---")
    if st.session_state.client.health():
        st.success("API connected", icon="🟢")
    else:
        st.error("API unreachable", icon="🔴")

# ── Main area ────────────────────────────────────────────────────────────────
render_degraded_banner()

st.title("💬 Support Chat")
st.caption("Describe your telecom issue and get instant help or escalation to a specialist.")

render_chat_panel()

# ── Post-response widgets (citations, feedback, debug, ticket) ───────────────
if st.session_state.messages:
    last = st.session_state.messages[-1]
    if last["role"] == "assistant" and last.get("meta"):
        meta = last["meta"]
        st.markdown("---")

        render_citations(meta)
        render_feedback(meta)
        render_debug_drawer(meta)
        render_ticket_panel(meta)

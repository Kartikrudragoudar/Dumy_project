"""NOC Multi-Agent Assistant — Streamlit entry point (Obsidian Flux theme).

Run with: streamlit run ui/app.py --server.port 8501
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from ui.auth_manager import init_auth_state, is_authenticated, logout_user
from ui.state import init_state
from ui.theme import inject_css, SURFACE_CONTAINER, OUTLINE_VARIANT, ON_SURFACE, ON_SURFACE_VARIANT, PRIMARY, TERTIARY, ERROR

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="NOC Multi-Agent Assistant",
    page_icon="🌐",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_css()
init_auth_state()
init_state()

# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    # Logo / Brand
    st.markdown(f"""
    <div style="text-align:center;padding:16px 0 8px 0;">
        <div style="font-size:32px;margin-bottom:4px;">🌐</div>
        <div style="font-family:Inter,sans-serif;font-size:16px;font-weight:700;color:{ON_SURFACE};letter-spacing:-0.01em;">NOC Core</div>
        <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};text-transform:uppercase;letter-spacing:0.08em;">Multi-Agent Assistant</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f'<div style="border-top:1px solid {OUTLINE_VARIANT};margin:8px 0;"></div>', unsafe_allow_html=True)

    if is_authenticated():
        # User profile card
        role = st.session_state.get("role", "User")
        role_color = TERTIARY if role == "Admin" else PRIMARY if role == "Network Engineer" else ON_SURFACE_VARIANT
        st.markdown(f"""
        <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:10px;padding:12px;margin-bottom:12px;">
            <div style="font-size:13px;font-weight:600;color:{ON_SURFACE};">{st.session_state.get('user_name', '')}</div>
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{role_color};text-transform:uppercase;letter-spacing:0.05em;margin-top:2px;">{role}</div>
            <div style="font-family:JetBrains Mono,monospace;font-size:10px;color:{ON_SURFACE_VARIANT};margin-top:4px;">{st.session_state.get('department', '')}</div>
        </div>
        """, unsafe_allow_html=True)

        # Navigation items
        st.markdown(f"""
        <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.06em;color:{ON_SURFACE_VARIANT};margin:16px 0 8px 4px;">Navigation</div>
        """, unsafe_allow_html=True)

        if st.button("🚪 Sign Out", use_container_width=True):
            logout_user()
            st.rerun()
    else:
        st.markdown(f"""
        <div style="text-align:center;padding:12px 0;color:{ON_SURFACE_VARIANT};font-size:13px;">
            Sign in to access the NOC portal.
        </div>
        """, unsafe_allow_html=True)

    # System status
    st.markdown(f'<div style="border-top:1px solid {OUTLINE_VARIANT};margin:12px 0 8px 0;"></div>', unsafe_allow_html=True)
    st.markdown(f"""
    <div style="font-family:JetBrains Mono,monospace;font-size:10px;text-transform:uppercase;letter-spacing:0.06em;color:{ON_SURFACE_VARIANT};margin-bottom:8px;">System</div>
    """, unsafe_allow_html=True)

    try:
        api_ok = st.session_state.client.health()
    except Exception:
        api_ok = False

    dot_color = TERTIARY if api_ok else ERROR
    status_text = "API Online" if api_ok else "API Offline"
    st.markdown(f"""
    <div style="display:flex;align-items:center;gap:6px;font-family:JetBrains Mono,monospace;font-size:11px;">
        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{dot_color};box-shadow:0 0 6px {dot_color};"></span>
        <span style="color:{dot_color};">{status_text}</span>
    </div>
    """, unsafe_allow_html=True)

# ── Main area (landing page) ────────────────────────────────────────────────
if not is_authenticated():
    st.markdown(f"""
    <div style="text-align:center;padding:80px 20px;">
        <div style="font-size:56px;margin-bottom:16px;">🌐</div>
        <h1 style="font-size:36px;color:{ON_SURFACE};margin-bottom:8px;">NOC Multi-Agent Assistant</h1>
        <p style="color:{ON_SURFACE_VARIANT};font-size:16px;max-width:500px;margin:0 auto 32px auto;">Enterprise network operations powered by AI multi-agent triage, FAISS RAG, and intelligent escalation.</p>
        <p style="color:{PRIMARY};font-size:14px;">Navigate to <b>Login</b> from the sidebar to get started.</p>
    </div>
    """, unsafe_allow_html=True)
else:
    st.markdown(f"""
    <div style="text-align:center;padding:60px 20px;">
        <div style="font-size:48px;margin-bottom:16px;">🌐</div>
        <h1 style="font-size:32px;color:{ON_SURFACE};margin-bottom:8px;">Welcome, {st.session_state.get('user_name', 'Operator')}</h1>
        <p style="color:{ON_SURFACE_VARIANT};font-size:14px;max-width:500px;margin:0 auto 24px auto;">Select a page from the sidebar to begin.</p>
    </div>
    """, unsafe_allow_html=True)

    # Quick links grid
    links = [
        ("📊", "Dashboard", "Real-time NOC metrics & incidents"),
        ("💬", "AI Chat", "Multi-agent triage assistant"),
        ("🎫", "My Tickets", "Track & manage incidents"),
        ("📚", "Knowledge", "FAISS-powered SOP search"),
    ]
    cols = st.columns(4)
    for col, (ico, name, desc) in zip(cols, links):
        with col:
            st.markdown(f"""
            <div style="background:{SURFACE_CONTAINER};border:1px solid {OUTLINE_VARIANT};border-radius:12px;padding:20px;text-align:center;min-height:120px;">
                <div style="font-size:28px;margin-bottom:8px;">{ico}</div>
                <div style="font-weight:600;color:{ON_SURFACE};font-size:14px;">{name}</div>
                <div style="font-size:11px;color:{ON_SURFACE_VARIANT};margin-top:4px;">{desc}</div>
            </div>
            """, unsafe_allow_html=True)

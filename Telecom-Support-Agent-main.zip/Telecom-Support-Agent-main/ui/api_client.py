"""HTTP client for the Telecom Support Agent API."""

from __future__ import annotations

import os
from dataclasses import dataclass

import httpx


@dataclass
class ChatMessage:
    trace_id: str
    session_id: str
    category: str | None
    priority: str | None
    resolution: str
    answer: str
    citations: list[dict]
    ticket: dict | None
    llm: dict
    usage: dict
    latency_ms: int


class ApiClient:
    def __init__(self) -> None:
        self._base = os.getenv("API_BASE_URL", "http://localhost:8000")
        self._key = os.getenv("API_KEY", "dev-key-change-me")
        self._timeout = float(os.getenv("API_TIMEOUT", "60"))

    def _headers(self) -> dict[str, str]:
        return {"X-API-Key": self._key, "Content-Type": "application/json"}

    def chat(self, message: str, session_id: str | None = None) -> ChatMessage:
        payload: dict = {"message": message}
        if session_id:
            payload["session_id"] = session_id
        resp = httpx.post(
            f"{self._base}/v1/chat",
            json=payload,
            headers=self._headers(),
            timeout=self._timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        return ChatMessage(
            trace_id=data["trace_id"],
            session_id=data["session_id"],
            category=data.get("category"),
            priority=data.get("priority"),
            resolution=data["resolution"],
            answer=data["answer"],
            citations=data.get("citations", []),
            ticket=data.get("ticket"),
            llm=data.get("llm", {}),
            usage=data.get("usage", {}),
            latency_ms=data.get("latency_ms", 0),
        )

    def send_feedback(self, trace_id: str, session_id: str, thumbs: str, comment: str = "") -> bool:
        payload = {
            "trace_id": trace_id,
            "session_id": session_id,
            "thumbs": thumbs,
            "comment": comment,
        }
        try:
            resp = httpx.post(
                f"{self._base}/v1/feedback",
                json=payload,
                headers=self._headers(),
                timeout=10,
            )
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    def health(self) -> bool:
        try:
            resp = httpx.get(f"{self._base}/healthz", timeout=5)
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

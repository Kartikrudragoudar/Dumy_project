"""HTTP client for the Telecom Support Agent API."""

from __future__ import annotations

import os
from dataclasses import dataclass

import httpx


@dataclass
class ChatMessage:
    trace_id: str
    session_id: str
    category: str | None
    priority: str | None
    resolution: str
    answer: str
    citations: list[dict]
    ticket: dict | None
    llm: dict
    usage: dict
    latency_ms: int


class ApiClient:
    def __init__(self) -> None:
        self._base = os.getenv("API_BASE_URL", "http://localhost:8000")
        self._key = os.getenv("API_KEY", "dev-key-change-me")
        self._timeout = float(os.getenv("API_TIMEOUT", "60"))

    def _headers(self) -> dict[str, str]:
        return {"X-API-Key": self._key, "Content-Type": "application/json"}

    def chat(self, message: str, session_id: str | None = None) -> ChatMessage:
        payload: dict = {"message": message}
        if session_id:
            payload["session_id"] = session_id
        resp = httpx.post(
            f"{self._base}/v1/chat",
            json=payload,
            headers=self._headers(),
            timeout=self._timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        return ChatMessage(
            trace_id=data["trace_id"],
            session_id=data["session_id"],
            category=data.get("category"),
            priority=data.get("priority"),
            resolution=data["resolution"],
            answer=data["answer"],
            citations=data.get("citations", []),
            ticket=data.get("ticket"),
            llm=data.get("llm", {}),
            usage=data.get("usage", {}),
            latency_ms=data.get("latency_ms", 0),
        )

    def send_feedback(self, trace_id: str, session_id: str, thumbs: str, comment: str = "") -> bool:
        payload = {
            "trace_id": trace_id,
            "session_id": session_id,
            "thumbs": thumbs,
            "comment": comment,
        }
        try:
            resp = httpx.post(
                f"{self._base}/v1/feedback",
                json=payload,
                headers=self._headers(),
                timeout=10,
            )
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    def health(self) -> bool:
        try:
            resp = httpx.get(f"{self._base}/healthz", timeout=5)
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    def readyz(self) -> dict | None:
        """Deep readiness check — returns checks dict or None on failure."""
        try:
            resp = httpx.get(f"{self._base}/readyz", timeout=5)
            return resp.json()
        except (httpx.HTTPError, Exception):
            return None

    def list_tickets(
        self,
        *,
        queue: str | None = None,
        priority: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        params: dict = {"limit": limit}
        if queue:
            params["queue"] = queue
        if priority:
            params["priority"] = priority
        if status:
            params["status"] = status
        try:
            resp = httpx.get(
                f"{self._base}/v1/tickets",
                params=params,
                headers=self._headers(),
                timeout=self._timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return []

    def get_ticket(self, ticket_id: str) -> dict | None:
        try:
            resp = httpx.get(
                f"{self._base}/v1/tickets/{ticket_id}",
                headers=self._headers(),
                timeout=self._timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return None

    def system_stats(self) -> dict:
        try:
            resp = httpx.get(f"{self._base}/v1/admin/stats", headers=self._headers(), timeout=10)
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return {}

    def system_config(self) -> dict:
        try:
            resp = httpx.get(f"{self._base}/v1/admin/config", headers=self._headers(), timeout=10)
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return {}

    def llm_health(self) -> dict:
        try:
            resp = httpx.get(f"{self._base}/v1/admin/llm-health", headers=self._headers(), timeout=10)
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return {}

    def kb_docs(self) -> dict:
        try:
            resp = httpx.get(f"{self._base}/v1/admin/kb-docs", headers=self._headers(), timeout=10)
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return {"total_docs": 0, "total_chunks": 0, "documents": []}

    def kb_search(self, query: str, k: int = 5) -> dict:
        try:
            resp = httpx.post(
                f"{self._base}/v1/admin/search",
                json={"query": query, "k": k},
                headers=self._headers(),
                timeout=self._timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, Exception):
            return {"results": [], "query": query, "max_score": 0, "total": 0}
